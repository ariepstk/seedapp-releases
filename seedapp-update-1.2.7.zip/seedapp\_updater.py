"""
SeedApp Updater — _updater.py
Dipanggil oleh update.bat
"""
import os, sys, json, shutil, zipfile, requests, time

VERSION_URL = "https://raw.githubusercontent.com/ariepstk/seedapp-releases/main/version.json"

def get_local_version(root):
    # root = SeedApp/ folder, version.txt ada di _internal/
    vfile = os.path.join(root, "_internal", "version.txt")
    if os.path.exists(vfile):
        return open(vfile).read().strip()
    return "0.0.0"

def get_remote_version():
    try:
        r = requests.get(VERSION_URL, timeout=10)
        return r.json()
    except Exception as e:
        print(f"  [!] Gagal cek versi: {e}")
        return None

def download_zip(url, dest):
    print(f"  [..] Download update dari GitHub...")
    r = requests.get(url, stream=True, timeout=120)
    r.raise_for_status()
    with open(dest, "wb") as f:
        total = int(r.headers.get("content-length", 0))
        downloaded = 0
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)
                downloaded += len(chunk)
                if total:
                    pct = downloaded * 100 // total
                    print(f"\r  [..] {pct}%", end="", flush=True)
    print()

def apply_update(zip_path, root):
    print("  [..] Mengaplikasikan update...")
    update_dir = os.path.join(root, "_internal", "update")
    backup_dir = os.path.join(root, "_internal", "update_backup")

    # Backup dulu
    if os.path.exists(backup_dir):
        shutil.rmtree(backup_dir)
    shutil.copytree(update_dir, backup_dir)
    print("  [OK] Backup dibuat → _internal/update_backup/")

    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(update_dir)
        print("  [OK] Update diterapkan.")
    except Exception as e:
        print(f"  [!] Error saat update: {e}")
        print("  [..] Rollback ke versi sebelumnya...")
        shutil.rmtree(update_dir)
        shutil.copytree(backup_dir, update_dir)
        print("  [OK] Rollback berhasil.")
        return False

    return True

def main():
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(__file__)
    root = os.path.abspath(root)

    print()
    local_ver = get_local_version(root)
    print(f"  Versi terinstall : {local_ver}")
    print(f"  Mengecek update...")

    info = get_remote_version()
    if not info:
        print("  [!] Tidak bisa cek update. Periksa koneksi internet.")
        return

    remote_ver = info.get("version", "0.0.0")
    notes      = info.get("notes", "")
    zip_url    = info.get("zip_url", "")

    print(f"  Versi terbaru    : {remote_ver}")

    if local_ver == remote_ver:
        print()
        print("  SeedApp sudah versi terbaru!")
        return

    print(f"  Catatan          : {notes}")
    print()
    ans = input("  Update ke versi terbaru? (y/n): ").strip().lower()
    if ans != "y":
        print("  Update dibatalkan.")
        return

    # Download ke temp
    zip_path = os.path.join(root, "_internal", "update_tmp.zip")
    download_zip(zip_url, zip_path)

    # Apply
    ok = apply_update(zip_path, root)
    os.remove(zip_path)

    if ok:
        # Update version.txt
        with open(os.path.join(root, "_internal", "version.txt"), "w") as f:
            f.write(remote_ver)
        print()
        print(f"  Update ke v{remote_ver} berhasil!")
        print("  Silakan restart SeedApp (run.bat).")
    else:
        print("  [!] Update gagal, versi sebelumnya dipulihkan.")

if __name__ == "__main__":
    main()
