"""
shopee_browser_resolver.py
Resolve URL video Shopee dgn HEADLESS BROWSER (Chrome via Playwright).

Kenapa: sejak Shopee pindah ke client-side rendering (web ver. 2026.06.v3),
HTML mentah halaman produk TIDAK lagi memuat video (video_info_list hilang) dan
API get_pc balas error anti-bot (90309999). Satu-satunya cara andal = buka
halaman pakai browser yang menjalankan JS, tunggu elemen <video> muncul, lalu
ambil .src-nya (link .mp4 down-*-id.vod.susercontent.com).

ROTASI MERATA (wajib): 1 profil Chrome per akun/cookie-set, dipilih bergiliran
LRU (pakai pick_cookie_set + cooldown dari shopee_resolver). Tidak ada 1 akun
yang dihajar terus → kurangi risiko block.

Thread-safety: Playwright SYNC harus jalan di 1 thread. Semua request resolve
(dari thread device manapun) dikirim ke 1 WORKER THREAD via antrian; worker
yang memegang Playwright + semua context. Aman dari ThreadPool runner.
"""
import os
import time
import queue
import threading

from src.macro import shopee_resolver as R

# ── Konfigurasi ──────────────────────────────────────────────────────
_HERE = os.path.dirname(__file__)
PROFILES_DIR = os.path.join(_HERE, "..", "..", "data", "resolver_profiles")
_CONFIG_PATH = os.path.join(_HERE, "..", "..", "data", "resolver_config.json")
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_STEALTH = """
Object.defineProperty(navigator,'webdriver',{get:()=>undefined});
window.chrome = window.chrome || {runtime:{}};
Object.defineProperty(navigator,'languages',{get:()=>['id-ID','id','en-US','en']});
Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3,4,5]});
"""

_CHROME_CANDIDATES = [
    os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Google\Chrome\Application\chrome.exe"),
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]


def _chrome_path():
    for p in _CHROME_CANDIDATES:
        if p and os.path.isfile(p):
            return p
    return None


def _headless():
    """Default headless True. Bisa di-override file data/resolver_config.json:
    {"headless": false}  → mode tampak (lebih lolos anti-bot, tapi muncul window)."""
    try:
        import json
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            return bool(json.load(f).get("headless", True))
    except Exception:
        return True


def browser_available():
    """True kalau Playwright terpasang & Chrome ada → resolver browser bisa dipakai."""
    if _chrome_path() is None:
        return False
    try:
        import playwright  # noqa: F401
        return True
    except Exception:
        return False


def _safe(s):
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in str(s))[:60] or "set"


# ── Worker thread (pemilik tunggal Playwright) ───────────────────────
_REQ_Q = queue.Queue()
_worker_started = False
_worker_lock = threading.Lock()


def _ensure_worker():
    global _worker_started
    with _worker_lock:
        if not _worker_started:
            threading.Thread(target=_worker_loop, daemon=True, name="ss-browser-resolver").start()
            _worker_started = True


def _worker_loop():
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        # Habiskan antrian dgn hasil kosong supaya pemanggil tak menggantung.
        while True:
            req = _REQ_Q.get()
            if req is None:
                return
            _, _, box, done = req
            box[0] = ""
            done.set()
    contexts = {}   # account_key -> persistent context (dibuat sekali, dipakai ulang)
    with sync_playwright() as pw:
        while True:
            req = _REQ_Q.get()
            if req is None:
                break
            product_url, log, box, done = req
            try:
                box[0] = _do_resolve(pw, contexts, product_url, log)
            except Exception as e:
                if log:
                    log(f"⚠ resolver browser error: {e}")
                box[0] = ""
            finally:
                done.set()


def _launch_ctx(pw, cookie_set):
    """Buka persistent context (1 profil per akun), seed cookies set ini."""
    key = R._set_key(cookie_set)
    profdir = os.path.join(PROFILES_DIR, _safe(key))
    os.makedirs(profdir, exist_ok=True)
    ctx = pw.chromium.launch_persistent_context(
        profdir,
        headless=_headless(),
        executable_path=_chrome_path(),
        user_agent=_UA,
        viewport={"width": 1280, "height": 900},
        args=["--disable-blink-features=AutomationControlled", "--no-first-run",
              "--no-default-browser-check"],
    )
    try:
        ctx.add_init_script(_STEALTH)
    except Exception:
        pass
    jar = cookie_set.get("jar", {}) or {}
    cookies = [{"name": k, "value": v, "domain": ".shopee.co.id", "path": "/"}
               for k, v in jar.items()]
    try:
        ctx.add_cookies(cookies)
    except Exception:
        pass
    return ctx


def _do_resolve(pw, contexts, product_url, log, timeout=30):
    ids = R.extract_ids(product_url)
    if not ids:
        return ""
    shop_id, item_id = ids

    cookie_set, key = R.pick_cookie_set()   # rotasi MERATA antar akun (LRU + cooldown)
    if not cookie_set:
        if log:
            log("⚠ resolver browser: belum ada cookies Shopee")
        return ""

    ctx = contexts.get(key)
    if ctx is None:
        ctx = _launch_ctx(pw, cookie_set)
        contexts[key] = ctx
    page = ctx.pages[0] if ctx.pages else ctx.new_page()

    url = f"https://shopee.co.id/product/{shop_id}/{item_id}"
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=timeout * 1000)
    except Exception as e:
        if log:
            log(f"🎬 resolver {item_id}: gagal buka halaman ({e})")
        return ""

    # Terdeteksi anti-bot / belum login → akun ini diistirahatkan (rotasi pindah akun lain)
    cur = page.url or ""
    if "/verify/" in cur or "traffic/error" in cur or "is_logged_in=false" in cur or "/buyer/login" in cur:
        R.mark_blocked(key)
        label = cookie_set.get("label", "akun")
        if log:
            log(f"🎬 resolver {item_id}: '{label}' diblok/belum login → istirahat 15mnt, ganti akun")
        return ""

    # Tunggu elemen <video> muncul & ambil .src
    src = ""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            src = page.evaluate(
                "()=>{const v=document.querySelector('video');return v?(v.src||v.currentSrc||''):''}")
        except Exception:
            src = ""
        if src and src.startswith("http"):
            break
        page.wait_for_timeout(400)

    if log:
        log(f"🎬 resolver {item_id}: {'OK (browser)' if src else 'tidak ada video di halaman'}")
    return src or ""


def resolve_via_browser(product_url, log=None, timeout=30):
    """API publik (thread-safe): kirim request ke worker, tunggu hasil. Return '' kalau gagal."""
    _ensure_worker()
    box = [""]
    done = threading.Event()
    _REQ_Q.put((product_url, log, box, done))
    # beri kelonggaran di atas timeout internal (launch context bisa makan waktu)
    done.wait(timeout + 40)
    return box[0]
