"""
Tools — Cek Pelanggaran (Status Kesehatan Video)
Scrape username + status kesehatan video dari akun yang sedang login.
"""

import time
import uiautomator2 as u2

SHOPEE_PACKAGE = "com.shopee.id"
WAIT_TIMEOUT   = 5

STATUS_LIST = ["Sangat Baik", "Baik", "Buruk", "Sangat Buruk"]


def _force_close_foreground(d):
    try:
        current = d.app_current()
        pkg = current.get("package", "")
        if pkg:
            d.app_stop(pkg)
    except Exception:
        pass


def _start_shopee(d, clone: bool):
    d.shell("settings put system accelerometer_rotation 0")
    d.shell("settings put system user_rotation 0")
    if clone:
        d.shell(f"am start --user 999 -n {SHOPEE_PACKAGE}/com.shopee.app.ui.home.HomeActivity_")
    else:
        d.app_start(SHOPEE_PACKAGE)
    time.sleep(3)


def _dismiss_popup(d):
    for _ in range(3):
        if d(description="Close").exists(timeout=1):
            d(description="Close").click(); time.sleep(0.5)
        elif d(text="Nanti Saja").exists(timeout=1):
            d(text="Nanti Saja").click(); time.sleep(0.5)
        elif d(text="Lewati").exists(timeout=1):
            d(text="Lewati").click(); time.sleep(0.5)
        else:
            break


def scrape_pelanggaran(serial: str, clone: bool, log=None) -> dict:
    """
    Scrape username + status kesehatan video dari 1 device.
    Return: {"username": str, "status": str, "error": str|None}
    """
    def _log(msg):
        if log: log(msg)

    result = {"username": "—", "status": "—", "error": None}

    try:
        d = u2.connect(serial)
        _log(f"📱 Terhubung ke {serial}")

        # Step 1 — Buka Shopee
        _log("🚀 Membuka Shopee...")
        _force_close_foreground(d)
        _start_shopee(d, clone)
        time.sleep(1)

        # Step 2 — Delay 3s (sudah di _start_shopee)
        # Step 3 — Dismiss popup
        _dismiss_popup(d)

        # Step 4 — Klik tab Live & Video
        _log("🎬 Klik tab Live & Video...")
        tab_lv = d(description="tab_bar_button_video_and_live")
        if not tab_lv.exists(timeout=WAIT_TIMEOUT):
            result["error"] = "Tab Live & Video tidak ditemukan"
            _log(f"❌ {result['error']}"); return result
        tab_lv.click()

        # Step 5 — Delay 3s
        time.sleep(3)

        # Step 6 — Dismiss popup
        _dismiss_popup(d)

        # Step 7 — Klik ikon Profil kanan atas
        _log("👤 Klik ikon Profil...")
        btn_profil = d(description="click me page icon")
        if not btn_profil.exists(timeout=WAIT_TIMEOUT):
            result["error"] = "Ikon Profil tidak ditemukan"
            _log(f"❌ {result['error']}"); return result
        btn_profil.click()

        # Step 8 — Delay 3s
        time.sleep(3)

        # Step 9 — Dismiss popup
        _dismiss_popup(d)

        # Step 10 — Scrape username
        _log("🔍 Scrape username...")
        username_el = None
        for el in d(className="android.widget.TextView"):
            try:
                txt = el.get_text() or ""
                if txt.startswith("Username: "):
                    username_el = txt
                    break
            except Exception:
                continue

        if username_el:
            result["username"] = username_el.replace("Username: ", "").strip()
            _log(f"✅ Username: {result['username']}")
        else:
            result["error"] = "Username tidak ditemukan"
            _log(f"⚠ {result['error']}")

        # Step 11 — Klik Pusat Kreator
        _log("🏢 Klik Pusat Kreator...")
        btn_pk = d(text="Pusat Kreator")
        if not btn_pk.exists(timeout=WAIT_TIMEOUT):
            result["error"] = (result["error"] or "") + " | Pusat Kreator tidak ditemukan"
            _log(f"❌ Pusat Kreator tidak ditemukan"); return result
        btn_pk.click()

        # Step 12 — Delay 3s
        time.sleep(3)

        # Step 13 — Dismiss popup
        _dismiss_popup(d)

        # Step 14 — Scrape status kesehatan (timeout 5s)
        _log("🔍 Scrape status kesehatan video...")
        status_found = None
        for status in STATUS_LIST:
            if d(text=status).exists(timeout=5):
                status_found = status
                break

        if status_found:
            result["status"] = status_found
            _log(f"✅ Status: {result['status']}")

            # Step 15 — Klik status untuk buka halaman Kesehatan Video
            _log("📄 Membuka halaman Kesehatan Video...")
            d(text=status_found).click()

        else:
            result["error"] = (result["error"] or "") + " | Status kesehatan tidak ditemukan"
            _log(f"⚠ Status kesehatan tidak ditemukan")

    except Exception as e:
        result["error"] = str(e)
        _log(f"❌ Error: {e}")

    return result
