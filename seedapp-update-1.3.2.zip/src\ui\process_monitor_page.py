"""
Process Monitor Page — theme-aware (dark/light)
"""

from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QFrame,
    QScrollArea, QTextEdit, QPushButton
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QTextCursor
from src.core.log_manager import LogManager
from src.core.database import ProjectRepo


def _c():
    """Return color dict sesuai theme aktif."""
    try:
        from src.ui.main_window import current_theme
        t = current_theme()
    except Exception:
        t = "dark"

    if t == "light":
        return {
            "bg":          "#f7f8fa",
            "bg2":         "#ffffff",
            "bg3":         "#f0f4f8",
            "border":      "#e0e6ed",
            "border2":     "#f0f4f8",
            "title":       "#1a2332",
            "text":        "#1a2332",
            "text_dim":    "#8a9bb0",
            "text_muted":  "#a0aab8",
            "dot_active":  "#00c48c",
            "dot_off":     "#e0e6ed",
            "sel_bg":      "#f0fdf8",
            "hover_bg":    "#f7f8fa",
            "tab_active":  "#00a876",
            "tab_border":  "#00c48c",
            "log_bg":      "#ffffff",
            "log_fg":      "#374151",
        }
    else:
        return {
            "bg":          "#1a1b2e",
            "bg2":         "#242538",
            "bg3":         "#0f1022",
            "border":      "#2e2f50",
            "border2":     "#1e1f38",
            "title":       "#ffffff",
            "text":        "#e0e1f0",
            "text_dim":    "#5a5c8a",
            "text_muted":  "#5a5c8a",
            "dot_active":  "#00c48c",
            "dot_off":     "#2e2f50",
            "sel_bg":      "#1e2040",
            "hover_bg":    "#1e1f38",
            "tab_active":  "#00c48c",
            "tab_border":  "#00c48c",
            "log_bg":      "#0f1022",
            "log_fg":      "#c8c9d8",
        }


class ProcessMonitorPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._selected_pid  = None
        self._log_cb_global = None
        self._build_ui()

        LogManager.instance().subscribe_global(self._on_global_log)

        self._timer = QTimer(self)
        self._timer.setInterval(2000)
        self._timer.timeout.connect(self._refresh_dots)
        self._timer.start()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Panel Kiri ───────────────────────────
        self._left_panel = QFrame()
        self._left_panel.setFixedWidth(240)
        left_v = QVBoxLayout(self._left_panel)
        left_v.setContentsMargins(0, 0, 0, 0)
        left_v.setSpacing(0)

        # Header kiri
        self._hdr = QFrame()
        self._hdr.setObjectName("pageHeader")
        self._hdr.setFixedHeight(64)
        hdr_l = QHBoxLayout(self._hdr)
        hdr_l.setContentsMargins(16, 0, 16, 0)
        self._hdr_title = QLabel("Process Monitor")
        self._hdr_title.setObjectName("pageTitle")
        self._hdr_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hdr_l.addWidget(self._hdr_title)
        left_v.addWidget(self._hdr)
        hdr_div = QFrame(); hdr_div.setFixedHeight(1); hdr_div.setObjectName("headerDivider")
        left_v.addWidget(hdr_div)

        # Filter tabs
        self._filter_bar = QFrame()
        self._filter_bar.setFixedHeight(38)
        fb_lay = QHBoxLayout(self._filter_bar)
        fb_lay.setContentsMargins(16, 0, 16, 0); fb_lay.setSpacing(20)
        self._filter = "all"
        self._filter_btns = {}
        fb_lay.addStretch()
        for key, label in [("all","All"),("active","Active"),("inactive","Inactive")]:
            btn = QPushButton(label)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _, k=key: self._set_filter(k))
            self._filter_btns[key] = btn
            fb_lay.addWidget(btn)
        fb_lay.addStretch()
        left_v.addWidget(self._filter_bar)
        self._update_filter_style("all")

        # List scroll
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent; border:none;")
        self._list_container = QWidget()
        self._list_container.setStyleSheet("background:transparent;")
        self._list_layout = QVBoxLayout(self._list_container)
        self._list_layout.setContentsMargins(8, 8, 8, 8)
        self._list_layout.setSpacing(4)
        self._list_layout.addStretch()
        scroll.setWidget(self._list_container)
        left_v.addWidget(scroll, 1)
        root.addWidget(self._left_panel)

        # ── Panel Kanan ──────────────────────────
        self._right_panel = QFrame()
        right_v = QVBoxLayout(self._right_panel)
        right_v.setContentsMargins(0, 0, 0, 0)
        right_v.setSpacing(0)

        # Header kanan
        self._right_hdr = QFrame()
        self._right_hdr.setFixedHeight(52)
        rh_lay = QHBoxLayout(self._right_hdr)
        rh_lay.setContentsMargins(20, 0, 16, 0); rh_lay.setSpacing(10)

        self._status_dot = QLabel("●")
        self._status_dot.setFixedWidth(18)

        self._log_title = QLabel("— Pilih project di kiri —")
        self._log_title.setStyleSheet(
            "font-size:14px; font-weight:600; background:transparent;")

        self._stop_btn = QPushButton("⏹ Stop")
        self._stop_btn.setObjectName("btnDanger")
        self._stop_btn.setFixedHeight(28)
        self._stop_btn.setStyleSheet(
            "QPushButton#btnDanger { background:#c0392b; color:white; border-radius:5px; font-size:12px; padding: 0 14px; }"
            "QPushButton#btnDanger:hover { background:#e74c3c; }"
        )
        self._stop_btn.setVisible(False)
        self._stop_btn.clicked.connect(self._stop_selected)

        rh_lay.addWidget(self._status_dot)
        rh_lay.addWidget(self._log_title, 1)
        rh_lay.addWidget(self._stop_btn)
        right_v.addWidget(self._right_hdr)

        self._log_text = QTextEdit()
        self._log_text.setReadOnly(True)
        self._log_text.setPlaceholderText(
            "Log akan muncul di sini saat project dijalankan...")
        right_v.addWidget(self._log_text, 1)
        root.addWidget(self._right_panel, 1)

        self._apply_theme()

    def _apply_theme(self):
        c = _c()
        self._left_panel.setStyleSheet(
            f"background:{c['bg']}; border-right:1px solid {c['border']};")
        self._hdr.setStyleSheet(
            f"background:{c['bg2']}; border-bottom:1px solid {c['border']};")
        self._hdr_title.setStyleSheet(
            f"color:{c['title']}; font-size:14px; font-weight:700; background:transparent;")
        self._filter_bar.setStyleSheet(
            f"background:{c['bg']}; border-bottom:1px solid {c['border2']};")
        self._right_panel.setStyleSheet(f"background:{c['bg3']};")
        self._right_hdr.setStyleSheet(
            f"background:{c['bg2']}; border-bottom:1px solid {c['border']};")
        self._log_text.setStyleSheet(f"""
            QTextEdit {{
                background: {c['log_bg']};
                border: none;
                color: {c['log_fg']};
                font-family: Consolas, 'Courier New', monospace;
                font-size: 13px;
                padding: 12px;
            }}
        """)
        self._update_filter_style(self._filter)
        self._render_list()

    def refresh(self):
        self._apply_theme()
        self._render_list()

    # ── Filter ───────────────────────────────
    def _set_filter(self, key):
        self._filter = key
        self._update_filter_style(key)
        self._render_list()

    def _update_filter_style(self, active):
        c = _c()
        for k, btn in self._filter_btns.items():
            if k == active:
                btn.setStyleSheet(f"""
                    QPushButton {{
                        background: transparent; border: none;
                        border-bottom: 2px solid {c['tab_border']};
                        color: {c['tab_active']}; font-size: 13px;
                        font-weight: 700; padding: 4px 0px;
                    }}
                """)
            else:
                btn.setStyleSheet(f"""
                    QPushButton {{
                        background: transparent; border: none;
                        color: {c['text_dim']}; font-size: 13px;
                        padding: 4px 0px;
                    }}
                    QPushButton:hover {{ color: {c['tab_active']}; }}
                """)

    # ── List ─────────────────────────────────
    def _render_list(self):
        c = _c()
        lm       = LogManager.instance()
        projects = ProjectRepo.get_all()
        pid_with_log = set(lm._logs.keys())

        shown = []
        for p in projects:
            pid       = p["id"]
            is_active = lm.is_running(pid)
            has_log   = pid in pid_with_log
            if not has_log: continue
            if self._filter == "active"   and not is_active: continue
            if self._filter == "inactive" and is_active:     continue
            shown.append((p, is_active))

        while self._list_layout.count() > 1:
            item = self._list_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

        if not shown:
            empty = QLabel("Belum ada proses")
            empty.setStyleSheet(
                f"color:{c['text_dim']}; font-size:13px; padding:20px;")
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._list_layout.insertWidget(0, empty)
            return

        for i, (p, is_active) in enumerate(shown):
            self._list_layout.insertWidget(i, self._make_item(p, is_active))

    def _make_item(self, p: dict, is_active: bool) -> QFrame:
        c   = _c()
        pid = p["id"]
        is_sel = (pid == self._selected_pid)

        frame = QFrame()
        frame.setFixedHeight(48)
        frame.setCursor(Qt.CursorShape.PointingHandCursor)

        if is_sel:
            frame.setStyleSheet(f"""
                QFrame {{ background: {c['sel_bg']}; border-radius: 8px; border: none; }}
            """)
        else:
            frame.setStyleSheet(f"""
                QFrame {{ background: transparent; border-radius: 8px; border: none; }}
                QFrame:hover {{ background: {c['hover_bg']}; }}
            """)

        frame.mousePressEvent = lambda _, p_=p: self._select_project(p_)

        lay = QHBoxLayout(frame)
        lay.setContentsMargins(12, 0, 12, 0); lay.setSpacing(10)

        # Pulse dot untuk active, static untuk inactive
        dot = QLabel("●")
        dot_color = c['dot_active'] if is_active else c['dot_off']
        dot.setStyleSheet(
            f"color:{dot_color}; font-size:{'14px' if is_active else '10px'}; background:transparent;")
        dot.setFixedWidth(16)

        if is_active:
            self._pulse_dot(dot)

        info = QVBoxLayout(); info.setSpacing(1)
        name_lbl = QLabel(p["name"])
        name_lbl.setStyleSheet(
            f"color:{c['text']}; font-size:14px; font-weight:600; background:transparent;")

        logs     = LogManager.instance().get_logs(pid)
        start_ts = logs[0]["ts"] if logs else "—"
        status_t = "Running" if is_active else "Stopped"
        sub_lbl  = QLabel(f"START: {start_ts}  ·  {status_t}")
        sub_lbl.setStyleSheet(
            f"color:{c['text_dim']}; font-size:11px; background:transparent;")

        info.addWidget(name_lbl); info.addWidget(sub_lbl)
        lay.addWidget(dot); lay.addLayout(info, 1)
        return frame

    # ── Select & Load Log ─────────────────────
    def _select_project(self, p: dict):
        self._selected_pid = p["id"]
        self._render_list()
        self._load_log(p)

    def _load_log(self, p: dict):
        c   = _c()
        pid = p["id"]
        lm  = LogManager.instance()

        if self._log_cb_global:
            lm.unsubscribe_global(self._log_cb_global)
            self._log_cb_global = None

        self._log_title.setText(p["name"])
        self._log_title.setStyleSheet(
            f"color:{c['text']}; font-size:14px; font-weight:600; background:transparent;")
        self._refresh_dot(pid)
        self._stop_btn.setVisible(lm.is_running(pid))

        self._log_text.clear()
        for entry in lm.get_logs(pid):
            self._append_line(entry["ts"], entry["msg"])

        def on_new(project_id, entry):
            if project_id == pid:
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(0, lambda: self._append_line(entry["ts"], entry["msg"]))
                QTimer.singleShot(0, lambda: self._refresh_dot(pid))
                QTimer.singleShot(0, lambda: self._stop_btn.setVisible(
                    LogManager.instance().is_running(pid)))

        self._log_cb_global = on_new
        lm.subscribe_global(on_new)

    def _append_line(self, ts: str, msg: str):
        from src.core.log_manager import get_log_color
        c = _c()
        self._log_text.moveCursor(QTextCursor.MoveOperation.End)
        ts_html = f'<span style="color:{c["text_dim"]};">{ts}</span>'
        color   = get_log_color(msg)
        if color:
            msg_html = f'<span style="color:{color};">{msg}</span>'
        else:
            msg_html = f'<span style="color:{c["log_fg"]};">{msg}</span>'
        self._log_text.append(f'{ts_html}&nbsp;&nbsp;{msg_html}')
        self._log_text.moveCursor(QTextCursor.MoveOperation.End)

    # ── Stop ─────────────────────────────────
    def _stop_selected(self):
        if not self._selected_pid: return
        lm = LogManager.instance()
        worker = lm.get_worker(self._selected_pid)
        if not worker: return
        worker.stop()
        worker.terminate()
        worker.wait(2000)
        lm.remove_worker(self._selected_pid)

        try:
            from src.core.database import get_connection, ProjectRepo
            conn = get_connection()
            conn.execute("""
                UPDATE project_videos SET status='error',
                    status_shopee=CASE WHEN status_shopee='proses' THEN 'error' ELSE status_shopee END,
                    status_tiktok=CASE WHEN status_tiktok='proses' THEN 'error' ELSE status_tiktok END,
                    updated_at=datetime('now','localtime')
                WHERE project_id=? AND status='proses'
            """, (self._selected_pid,))
            conn.commit(); conn.close()
            ProjectRepo.update_status(self._selected_pid, "berhenti")
        except: pass

        self._stop_btn.setVisible(False)
        self._refresh_dot(self._selected_pid)
        self._render_list()

    def _pulse_dot(self, dot: QLabel):
        """Pulse/breathing animation untuk dot aktif."""
        # Stop timer lama jika ada
        old_timer = getattr(dot, '_pulse_timer', None)
        if old_timer is not None:
            try: old_timer.stop()
            except: pass

        timer = QTimer(dot)
        timer.setInterval(800)
        dot._pulse_timer = timer
        _state = [True]
        c = _c()
        def toggle():
            # Cek widget masih hidup sebelum akses — cegah crash saat dot sudah di-destroy
            try:
                if not dot.isVisible() and not dot.parent():
                    timer.stop()
                    return
            except RuntimeError:
                # Widget sudah di-delete di level C++ — stop timer dan keluar
                try: timer.stop()
                except: pass
                return
            _state[0] = not _state[0]
            size = "16px" if _state[0] else "10px"
            try:
                dot.setStyleSheet(
                    f"color:{c['dot_active']}; font-size:{size}; background:transparent;")
            except RuntimeError:
                try: timer.stop()
                except: pass
        timer.timeout.connect(toggle)
        timer.start()

    # ── Helpers ──────────────────────────────
    def _refresh_dot(self, pid: int):
        c = _c()
        is_active = LogManager.instance().is_running(pid)
        color = c['dot_active'] if is_active else c['dot_off']
        self._status_dot.setStyleSheet(
            f"color:{color}; font-size:14px; background:transparent;")

    def _refresh_dots(self):
        self._render_list()
        if self._selected_pid:
            self._refresh_dot(self._selected_pid)
            self._stop_btn.setVisible(
                LogManager.instance().is_running(self._selected_pid))

    def _on_global_log(self, project_id, entry):
        # Throttle — render list max 1x per 2s agar tidak flood dari banyak worker
        if not getattr(self, '_render_pending', False):
            self._render_pending = True
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(2000, self._deferred_render)

    def _deferred_render(self):
        self._render_pending = False
        self._render_list()
