"""
runner.py
Flow per produk (TikTok dulu → Shopee):
  1. Connect sekali → d (reuse sampai selesai)
  2. Download {id}_tiktok.mp4 → upscale → copy → {id}_shopee.mp4
  3. Push tiktok → Upload TikTok → Force close TikTok
  4. Delay 30s
  5. Push shopee → Upload Shopee → Tonton video min_max
  6. destroy d → _interruptible_sleep sudah tidak ada koneksi aktif
  7. Cleanup HP

Aturan:
  - PC: tidak pernah hapus file (cache permanen)
  - HP: hapus sebelum push (di push_to_device) dan sesudah upload (cleanup_hp)
  - u2.connect() hanya 1x per item per HP
"""

import os
import time
import random
from src.core.database import ProjectRepo, VideoRepo, UploadStatsRepo
from src.macro import shopee_only, tiktok_only
from src.macro.media_helper import cleanup_hp
from src.core.debug_logger import dlog
from src.core.error_categories import format_error


def _interruptible_sleep(seconds: int, stop_flag_fn, log_fn=None, label=""):
    """Sleep yang bisa di-interrupt oleh stop_flag, tanpa block GIL lama."""
    import time
    for i in range(seconds, 0, -1):
        if stop_flag_fn():
            if log_fn: log_fn(f"⏹ Jeda dibatalkan.")
            return
        time.sleep(1)


def _safe_disconnect(d):
    """Tutup koneksi u2 dengan aman — cegah zombie connection di ADB daemon."""
    if d is None:
        return
    try:
        if hasattr(d, '_default_session'):
            d._default_session.close()
    except Exception:
        pass
    try:
        if hasattr(d, 'stop_uiautomator'):
            d.stop_uiautomator()
    except Exception:
        pass


class ProjectRunner:

    def __init__(self, project_id: int, device_serial: str = None,
                 log_fn=None, stop_flag_fn=None, target_selesai: int = 0,
                 watch_min: int = 10, watch_max: int = 20,
                 jeda_tiktok_shopee: int = 30,
                 folder_sound: str = "D:\\TikTok\\sounds",
                 retry_video_id: int = 0,
                 retry_platform: str = "",
                 max_retry: int = 10,
                 shopee_clone: bool = False,
                 mix_sound: bool = True,
                 auto_hapus_cache: bool = True,
                 fast_mode: bool = False,
                 tiktok_search_keywords: str = "remix terbaru"):
        self.project_id       = project_id
        self.device_serial    = device_serial
        self.log_fn           = log_fn or print
        self.stop_flag_fn     = stop_flag_fn or (lambda: False)
        self.target_selesai   = target_selesai
        self.watch_min        = watch_min
        self.watch_max        = watch_max
        self.jeda_tiktok_shopee = jeda_tiktok_shopee
        self.folder_sound      = folder_sound
        self.retry_video_id    = retry_video_id
        self.retry_platform    = retry_platform
        self.max_retry         = max_retry
        self.shopee_clone      = shopee_clone
        self.mix_sound         = mix_sound
        self.auto_hapus_cache  = auto_hapus_cache
        self.fast_mode         = fast_mode
        # Parse keywords (split by koma, trim space, filter empty)
        kw_raw = tiktok_search_keywords or "remix terbaru"
        self.tiktok_keywords = [k.strip() for k in kw_raw.split(",") if k.strip()] or ["remix terbaru"]

    def _pick_search_query(self) -> str:
        """Random pick keyword dari list. Dipanggil tiap upload buat variasi."""
        import random as _r
        return _r.choice(self.tiktok_keywords)

    def log(self, msg): self.log_fn(msg)
    def is_stopped(self): return self.stop_flag_fn()

    def _connect(self):
        import uiautomator2 as u2
        try:
            return u2.connect(self.device_serial) if self.device_serial else u2.connect()
        except Exception as e:
            self.log(format_error(e, f"Connect {self.device_serial or 'default'}"))
            raise

    def run(self) -> tuple[int, int]:
        p = ProjectRepo.get_by_id(self.project_id)
        if not p or not p.get("dataset_id"):
            self.log("❌ Project tidak punya dataset!"); return 0, 0

        upload_target = p.get("upload_target", "shopee_tiktok")

        # Retry mode: override items & upload_target
        if self.retry_video_id:
            all_items = VideoRepo.get_by_project(self.project_id, status_filter="semua")
            items = [x for x in all_items if x["id"] == self.retry_video_id]
            if not items:
                self.log(f"❌ Video id={self.retry_video_id} tidak ditemukan"); return 0, 0
            if self.retry_platform == "tiktok":
                upload_target = "tiktok_retry"
            else:  # "shopee" atau default
                upload_target = "shopee"
        else:
            items = VideoRepo.get_by_project(self.project_id, status_filter="antrian")
            if not items:
                self.log("ℹ️  Tidak ada video dengan status Antrian."); return 0, 0

        # Normalize: tiktok_only (project mode) pakai flow yang sama dengan tiktok_retry
        if upload_target == "tiktok_only":
            upload_target = "tiktok_retry"

        mode_label = "TikTok & Shopee" if upload_target == "shopee_tiktok" else ("TikTok" if upload_target == "tiktok_retry" else "Shopee saja")
        self.log(f"── {p['name']}  |  {mode_label}  |  Clone={'ON' if self.shopee_clone else 'OFF'}  |  Mix Song={'ON' if self.mix_sound else 'OFF'}  |  Nonton={self.watch_min}~{self.watch_max}s  |  Jeda={self.jeda_tiktok_shopee}s  |  Max Retry={self.max_retry}  |  Target: {self.target_selesai}  |  {self.device_serial or 'default'} ──")

        # ── Persiapan awal — 1 connect ──
        try:
            d = self._connect()
            d.shell("settings put system accelerometer_rotation 0")
            d.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mp4' -delete")
            d.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mov' -delete")
            _safe_disconnect(d); d = None  # destroy setelah persiapan
        except Exception as e:
            self.log(format_error(e, "Persiapan awal"))

        ProjectRepo.update_status(self.project_id, "berjalan")

        success     = 0
        error       = 0
        shopee_ok   = 0
        shopee_fail = 0
        tiktok_ok   = 0
        tiktok_fail = 0

        for _idx, item in enumerate(items):
            if self.is_stopped():
                self.log("⏹  Dihentikan oleh pengguna."); break

            if self.target_selesai > 0 and success >= self.target_selesai:
                self.log(f"🎯 Target {self.target_selesai} video selesai tercapai!"); break

            excel_no = item.get("no")
            if excel_no is None:
                self.log(f"❌ Kolom 'no' tidak ditemukan, skip id={item['id']}"); continue

            video_url = item.get("video_result", "").strip()
            if not video_url:
                self.log(f"⚠ [{excel_no}] URL video kosong, skip!")
                VideoRepo.update_status_by_project(
                    self.project_id, item["id"], "error",
                    status_shopee="error",
                    status_tiktok="error" if upload_target == "shopee_tiktok" else "antrian"
                )
                VideoRepo.save_error_message(
                    self.project_id, item["id"],
                    error_shopee="URL video kosong",
                    error_tiktok="URL video kosong" if upload_target == "shopee_tiktok" else None
                )
                error += 1
                continue

            # Set → proses (hanya platform yang akan dijalankan)
            if upload_target == "shopee_tiktok":
                VideoRepo.update_status_by_project(
                    self.project_id, item["id"], "proses",
                    status_shopee="proses",
                    status_tiktok="proses",
                )
            elif upload_target == "tiktok_retry":
                VideoRepo.update_status_by_project(
                    self.project_id, item["id"], "proses",
                    status_tiktok="proses",
                    # status_shopee tidak disentuh
                )
            else:  # shopee / shopee retry
                VideoRepo.update_status_by_project(
                    self.project_id, item["id"], "proses",
                    status_shopee="proses",
                    # status_tiktok tidak disentuh
                )

            _shopee_notified = [False]
            if upload_target == "shopee_tiktok":
                ok_shopee, ok_tiktok = self._run_tiktok_shopee(item, excel_no)
            elif upload_target == "tiktok_retry":
                ok_tiktok = self._run_tiktok_only(item, excel_no)
                ok_shopee = None
            else:
                _p_name_pre = ProjectRepo.get_by_id(self.project_id).get("name", "")
                def _notify_shopee_done(_pn=_p_name_pre):
                    self._finalize_status(item["id"], upload_target, True, None)
                    _sc = f"({success + 1}" + (f"/{self.target_selesai}" if self.target_selesai > 0 else "") + ")"
                    self.log(f"✅ {_pn} — Shopee ✓  {_sc}")
                    UploadStatsRepo.record(self.device_serial, "shopee")
                    _shopee_notified[0] = True
                ok_shopee = self._run_shopee_only(item, excel_no, pre_watch_fn=_notify_shopee_done)
                ok_tiktok = None

            # Log selesai per item
            dlog(self.device_serial, f"item {excel_no} — SELESAI")

            if not _shopee_notified[0]:
                self._finalize_status(item["id"], upload_target, ok_shopee, ok_tiktok)

            if upload_target == "shopee_tiktok":
                if ok_shopee: shopee_ok   += 1
                else:         shopee_fail += 1
                if ok_tiktok: tiktok_ok   += 1
                else:         tiktok_fail += 1
            elif upload_target == "tiktok_retry":
                if ok_tiktok: tiktok_ok   += 1
                else:         tiktok_fail += 1
            else:
                if ok_shopee: shopee_ok   += 1
                else:         shopee_fail += 1

            if upload_target == "shopee_tiktok":
                item_ok = ok_shopee or ok_tiktok
            elif upload_target == "tiktok_retry":
                item_ok = ok_tiktok
            else:
                item_ok = ok_shopee

            p_name = ProjectRepo.get_by_id(self.project_id).get("name", "")
            s_count = f"({success + (1 if item_ok else 0)}" + (f"/{self.target_selesai}" if self.target_selesai > 0 else "") + ")"
            if item_ok:
                success += 1
                if upload_target == "shopee_tiktok":
                    icon = "✅" if (ok_shopee and ok_tiktok) else "⚠️"
                    self.log(f"{icon} {p_name} — TikTok {'✓' if ok_tiktok else '✗'}  Shopee {'✓' if ok_shopee else '✗'}  {s_count}")
                    if ok_tiktok:  UploadStatsRepo.record(self.device_serial, "tiktok")
                    if ok_shopee:  UploadStatsRepo.record(self.device_serial, "shopee")
                elif upload_target == "tiktok_retry":
                    self.log(f"✅ {p_name} — TikTok ✓  {s_count}")
                    UploadStatsRepo.record(self.device_serial, "tiktok")
                else:
                    if not _shopee_notified[0]:
                        self.log(f"✅ {p_name} — Shopee ✓  {s_count}")
                        UploadStatsRepo.record(self.device_serial, "shopee")
            else:
                error += 1
                if upload_target == "shopee_tiktok":
                    self.log(f"❌ {p_name} — TikTok {'✓' if ok_tiktok else '✗'}  Shopee {'✓' if ok_shopee else '✗'}")
                elif upload_target == "tiktok_retry":
                    self.log(f"❌ {p_name} — TikTok ✗")
                else:
                    self.log(f"❌ {p_name} — Shopee ✗")

            # Jeda antar video — pakai jeda_tiktok_shopee dari setting
            _remaining = [x for x in items[_idx+1:] if x.get("video_result","").strip()]
            _target_reached = self.target_selesai > 0 and success >= self.target_selesai
            if not self.is_stopped() and not _target_reached and _remaining and self.jeda_tiktok_shopee > 0:
                jeda = self.jeda_tiktok_shopee
                self.log(f"━━━ Jeda {jeda}s sebelum video berikutnya ━━━")
                dlog(self.device_serial, f"item {excel_no} — Jeda antar video {jeda}s")
                _interruptible_sleep(jeda, self.is_stopped, self.log)

        # Final
        if self.is_stopped():
            final = "berhenti"
        elif self.target_selesai > 0 and success >= self.target_selesai:
            final = "selesai"
        elif error == 0:
            final = "selesai"
        else:
            final = "berhenti"

        # Auto-rotate off — 1 connect singkat
        try:
            d_end = self._connect()
            d_end.shell("settings put system accelerometer_rotation 0")
            _safe_disconnect(d_end); d_end = None
        except: pass

        ProjectRepo.update_status(self.project_id, final)

        total = success + error
        self.log(f"━━━━━━━━━━ Ringkasan ━━━━━━━━━━")
        if upload_target == "shopee_tiktok":
            self.log(f"🎵 TikTok  ✅ {tiktok_ok}/{total}  ❌ {tiktok_fail}/{total}")
            self.log(f"🛍 Shopee  ✅ {shopee_ok}/{total}  ❌ {shopee_fail}/{total}")
        elif upload_target == "tiktok_retry":
            self.log(f"🎵 TikTok  ✅ {tiktok_ok}/{total}  ❌ {tiktok_fail}/{total}")
        elif upload_target == "shopee":
            self.log(f"🛍 Shopee  ✅ {shopee_ok}/{total}  ❌ {shopee_fail}/{total}")
        else:
            self.log(f"🛍 Shopee  ✅ {shopee_ok}/{total}  ❌ {shopee_fail}/{total}")
        return success, error

    def _run_tiktok_shopee(self, item: dict, excel_no: int) -> tuple[bool, bool]:
        # Connect SEKALI — reuse untuk TikTok + Shopee + cleanup
        dlog(self.device_serial, f"START item {excel_no} — TikTok & Shopee")
        try:
            d = self._connect()
        except Exception:
            return False, False

        ok_tiktok = False
        ok_shopee = False
        try:
            # 1 — TikTok
            ok_tiktok, err_tiktok = tiktok_only.run_upload_flow(
                d                = d,
                caption          = item.get("caption_tiktok", ""),
                product          = item.get("product_shopee", ""),
                video_url        = item.get("video_result", ""),
                item_id          = excel_no,
                caption_tiktok   = item.get("caption_tiktok", ""),
                link_tiktok      = item.get("link_tiktok", ""),
                keranjang_tiktok = item.get("keranjang_tiktok", ""),
                log_fn           = self.log,
                folder_sound     = self.folder_sound,
                serial           = self.device_serial,
                max_retry        = self.max_retry,
                mix_sound        = self.mix_sound,
                search_query     = self._pick_search_query(),
            )
            VideoRepo.update_status_by_project(
                self.project_id, item["id"], "proses",
                status_tiktok="selesai" if ok_tiktok else "error",
            )
            if not ok_tiktok and err_tiktok:
                VideoRepo.save_error_message(self.project_id, item["id"], error_tiktok=err_tiktok)

            # 2 — Delay 30s TikTok → Shopee
            self.log(f"━━━━━━━━━━ Jeda TikTok → Shopee ━━━━━━━━━━")
            self.log(f"⏱ Jeda 30s sebelum Shopee...")
            dlog(self.device_serial, f"item {excel_no} — Jeda 30s TikTok→Shopee")
            _interruptible_sleep(self.jeda_tiktok_shopee, self.is_stopped, self.log)
            if self.is_stopped(): return ok_tiktok, False

            # 3 — Shopee
            ok_shopee, err_shopee = shopee_only.run_upload_flow(
                d             = d,
                caption       = item.get("caption_shopee", ""),
                product       = item.get("product_shopee", ""),
                video_url     = item.get("video_result", ""),
                item_id       = excel_no,
                log_fn        = self.log,
                watch_min     = self.watch_min,
                watch_max     = self.watch_max,
                serial        = self.device_serial,
                shopee_clone  = self.shopee_clone,
                use_mix_sound = self.mix_sound,
                fast_mode     = self.fast_mode,
            )
            VideoRepo.update_status_by_project(
                self.project_id, item["id"], "proses",
                status_shopee="selesai" if ok_shopee else "error",
            )
            if not ok_shopee and err_shopee:
                VideoRepo.save_error_message(self.project_id, item["id"], error_shopee=err_shopee)

        except Exception as e:
            self.log(format_error(e, f"Upload [{excel_no}]"))
        finally:
            # Cleanup HP pakai d yang sama
            if self.auto_hapus_cache:
                try:
                    cleanup_hp(d, excel_no, "shopee_tiktok", self.log)
                except Exception as e:
                    self.log(f"⚠ Cleanup HP error: {e}")
            # Destroy d → wait_finished mati
            _safe_disconnect(d); d = None

        return ok_shopee, ok_tiktok

    def _run_tiktok_only(self, item: dict, excel_no: int) -> bool:
        try:
            d = self._connect()
        except Exception:
            return False
        ok = False
        try:
            ok, err = tiktok_only.run_upload_flow(
                d                = d,
                caption          = item.get("caption_tiktok", ""),
                product          = item.get("product_shopee", ""),
                video_url        = item.get("video_result", ""),
                item_id          = excel_no,
                caption_tiktok   = item.get("caption_tiktok", ""),
                link_tiktok      = item.get("link_tiktok", ""),
                keranjang_tiktok = item.get("keranjang_tiktok", ""),
                log_fn           = self.log,
                folder_sound     = self.folder_sound,
                serial           = self.device_serial,
                is_retry         = True,
                max_retry        = self.max_retry,
                mix_sound        = self.mix_sound,
                search_query     = self._pick_search_query(),
            )
            if not ok and err:
                VideoRepo.save_error_message(self.project_id, item["id"], error_tiktok=err)
        except Exception as e:
            self.log(format_error(e, f"TikTok [{excel_no}]"))
        finally:
            if self.auto_hapus_cache:
                try:
                    cleanup_hp(d, excel_no, "tiktok", self.log)
                except Exception as e:
                    self.log(f"⚠ Cleanup HP error: {e}")
            _safe_disconnect(d); d = None
        return ok

    def _run_shopee_only(self, item: dict, excel_no: int, pre_watch_fn=None) -> bool:
        try:
            d = self._connect()
        except Exception:
            return False
        ok = False
        try:
            ok, err = shopee_only.run_upload_flow(
                d             = d,
                caption       = item.get("caption_shopee", ""),
                product       = item.get("product_shopee", ""),
                video_url     = item.get("video_result", ""),
                item_id       = excel_no,
                log_fn        = self.log,
                watch_min     = self.watch_min,
                watch_max     = self.watch_max,
                is_retry      = True,
                folder_sound  = self.folder_sound,
                shopee_clone  = self.shopee_clone,
                use_mix_sound = self.mix_sound,
                pre_watch_fn  = pre_watch_fn,
                fast_mode     = self.fast_mode,
            )
            if not ok and err:
                VideoRepo.save_error_message(self.project_id, item["id"], error_shopee=err)
        except Exception as e:
            self.log(format_error(e, f"Shopee [{excel_no}]"))
        finally:
            if self.auto_hapus_cache:
                try:
                    cleanup_hp(d, excel_no, "shopee", self.log)
                except Exception as e:
                    self.log(f"⚠ Cleanup HP error: {e}")
            _safe_disconnect(d); d = None
        return ok

    def _finalize_status(self, video_id: int, upload_target: str,
                          ok_shopee: bool, ok_tiktok):
        if upload_target == "shopee_tiktok":
            overall = "selesai" if (ok_shopee or ok_tiktok) else "error"
            VideoRepo.update_status_by_project(
                self.project_id, video_id, overall,
                status_shopee="selesai" if ok_shopee else "error",
                status_tiktok="selesai" if ok_tiktok else "error",
            )
        elif upload_target == "tiktok_retry":
            # Retry tiktok: hanya update tiktok, shopee tidak disentuh
            overall = "selesai" if ok_tiktok else "error"
            VideoRepo.update_status_by_project(
                self.project_id, video_id, overall,
                status_tiktok="selesai" if ok_tiktok else "error",
            )
        else:
            # shopee / shopee retry: hanya update shopee, tiktok tidak disentuh
            overall = "selesai" if ok_shopee else "error"
            VideoRepo.update_status_by_project(
                self.project_id, video_id, overall,
                status_shopee="selesai" if ok_shopee else "error",
            )
