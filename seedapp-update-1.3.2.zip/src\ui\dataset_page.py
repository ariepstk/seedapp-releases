"""
Dataset Page - List dataset & detail isi video
"""

import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView,
    QDialog, QLineEdit, QTextEdit, QMessageBox, QFileDialog,
    QStackedWidget, QMenu, QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QCursor

from src.core.database import DatasetRepo, VideoRepo


# ──────────────────────────────────────────────────
# Clickable Frame (aman dari segfault)
# ──────────────────────────────────────────────────
class ClickableFrame(QFrame):
    clicked = pyqtSignal()
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)


# ──────────────────────────────────────────────────
# Dialog Tambah/Edit Dataset
# ──────────────────────────────────────────────────
class DatasetDialog(QDialog):
    def __init__(self, parent=None, dataset: dict = None):
        super().__init__(parent)
        self.dataset = dataset
        self.setWindowTitle("Tambah Dataset" if not dataset else "Edit Dataset")
        self.setMinimumSize(440, 220)
        self._build()

    def _build(self):
        from src.ui.styles import get_dialog_style
        from src.ui.main_window import current_theme
        self.setStyleSheet(get_dialog_style(current_theme()))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        layout.addWidget(QLabel("Nama Dataset"))
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Contoh: Data 01")
        if self.dataset:
            self.name_input.setText(self.dataset.get('name', ''))
        layout.addWidget(self.name_input)

        layout.addWidget(QLabel("Deskripsi (opsional)"))
        self.desc_input = QLineEdit()
        self.desc_input.setPlaceholderText("Deskripsi singkat...")
        if self.dataset:
            self.desc_input.setText(self.dataset.get('description', ''))
        layout.addWidget(self.desc_input)

        layout.addSpacing(16)
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        cancel_btn = QPushButton("Batal")
        cancel_btn.setObjectName("btnSecondary")
        cancel_btn.clicked.connect(self.reject)
        cancel_btn.setFixedSize(90, 36)

        save_btn = QPushButton("Simpan")
        save_btn.setObjectName("btnPrimary")
        save_btn.clicked.connect(self._save)
        save_btn.setFixedSize(90, 36)

        btn_row.addWidget(cancel_btn)
        btn_row.addSpacing(8)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

    def _save(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Error", "Nama dataset tidak boleh kosong!")
            return
        self.result_name = name
        self.result_desc = self.desc_input.text().strip()
        self.accept()


# ──────────────────────────────────────────────────
# Dataset List Page
# ──────────────────────────────────────────────────
class DatasetListPage(QWidget):
    open_dataset = pyqtSignal(int)  # dataset_id

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Page header bar ──
        hdr_frame = QFrame(); hdr_frame.setObjectName("pageHeader"); hdr_frame.setFixedHeight(64)
        hdr_lay = QHBoxLayout(hdr_frame); hdr_lay.setContentsMargins(28, 0, 28, 0)
        title = QLabel("Dataset Video"); title.setObjectName("pageTitle")
        hdr_lay.addWidget(title); hdr_lay.addStretch()
        add_btn = QPushButton("+ Tambah"); add_btn.setObjectName("btnPrimary")
        add_btn.clicked.connect(self._add_dataset); hdr_lay.addWidget(add_btn)
        layout.addWidget(hdr_frame)
        div = QFrame(); div.setFixedHeight(1); div.setObjectName("headerDivider")
        layout.addWidget(div)

        # ── Body ──
        body = QWidget()
        body_lay = QVBoxLayout(body); body_lay.setContentsMargins(28, 16, 28, 16); body_lay.setSpacing(12)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")

        self.list_container = QWidget()
        self.list_layout = QVBoxLayout(self.list_container)
        self.list_layout.setSpacing(6)
        self.list_layout.setContentsMargins(0, 0, 0, 0)
        self.list_layout.addStretch()

        scroll.setWidget(self.list_container)
        body_lay.addWidget(scroll)
        layout.addWidget(body, 1)

        self.refresh()

    def refresh(self):
        while self.list_layout.count() > 1:
            item = self.list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        datasets = DatasetRepo.get_all()

        if not datasets:
            empty = QLabel("Belum ada dataset. Klik '+ Tambah' untuk membuat dataset baru.")
            empty.setObjectName("itemMeta")
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.list_layout.insertWidget(0, empty)
            return

        for i, ds in enumerate(datasets):
            row = self._make_row(i + 1, ds)
            self.list_layout.insertWidget(self.list_layout.count() - 1, row)

    def _make_row(self, no: int, ds: dict) -> QFrame:
        frame = ClickableFrame(); frame.setObjectName("listItem"); frame.setFixedHeight(56)
        frame.clicked.connect(lambda did=ds["id"]: self.open_dataset.emit(did))
        row = QHBoxLayout(frame); row.setContentsMargins(12, 0, 12, 0); row.setSpacing(10)

        # Icon
        icon_f = QFrame(); icon_f.setObjectName("projectIcon"); icon_f.setFixedSize(36, 36)
        icon_f.setStyleSheet("QFrame#projectIcon { background:transparent; border:none; }")
        il = QHBoxLayout(icon_f); il.setContentsMargins(0, 0, 0, 0)
        ic = QLabel("📋"); ic.setStyleSheet("font-size:20px; background:transparent; border:none;")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter); il.addWidget(ic)

        # Info
        info_col = QVBoxLayout(); info_col.setSpacing(2)
        name_lbl = QLabel(f"{no}. {ds['name']}"); name_lbl.setObjectName("itemTitle")
        meta_lbl = QLabel(f"Dibuat: {ds.get('created_at', '')[:10]}"); meta_lbl.setObjectName("itemMeta")
        info_col.addWidget(name_lbl); info_col.addWidget(meta_lbl)

        # Stats — style sama seperti project page
        total_col = QVBoxLayout(); total_col.setSpacing(0)
        total_val = QLabel(str(ds.get("total_video", 0)))
        total_val.setStyleSheet("font-size:15px; font-weight:700; background:transparent; border:none;")
        total_val.setAlignment(Qt.AlignmentFlag.AlignCenter)
        total_lbl = QLabel("Total Video")
        total_lbl.setObjectName("itemMeta"); total_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        total_col.addWidget(total_val); total_col.addWidget(total_lbl)

        # Menu button saja (klik row = buka)
        menu_btn = QPushButton("⋮"); menu_btn.setObjectName("btnIcon"); menu_btn.setFixedWidth(30)
        menu_btn.clicked.connect(lambda _, d=ds, b=menu_btn: self._show_menu(d, b))

        row.addWidget(icon_f); row.addLayout(info_col, 2); row.addStretch()
        row.addLayout(total_col); row.addSpacing(20)
        row.addWidget(menu_btn)

        return frame

    def _show_menu(self, ds: dict, btn: QPushButton):
        menu = QMenu(self)
        menu.addAction("✏️ Edit", lambda: self._edit_dataset(ds))
        menu.addSeparator()
        menu.addAction("🗑️ Hapus", lambda: self._delete_dataset(ds))
        menu.exec(btn.mapToGlobal(btn.rect().bottomLeft()))

    def _add_dataset(self):
        dlg = DatasetDialog(self)
        if dlg.exec():
            DatasetRepo.create(dlg.result_name, dlg.result_desc)
            self.refresh()

    def _edit_dataset(self, ds: dict):
        dlg = DatasetDialog(self, ds)
        if dlg.exec():
            DatasetRepo.update(ds['id'], dlg.result_name, dlg.result_desc)
            self.refresh()

    def _delete_dataset(self, ds: dict):
        reply = QMessageBox.question(
            self, "Hapus Dataset",
            f"Hapus dataset '{ds['name']}'?\nSemua data video di dalamnya akan ikut terhapus.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            DatasetRepo.delete(ds['id'])
            self.refresh()


# ──────────────────────────────────────────────────
# Dataset Detail Page
# ──────────────────────────────────────────────────
class DatasetDetailPage(QWidget):
    go_back = pyqtSignal()

    COLUMNS = ['No', 'Judul (Product)', 'Caption Shopee', 'Caption TikTok',
               'Link TikTok', 'Keranjang TikTok', 'Video Result', 'Aksi']
    COL_WIDTHS = [40, 200, 260, 260, 160, 120, 160, 90]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.dataset_id = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Page header bar ──
        hdr_frame = QFrame(); hdr_frame.setObjectName("pageHeader"); hdr_frame.setFixedHeight(64)
        hdr_lay = QHBoxLayout(hdr_frame); hdr_lay.setContentsMargins(28, 0, 28, 0); hdr_lay.setSpacing(10)
        back_btn = QPushButton("← Kembali"); back_btn.setObjectName("btnSecondary")
        back_btn.clicked.connect(self.go_back.emit); back_btn.setFixedWidth(100)
        self.title_lbl = QLabel("Dataset"); self.title_lbl.setObjectName("pageTitle")
        self.total_lbl = QLabel("0 Video"); self.total_lbl.setObjectName("itemMeta")
        import_btn = QPushButton("⬆ Import Excel"); import_btn.setObjectName("btnSecondary")
        import_btn.clicked.connect(self._import_excel)
        self.delete_sel_btn = QPushButton("🗑️ Hapus Terpilih"); self.delete_sel_btn.setObjectName("btnDanger")
        self.delete_sel_btn.clicked.connect(self._delete_selected); self.delete_sel_btn.setEnabled(False)
        hdr_lay.addWidget(back_btn); hdr_lay.addSpacing(12)
        hdr_lay.addWidget(self.title_lbl); hdr_lay.addSpacing(8)
        hdr_lay.addWidget(self.total_lbl); hdr_lay.addStretch()
        hdr_lay.addWidget(import_btn); hdr_lay.addWidget(self.delete_sel_btn)
        layout.addWidget(hdr_frame)
        div = QFrame(); div.setFixedHeight(1); div.setObjectName("headerDivider")
        layout.addWidget(div)

        # ── Body ──
        body = QWidget()
        body_lay = QVBoxLayout(body); body_lay.setContentsMargins(28, 16, 28, 16); body_lay.setSpacing(14)
        layout.addWidget(body, 1)

        # Table
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(False)
        self.table.itemSelectionChanged.connect(self._on_selection_changed)

        for i, w in enumerate(self.COL_WIDTHS):
            self.table.setColumnWidth(i, w)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        body_lay.addWidget(self.table)

    def load_dataset(self, dataset_id: int):
        self.dataset_id = dataset_id
        ds = DatasetRepo.get_by_id(dataset_id)
        if ds:
            self.title_lbl.setText(f"Dataset : {ds['name']}")
        self._load_items()

    def _load_items(self, status_filter: str = 'semua'):
        items = VideoRepo.get_by_dataset(self.dataset_id, status_filter)
        self.total_lbl.setText(f"Total: {len(items)} Video")
        self.table.setRowCount(0)

        for item in items:
            row = self.table.rowCount()
            self.table.insertRow(row)

            def cell(text, align=Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft):
                it = QTableWidgetItem(str(text) if text else '')
                it.setTextAlignment(align)
                return it

            self.table.setItem(row, 0, cell(item.get('no', ''), Qt.AlignmentFlag.AlignCenter))
            self.table.setItem(row, 1, cell(item.get('product_shopee', '')))
            self.table.setItem(row, 2, cell(item.get('caption_shopee', '')))
            self.table.setItem(row, 3, cell(item.get('caption_tiktok', '')))
            self.table.setItem(row, 4, cell(item.get('link_tiktok', '')))
            self.table.setItem(row, 5, cell(item.get('keranjang_tiktok', '')))

            vr = item.get('video_result', '')
            vr_item = QTableWidgetItem(vr[:40] + '...' if len(vr) > 40 else vr)
            vr_item.setToolTip(vr)
            self.table.setItem(row, 6, vr_item)

            # Action cell
            action_widget = QWidget()
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(4, 2, 4, 2)
            action_layout.setSpacing(4)

            del_btn = QPushButton("Hapus")
            del_btn.setObjectName("btnIconDanger")
            del_btn.setFixedHeight(26)
            del_btn.clicked.connect(lambda _, iid=item['id']: self._delete_item(iid))
            action_layout.addWidget(del_btn)
            action_layout.addStretch()

            self.table.setCellWidget(row, 7, action_widget)
            self.table.setRowHeight(row, 42)

            # Store item id
            self.table.item(row, 0).setData(Qt.ItemDataRole.UserRole, item['id'])

    def _on_selection_changed(self):
        has_sel = bool(self.table.selectedItems())
        self.delete_sel_btn.setEnabled(has_sel)

    def _import_excel(self):
        try:
            import openpyxl
        except ImportError:
            QMessageBox.warning(self, "Error",
                "openpyxl belum terinstall!\nJalankan: pip install openpyxl")
            return

        path, _ = QFileDialog.getOpenFileName(
            self, "Pilih File Excel", "", "Excel Files (*.xlsx *.xls)"
        )
        if not path:
            return

        try:
            wb = openpyxl.load_workbook(path, data_only=True)
            ws = wb.active

            items = []
            headers = [str(c.value).strip().lower() if c.value else '' for c in next(ws.iter_rows(min_row=1, max_row=1))]

            def col_idx(name):
                try: return headers.index(name.lower())
                except ValueError: return -1

            no_i   = col_idx('no')
            cs_i   = col_idx('caption_shopee')
            ps_i   = col_idx('product_shopee')
            ct_i   = col_idx('caption_tiktok')
            lt_i   = col_idx('link_tiktok')
            kt_i   = col_idx('keranjang_tiktok')
            vr_i   = col_idx('video_result')

            for row in ws.iter_rows(min_row=2, values_only=True):
                if not any(row):
                    continue
                def g(i): return str(row[i]).strip() if i >= 0 and i < len(row) and row[i] is not None else ''
                items.append({
                    'no': g(no_i),
                    'caption_shopee': g(cs_i),
                    'product_shopee': g(ps_i),
                    'caption_tiktok': g(ct_i),
                    'link_tiktok': g(lt_i),
                    'keranjang_tiktok': g(kt_i),
                    'video_result': g(vr_i),
                })

            if not items:
                QMessageBox.warning(self, "Error", "Tidak ada data yang bisa diimport!")
                return

            reply = QMessageBox.question(
                self, "Import Excel",
                f"Akan mengimport {len(items)} baris data.\n"
                f"Data lama akan diganti. Lanjutkan?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                VideoRepo.bulk_insert(self.dataset_id, items)
                self._load_items()
                QMessageBox.information(self, "Berhasil",
                    f"{len(items)} data berhasil diimport!")

        except Exception as e:
            QMessageBox.critical(self, "Error Import", str(e))

    def _delete_item(self, item_id: int):
        reply = QMessageBox.question(self, "Hapus", "Hapus data ini?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            VideoRepo.delete(item_id)
            self._load_items()

    def _delete_selected(self):
        rows = set(item.row() for item in self.table.selectedItems())
        if not rows:
            return
        reply = QMessageBox.question(self, "Hapus Terpilih",
            f"Hapus {len(rows)} data terpilih?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            for row in rows:
                item = self.table.item(row, 0)
                if item:
                    item_id = item.data(Qt.ItemDataRole.UserRole)
                    VideoRepo.delete(item_id)
            self._load_items()


# ──────────────────────────────────────────────────
# Dataset Page (wrapper dengan stack)
# ──────────────────────────────────────────────────
class DatasetPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.stack = QStackedWidget()

        self.list_page = DatasetListPage()
        self.detail_page = DatasetDetailPage()

        self.stack.addWidget(self.list_page)
        self.stack.addWidget(self.detail_page)

        self.list_page.open_dataset.connect(self._open_detail)
        self.detail_page.go_back.connect(self._go_back)

        layout.addWidget(self.stack)

    def _open_detail(self, dataset_id: int):
        self.detail_page.load_dataset(dataset_id)
        self.stack.setCurrentWidget(self.detail_page)

    def _go_back(self):
        self.list_page.refresh()
        self.stack.setCurrentWidget(self.list_page)

    def refresh(self):
        self.list_page.refresh()
        self.stack.setCurrentWidget(self.list_page)
