"""
SeedApp License Checker — BYPASS MODE
Sistem license dilepas. Semua function return valid=True.
Folder & file tetap dipertahankan untuk backward compatibility.
"""
import os, json, hashlib, subprocess, threading
from datetime import datetime, timedelta

# ── Konfigurasi ──────────────────────────────────────────
# License system di-bypass — server tidak dipanggil sama sekali.
LICENSE_SERVER = "https://web-production-bb164.up.railway.app"
LICENSE_FILE   = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "license.dat")
LICENSE_FILE   = os.path.normpath(LICENSE_FILE)
GRACE_DAYS     = 999999   # bypass — gak penting lagi
SERVER_TIMEOUT = 5

LICENSE_BYPASS = True  # ← FLAG: True = bypass license, False = normal license check


def get_hwid() -> str:
    """Generate HWID unik dari CPU + Disk serial."""
    try:
        cpu  = subprocess.check_output("wmic cpu get ProcessorId", shell=True, stderr=subprocess.DEVNULL).decode()
        cpu  = [l.strip() for l in cpu.splitlines() if l.strip() and l.strip() != "ProcessorId"][0]
        disk = subprocess.check_output("wmic diskdrive get SerialNumber", shell=True, stderr=subprocess.DEVNULL).decode()
        disk = [l.strip() for l in disk.splitlines() if l.strip() and l.strip() != "SerialNumber"][0]
        raw  = f"{cpu}|{disk}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]
    except Exception:
        # Fallback: pakai hostname + username
        import platform, getpass
        raw = f"{platform.node()}|{getpass.getuser()}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]


def _load() -> dict:
    try:
        with open(LICENSE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data: dict):
    with open(LICENSE_FILE, "w") as f:
        json.dump(data, f)


def activate(key: str) -> tuple[bool, str]:
    """Aktivasi license key. BYPASS MODE — selalu sukses tanpa hit server."""
    if LICENSE_BYPASS:
        hwid = get_hwid()
        _save({
            "key":          (key or "BYPASS").strip().upper(),
            "hwid":         hwid,
            "activated_at": datetime.now().isoformat(),
            "last_checked": datetime.now().isoformat(),
            "status":       "active"
        })
        return True, "Aktivasi berhasil (bypass mode)"

    # ── Original code (kalau bypass dimatikan) ──
    import requests
    hwid = get_hwid()
    try:
        r = requests.post(
            f"{LICENSE_SERVER}/api/activate",
            json={"key": key.strip().upper(), "hwid": hwid},
            timeout=10
        )
        if r.status_code == 200:
            _save({
                "key":          key.strip().upper(),
                "hwid":         hwid,
                "activated_at": datetime.now().isoformat(),
                "last_checked": datetime.now().isoformat(),
                "status":       "active"
            })
            return True, "Aktivasi berhasil!"
        else:
            detail = r.json().get("detail", "Gagal aktivasi")
            return False, detail
    except requests.exceptions.ConnectionError:
        return False, "Tidak bisa terhubung ke server. Periksa koneksi internet."
    except Exception as e:
        return False, str(e)


def _server_validate(key: str, hwid: str) -> tuple[bool, str]:
    """Cek ke server. Return (valid, message) atau (None, 'timeout') jika tidak bisa dihubungi."""
    import requests
    try:
        r = requests.post(
            f"{LICENSE_SERVER}/api/validate",
            json={"key": key, "hwid": hwid},
            timeout=SERVER_TIMEOUT
        )
        data = r.json()
        return data.get("valid", False), data.get("message", "")
    except Exception:
        return None, "timeout"  # None = tidak bisa dihubungi


def check_license() -> tuple[bool, str]:
    """
    Cek license saat startup. BYPASS MODE — selalu return True.
    """
    if LICENSE_BYPASS:
        return True, "ok"

    # ── Original code (kalau bypass dimatikan) ──
    data = _load()
    if not data or not data.get("key"):
        return False, "not_activated"

    hwid = get_hwid()
    if data.get("hwid") != hwid:
        return False, "HWID tidak cocok. License terdaftar di PC lain."

    # Selalu cek server setiap buka app
    valid, msg = _server_validate(data["key"], hwid)

    if valid is None:
        # Server tidak bisa dihubungi → grace period
        last_ok = data.get("last_checked") or data.get("activated_at")
        if last_ok:
            try:
                days_since = (datetime.now() - datetime.fromisoformat(last_ok)).days
                if days_since > GRACE_DAYS:
                    return False, f"Tidak bisa terhubung ke server selama {days_since} hari. Hubungi admin."
            except Exception:
                pass
        return True, "offline_grace"
    elif not valid:
        data["status"] = "inactive"
        _save(data)
        return False, msg
    else:
        data["last_checked"] = datetime.now().isoformat()
        data["status"]       = "active"
        _save(data)
        return True, "ok"


def background_check():
    """Jalankan validasi server di background thread. BYPASS MODE — no-op."""
    if LICENSE_BYPASS:
        return
    def _run():
        data = _load()
        if not data or not data.get("key"):
            return
        hwid  = get_hwid()
        valid, msg = _server_validate(data["key"], hwid)
        if valid is False:
            data["status"]       = "inactive"
            data["last_checked"] = datetime.now().isoformat()
            _save(data)
        elif valid is True:
            data["status"]       = "active"
            data["last_checked"] = datetime.now().isoformat()
            _save(data)
    t = threading.Thread(target=_run, daemon=True)
    t.start()


def is_activated() -> bool:
    """Quick check: apakah sudah pernah aktivasi? BYPASS MODE — selalu True."""
    if LICENSE_BYPASS:
        return True
    data = _load()
    return bool(data.get("key") and data.get("hwid"))


def get_license_info() -> dict:
    return _load()
