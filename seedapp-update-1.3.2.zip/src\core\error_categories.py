"""
Error Categorization — SeedApp
Kategorisasi error untuk macro runner agar mudah di-debug dan di-monitor.
"""


class ErrorCategory:
    NETWORK = "network"              # Download gagal, timeout, no internet
    DEVICE_DISCONNECTED = "device"   # ADB disconnect, uiautomator connection lost
    UI_NOT_FOUND = "ui"              # Element tidak ditemukan di layar
    APP_CRASH = "app_crash"          # App force close / ANR
    FILE_ERROR = "file"              # File corrupt, disk full, permission
    RATE_LIMIT = "rate_limit"        # Platform rate limit (GDrive, Shopee, TikTok)
    UNKNOWN = "unknown"              # Tidak diketahui


# Keyword → kategori (urutan penting, match pertama menang)
# ATURAN: pattern yang lebih spesifik harus di ATAS pattern yang lebih umum
_ERROR_PATTERNS = [
    # Device disconnected (cek dulu sebelum network, karena beberapa overlap)
    ("device not found", ErrorCategory.DEVICE_DISCONNECTED),
    ("Device offline", ErrorCategory.DEVICE_DISCONNECTED),
    ("uiautomator", ErrorCategory.DEVICE_DISCONNECTED),
    ("adb server", ErrorCategory.DEVICE_DISCONNECTED),
    ("USB disconnect", ErrorCategory.DEVICE_DISCONNECTED),
    ("Connection reset by peer", ErrorCategory.DEVICE_DISCONNECTED),
    ("SessionBrokenError", ErrorCategory.DEVICE_DISCONNECTED),

    # UI not found (cek sebelum "timeout" agar "UI timeout" tidak salah kategorisasi)
    ("UiObjectNotFoundError", ErrorCategory.UI_NOT_FOUND),
    ("Gallery tidak ditemukan", ErrorCategory.UI_NOT_FOUND),
    ("Element not found", ErrorCategory.UI_NOT_FOUND),
    ("Gagal buka gallery", ErrorCategory.UI_NOT_FOUND),
    ("Produk tidak ditemukan", ErrorCategory.UI_NOT_FOUND),
    ("Video tidak ditemukan", ErrorCategory.UI_NOT_FOUND),
    ("tombol tidak ditemukan", ErrorCategory.UI_NOT_FOUND),

    # App crash
    ("force close", ErrorCategory.APP_CRASH),
    ("ANR", ErrorCategory.APP_CRASH),
    ("app not running", ErrorCategory.APP_CRASH),
    ("App crash", ErrorCategory.APP_CRASH),
    ("stopped unexpectedly", ErrorCategory.APP_CRASH),

    # Rate limit (cek sebelum network karena beberapa overlap dengan HTTP errors)
    ("rate limit", ErrorCategory.RATE_LIMIT),
    ("many accesses", ErrorCategory.RATE_LIMIT),
    ("retrieve file url", ErrorCategory.RATE_LIMIT),
    ("Too Many Requests", ErrorCategory.RATE_LIMIT),
    ("status 429", ErrorCategory.RATE_LIMIT),
    ("HTTP 429", ErrorCategory.RATE_LIMIT),
    ("Gdown rate limit", ErrorCategory.RATE_LIMIT),

    # File errors
    ("File terlalu kecil", ErrorCategory.FILE_ERROR),
    ("corrupt", ErrorCategory.FILE_ERROR),
    ("No space left", ErrorCategory.FILE_ERROR),
    ("Permission denied", ErrorCategory.FILE_ERROR),
    ("FileNotFoundError", ErrorCategory.FILE_ERROR),

    # Network (paling bawah karena pattern "timeout" broad — hanya match jika tidak ada yang lebih spesifik)
    ("ConnectionError", ErrorCategory.NETWORK),
    ("ConnectTimeout", ErrorCategory.NETWORK),
    ("ReadTimeout", ErrorCategory.NETWORK),
    ("HTTPSConnectionPool", ErrorCategory.NETWORK),
    ("Connection refused", ErrorCategory.NETWORK),
    ("Network is unreachable", ErrorCategory.NETWORK),
    ("Name or service not known", ErrorCategory.NETWORK),
    ("Download gagal", ErrorCategory.NETWORK),
    ("cannot connect", ErrorCategory.NETWORK),
    ("timeout", ErrorCategory.NETWORK),
]


def categorize_error(error: Exception | str) -> tuple[str, str]:
    """
    Kategorisasi error berdasarkan pesan error.

    Returns:
        (category, emoji_prefix) — misal ("network", "🌐")
    """
    err_str = str(error)
    err_lower = err_str.lower()

    for pattern, category in _ERROR_PATTERNS:
        if pattern.lower() in err_lower:
            return category, _CATEGORY_EMOJI.get(category, "❌")

    return ErrorCategory.UNKNOWN, "❌"


_CATEGORY_EMOJI = {
    ErrorCategory.NETWORK: "🌐",
    ErrorCategory.DEVICE_DISCONNECTED: "📱",
    ErrorCategory.UI_NOT_FOUND: "🔍",
    ErrorCategory.APP_CRASH: "💥",
    ErrorCategory.FILE_ERROR: "📁",
    ErrorCategory.RATE_LIMIT: "⏳",
    ErrorCategory.UNKNOWN: "❌",
}


_CATEGORY_HINT = {
    ErrorCategory.NETWORK: "Periksa koneksi internet atau URL video",
    ErrorCategory.DEVICE_DISCONNECTED: "Periksa kabel USB dan koneksi ADB",
    ErrorCategory.UI_NOT_FOUND: "App mungkin berubah layout, coba restart",
    ErrorCategory.APP_CRASH: "App crash, coba force stop dan mulai ulang",
    ErrorCategory.FILE_ERROR: "Periksa file video atau ruang disk",
    ErrorCategory.RATE_LIMIT: "Terlalu banyak request, tunggu beberapa menit",
    ErrorCategory.UNKNOWN: "Error tidak diketahui, cek log untuk detail",
}


def format_error(error: Exception | str, context: str = "") -> str:
    """Format error dengan kategori dan hint untuk log yang lebih informatif."""
    category, emoji = categorize_error(error)
    hint = _CATEGORY_HINT.get(category, "")
    err_str = str(error)

    # Potong pesan error yang terlalu panjang
    if len(err_str) > 200:
        err_str = err_str[:200] + "..."

    parts = [f"{emoji} [{category.upper()}]"]
    if context:
        parts.append(context + ":")
    parts.append(err_str)
    if hint:
        parts.append(f"→ {hint}")

    return " ".join(parts)
