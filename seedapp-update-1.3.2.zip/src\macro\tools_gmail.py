"""
Tools — Buat Gmail
Buat akun Gmail baru via aplikasi Gmail di Android.

Flow 14 step:
1. Buka Gmail
2. Tap profil kanan atas
3. Add another account
4. Google (sleep 3-5s)
5. Create account → For my personal use (coord)
6. First name + Tab + Last name + Next
7. Birth (Bulan dropdown) + Tab Day + Tab Year + Tab Enter Gender + Spasi + Next
8. Email username + Next
9. Password "1sampai10" + Next
10. Save password popup
11. Review → Next
12. Scroll 8x → I agree (coord) → wait 10-15s
13. Scroll 3x → Not now (coord)
14. Done → wait 10s → close app
"""

import time
import random
import string
import uiautomator2 as u2

GMAIL_PACKAGE = "com.google.android.gm"
WAIT_TIMEOUT = 10

# ─────────────── Random Indo Name + Gender Tag ───────────────
NAMES_M = [
    # Indonesia umum
    "Andi", "Budi", "Rizky", "Bayu", "Dimas", "Fajar", "Hendra", "Irfan",
    "Joko", "Krisna", "Lukman", "Made", "Nanda", "Oki", "Putra", "Rama",
    "Surya", "Teguh", "Umar", "Vino", "Wahyu", "Yoga", "Zaki", "Adi",
    "Bagus", "Cahyo", "Doni", "Eko", "Faisal", "Galih", "Hadi", "Ilham",
    "Jaya", "Kevin", "Lutfi", "Mukti", "Naufal", "Oscar", "Pandu", "Reza",
    "Satrio", "Toni", "Usman", "Vicky", "Wisnu", "Yusuf", "Zainul", "Arif",
    "Bima", "Aldi",
    # Variasi modern
    "Aditya", "Akmal", "Alvin", "Anggi", "Aris", "Arman", "Arya", "Bagas",
    "Bambang", "Beni", "Bintang", "Bobby", "Brian", "Burhan", "Candra", "Cecep",
    "Daffa", "Danang", "Daniel", "Darma", "David", "Dedi", "Denny", "Derry",
    "Dewa", "Didi", "Diki", "Dion", "Dwi", "Edi", "Edwin", "Egi",
    "Endang", "Erwin", "Evan", "Faiz", "Fakhri", "Fauzan", "Felix", "Ferdi",
    "Ferry", "Firman", "Frans", "Gading", "Gilang", "Gunawan", "Hafiz", "Hanif",
    "Harun", "Helmi", "Heri", "Iqbal", "Ivan", "Jamal", "Jefri", "Jonathan",
    # Arab-influenced
    "Abdul", "Ahmad", "Ali", "Amir", "Anwar", "Aziz", "Faiq", "Faruq",
    "Fathir", "Ghani", "Hakim", "Hamid", "Harits", "Hasan", "Husein", "Ibrahim",
    "Idris", "Imran", "Iskandar", "Ismail", "Jabir", "Jafar", "Junaid", "Kamal",
    "Khalid", "Latif", "Mahmud", "Malik", "Mansur", "Mahdi", "Mubarak", "Muhammad",
    "Mukhlis", "Nasir", "Nizam", "Nuh", "Omar", "Qasim", "Rafi", "Rahman",
    "Rasyid", "Ridho", "Rio", "Riyadi", "Roni", "Rudy", "Salman", "Samsul",
    # Jawa-Sunda-Bali
    "Sandi", "Sanjaya", "Saputra", "Sasongko", "Setyo", "Sigit", "Slamet", "Sofyan",
    "Sukma", "Suparman", "Suryadi", "Sutrisno", "Taufik", "Tegar", "Tirta", "Tomi",
    "Tri", "Wardana", "Wibawa", "Widodo", "Wira", "Yoga", "Yudha", "Zafar",
    "Zaenal", "Adit", "Aji", "Akbar", "Alex", "Alfan", "Alfian", "Algi",
    "Alif", "Aliando", "Alvaro", "Aman", "Andika", "Angga", "Antonius", "Apip",
    "Arie", "Arul", "Asep", "Awan", "Bara", "Baskara", "Basuki", "Boni",
    # Tambahan biar variatif
    "Caesar", "Cakra", "Catur", "Damar", "Daniel", "Darmawan", "Dean", "Dery",
    "Difa", "Dika", "Dirga", "Dito", "Dodo", "Dwiki", "Edo", "Ega",
    "Elang", "Elvin", "Erdin", "Erlangga", "Fadhil", "Fadli", "Faldi", "Faris",
    "Fariz", "Farrel", "Fauzi", "Fendi", "Frido", "Fuad", "Genta", "Gerry",
    "Glenn", "Hari", "Haris", "Hary", "Haziq", "Heru", "Hilman", "Iman",
    "Indra", "Iqro", "Jovan", "Kanda", "Kemal", "Kenzo", "Khairul", "Kiki",
    "Korn", "Kresna", "Lazuardi", "Leo", "Lintang", "Marco",
]

NAMES_F = [
    # Indonesia umum
    "Sari", "Dewi", "Indah", "Lia", "Mia", "Nia", "Putri", "Rina",
    "Siti", "Tina", "Vera", "Wati", "Yuni", "Zahra", "Anisa", "Bella",
    "Citra", "Diah", "Eka", "Fitri", "Galuh", "Hana", "Ika", "Jihan",
    "Kirana", "Laras", "Maya", "Novi", "Ovi", "Putu", "Qori", "Reni",
    "Salsa", "Tara", "Ulfa", "Vina", "Winda", "Yanti", "Zaskia", "Ayu",
    "Bunga", "Cinta", "Devi", "Endah", "Farah", "Gita", "Hesti", "Ira",
    "Kesya", "Aida",
    # Modern
    "Adelia", "Aira", "Alya", "Amalia", "Amanda", "Amelia", "Anastasia", "Andini",
    "Anggun", "Annisa", "Aprilia", "Arini", "Asri", "Astri", "Aulia", "Azizah",
    "Berliana", "Caca", "Cahaya", "Cantika", "Carla", "Cherry", "Cinta", "Clara",
    "Dahlia", "Dara", "Dea", "Della", "Desi", "Dian", "Diana", "Dinda",
    "Dini", "Diva", "Dyah", "Echa", "Elsa", "Emma", "Eva", "Evi",
    "Fanny", "Fatimah", "Felicia", "Fenny", "Feronika", "Fika", "Frida", "Gendis",
    "Hafsa", "Hafshah", "Hayati", "Ifa", "Ines", "Inggrid", "Intan", "Isabella",
    "Iswandari", "Jasmine", "Jelita", "Jenny", "Jessica", "Joana", "Julia", "Kanaya",
    # Arab-influenced
    "Aisyah", "Alia", "Amani", "Aminah", "Asma", "Azzahra", "Balqis", "Camelia",
    "Faiza", "Fadhilah", "Fairuz", "Fitria", "Hadiya", "Halimah", "Hamida", "Husna",
    "Iffah", "Ilma", "Inara", "Insyirah", "Iqlima", "Karima", "Khadija", "Khairiya",
    "Khaleeda", "Khalisa", "Latifah", "Maisarah", "Maleeha", "Maryam", "Mawar", "Mufida",
    "Munawaroh", "Munira", "Nabila", "Nadia", "Nadiya", "Naila", "Najla", "Najwa",
    "Najmi", "Nasya", "Nayla", "Nazwa", "Nida", "Nilam", "Nisa", "Nuraini",
    # Jawa-Sunda-Bali-modern campur
    "Olivia", "Oliviana", "Patricia", "Permata", "Prita", "Putri", "Qonita", "Rafifa",
    "Rahma", "Raisa", "Ramadhani", "Ranti", "Rara", "Rasti", "Rasyifa", "Ratih",
    "Ratu", "Rayya", "Regina", "Resti", "Retno", "Rezky", "Rika", "Risma",
    "Rita", "Rosa", "Rosalina", "Rosita", "Sabrina", "Safira", "Salma", "Salwa",
    "Sania", "Santi", "Sarah", "Sasa", "Selena", "Selly", "Septi", "Shafa",
    "Shania", "Shinta", "Sinta", "Sofi", "Sofia", "Sonya", "Stefani", "Steffi",
    "Suci", "Sulis", "Susi", "Syifa", "Tania", "Tania", "Tia", "Titi",
    # Tambahan biar variatif
    "Ulfah", "Umi", "Vania", "Velove", "Verena", "Viona", "Vivi", "Wanda",
    "Yasmin", "Yessi", "Yola", "Yuli", "Yulia", "Yulianti", "Yulita", "Zaira",
    "Zaina", "Zaskia", "Zia", "Zulfa", "Adisty", "Agnes", "Aisha", "Alfira",
    "Aliya", "Alma", "Amira", "Anika", "Annisa", "Arina", "Arsy", "Asha",
]

LAST_NAMES = [
    # Indonesia umum
    "Pratama", "Saputra", "Wijaya", "Hidayat", "Lestari", "Anggraini",
    "Permata", "Cahyani", "Kurniawan", "Setiawan", "Maulana", "Nugroho",
    "Susanto", "Hartono", "Pranata", "Ramadhan", "Hakim", "Wibowo",
    "Putri", "Anggara",
    # Jawa
    "Adi", "Adinata", "Adriansyah", "Aditama", "Adyatma", "Aji", "Aksara", "Alfianto",
    "Alfira", "Aliansyah", "Anandika", "Andriana", "Anggana", "Anugrah", "Aprilianto", "Arianto",
    "Aryadi", "Aryanto", "Asmara", "Asmoro", "Atmaja", "Atmojo", "Bagaskara", "Bahari",
    "Baskara", "Bastari", "Batubara", "Bramantyo", "Buana", "Budiarto", "Budiman", "Cahyadi",
    "Cahyo", "Cahyono", "Candra", "Chandra", "Cipta", "Daniswara", "Darmawan", "Dewangga",
    "Dharma", "Dirgantara", "Diwangkara", "Dwiputra", "Eka", "Endriawan", "Faturahman", "Febrian",
    "Febrianto", "Firdaus", "Firmansyah", "Gani", "Gemilang", "Ghozali", "Gunadi", "Gunawan",
    # Sumatera & Sunda
    "Halim", "Hamzah", "Handoko", "Hanggara", "Harahap", "Harimurti", "Haryadi", "Haryanto",
    "Harahap", "Hasanuddin", "Hasibuan", "Hendrawan", "Hermansyah", "Hidayat", "Husada", "Imanuel",
    "Indrayana", "Iskandar", "Ismaya", "Iswahyudi", "Jaelani", "Jatmiko", "Junaedi", "Karyadi",
    "Khairan", "Kholid", "Krisnawan", "Kusnadi", "Kusuma", "Kusumawardhana", "Lazuardi", "Lim",
    "Lubis", "Mahardhika", "Mahendra", "Maharani", "Manik", "Mardika", "Marpaung", "Marsudi",
    "Mawardi", "Megantara", "Mukti", "Mulia", "Mulyadi", "Mulyana", "Mulyono", "Munawar",
    "Munir", "Murdaya", "Nababan", "Nainggolan", "Nasution", "Naufaldi", "Nirmana", "Noviansyah",
    "Nugraha", "Nuratman", "Nurcahyo", "Nurhadi", "Nurkholis", "Nurrahman", "Octavianto", "Padmawijaya",
    # Bali & lain
    "Pandu", "Panjaitan", "Pasaribu", "Permadi", "Pradana", "Pradipta", "Prakoso", "Pranadipta",
    "Prananto", "Prasetya", "Prasetyo", "Prastiwi", "Prawira", "Prayoga", "Pribadi", "Priyono",
    "Pujangga", "Purba", "Purnama", "Purnomo", "Purwanto", "Rachman", "Rachmat", "Raharja",
    "Raharjo", "Rahardjo", "Rahayu", "Rahimsyah", "Raksana", "Ramadhan", "Ramadhani", "Ramelan",
    "Rangkuti", "Rasyid", "Ridwan", "Rifa'i", "Rinaldi", "Rinjani", "Risdianto", "Riyadi",
    "Riyanto", "Rizaldi", "Rosadi", "Rusmana", "Saharani", "Salim", "Sanjaya", "Santosa",
    "Santoso", "Sasongko", "Sastrawijaya", "Satria", "Satrio", "Sebastian", "Setiabudi", "Setiadi",
    "Setiawati", "Sianipar", "Siahaan", "Sianturi", "Siburian", "Siddiq", "Sihombing", "Silaban",
    # Tambahan
    "Simanjuntak", "Simbolon", "Simorangkir", "Simatupang", "Sinaga", "Siregar", "Sitepu", "Sitompul",
    "Sitorus", "Soemarno", "Solihin", "Sopian", "Sudarto", "Sudirman", "Suganda", "Suhardi",
    "Suherman", "Sulaiman", "Sulistio", "Sulistiyo", "Sumadi", "Sumantri", "Sunaryo", "Suparman",
    "Surahman", "Suryadi", "Suryana", "Susilo", "Sutanto", "Sutardjo", "Sutomo", "Tanjung",
    "Taufiq", "Trihatmodjo", "Tristanto", "Utomo", "Wahidin", "Wahyono", "Wahyudi", "Wardana",
    "Wardhana", "Wardoyo", "Wibawa", "Wibisono", "Widiyanto", "Widjaja", "Widodo", "Wijaksana",
    "Winata", "Wiranata", "Wiratama", "Wirawan", "Wirayuda", "Yanto", "Yudhistira", "Zulkarnain",
]

# Dedupe (preserve order)
NAMES_M    = list(dict.fromkeys(NAMES_M))
NAMES_F    = list(dict.fromkeys(NAMES_F))
LAST_NAMES = list(dict.fromkeys(LAST_NAMES))


def _pick_random_name():
    """Return (first, last, gender) — gender = 'M' or 'F'."""
    if random.random() < 0.5:
        first = random.choice(NAMES_M)
        gender = "M"  # Male
    else:
        first = random.choice(NAMES_F)
        gender = "F"  # Female
    last = random.choice(LAST_NAMES)
    return first, last, gender


def _gen_username(first: str, last: str, suffix: str = "") -> str:
    """Generate username target 25-29 chars total.
    Format: <first><last><pad-letters><digits><suffix>
    Gmail allowed: a-z 0-9 . — total 6-30 chars.
    """
    target_len = random.randint(25, 29)
    base = (first + last).lower().replace(" ", "")
    digits = "".join(random.choices(string.digits, k=4))
    suffix_full = digits + suffix
    # Sisa karakter buat base atau pad
    remaining = target_len - len(suffix_full)
    if len(base) >= remaining:
        # Base ke-panjangan → potong
        base = base[:remaining]
    else:
        # Base ke-pendekan → pad dengan huruf random
        pad_len = remaining - len(base)
        base = base + "".join(random.choices(string.ascii_lowercase, k=pad_len))
    return (base + suffix_full).lower()


def _gen_birth():
    """Random birth date 1995-2005, day 1-28 (safe), month 1-12."""
    year = random.randint(1995, 2005)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return year, month, day


# ─────────────── Helper: input via shell ───────────────
def _type(d, text: str):
    """Type text dengan robust multi-method.
    Order: set_text(focused) → send_keys → shell input (chunked).
    Penting buat string panjang (25+ chars) yang sering ke-truncate via shell langsung.
    """
    # Method 1: set_text ke focused EditText (paling reliable buat string panjang)
    try:
        focused = d(focused=True)
        if focused.exists(timeout=1):
            focused.set_text(text)
            time.sleep(0.6)
            return
    except Exception:
        pass

    # Method 2: send_keys (uiautomator2 native)
    try:
        d.send_keys(text)
        time.sleep(0.6)
        return
    except Exception:
        pass

    # Method 3: shell input text dengan chunking (fallback)
    safe = text.replace(" ", "%s").replace("'", "")
    chunk_size = 8
    for i in range(0, len(safe), chunk_size):
        d.shell(f"input text {safe[i:i+chunk_size]}")
        time.sleep(0.25)
    time.sleep(0.5)


def _key(d, keycode: str):
    """Press keyevent."""
    d.shell(f"input keyevent {keycode}")
    time.sleep(0.4)


def _click_pct(d, x_pct: float, y_pct: float):
    """Click using percent coordinates (0.0 - 1.0)."""
    info = d.window_size()  # (w, h)
    w, h = info
    d.click(int(w * x_pct), int(h * y_pct))
    time.sleep(0.6)


def _swipe_long(d):
    """Swipe panjang dari bawah ke atas (scroll down content)."""
    w, h = d.window_size()
    d.swipe(int(w * 0.5), int(h * 0.8), int(w * 0.5), int(h * 0.2), duration=0.4)
    time.sleep(0.5)


def _close_app(d):
    try:
        d.shell(f"am force-stop {GMAIL_PACKAGE}")
    except Exception:
        pass


# ─────────────── MAIN ENTRY ───────────────
def create_gmail(serial: str, log=None) -> dict:
    """
    Buat akun Gmail baru di device.
    Return: {
      "username": "...",  (alias dari setting kalau ada)
      "email":    "abc@gmail.com",
      "password": "1sampai10",
      "status":   "ok" | "error",
      "error":    "..."
    }
    """
    def _log(msg):
        if log: log(msg)

    first, last, gender = _pick_random_name()
    year, month, day = _gen_birth()
    password = "1sampai10"

    result = {
        "first_name": first,
        "last_name": last,
        "gender": "Male" if gender == "M" else "Female",
        "birth": f"{day:02d}/{month:02d}/{year}",
        "email": "",
        "password": password,
        "status": "error",
        "error": "",
    }

    try:
        d = u2.connect(serial)

        # ── Lock orientation portrait (anti auto-rotate) ──
        try:
            d.shell("settings put system accelerometer_rotation 0")  # disable auto-rotate
            d.shell("settings put system user_rotation 0")           # set portrait
            d.freeze_rotation(True)                                   # uiautomator2 freeze
            # Cmd Android 11+ — lock orientation
            d.shell("cmd window set-user-rotation lock 0")
        except Exception as _re:
            _log(f"⚠ Lock rotation partial: {_re}")
        time.sleep(0.5)

        # ── Step 1: Buka Gmail ──
        _log(f"📧 [1/14] Buka Gmail")
        d.app_stop(GMAIL_PACKAGE)
        time.sleep(1)
        d.app_start(GMAIL_PACKAGE)
        # ⚡ Langsung lock rotation segera setelah app start (Gmail bisa rotate cepat)
        # Apply immediately, sebelum delay 5s
        try:
            d.shell("settings put system accelerometer_rotation 0")
            d.shell("settings put system user_rotation 0")
            d.freeze_rotation(True)
            d.shell("cmd window set-user-rotation lock 0")
        except Exception:
            pass
        time.sleep(5)
        # Re-apply lagi setelah Gmail load — buat jaga-jaga app reset state
        try:
            d.shell("settings put system accelerometer_rotation 0")
            d.shell("settings put system user_rotation 0")
            d.freeze_rotation(True)
        except Exception:
            pass

        # ── Step 2: Tap profil kanan atas ──
        _log(f"📧 [2/14] Tap profil")
        if d(resourceId=f"{GMAIL_PACKAGE}:id/og_apd_internal_image_view").exists(timeout=8):
            d(resourceId=f"{GMAIL_PACKAGE}:id/og_apd_internal_image_view").click()
        else:
            _click_pct(d, 0.883, 0.09)
        time.sleep(2)

        # ── Step 3: Add another account ──
        _log(f"📧 [3/14] Add another account")
        if d(text="Add another account").exists(timeout=5):
            d(text="Add another account").click()
        else:
            _click_pct(d, 0.315, 0.725)
        time.sleep(2)

        # ── Step 4: Pilih Google ──
        _log(f"📧 [4/14] Pilih Google")
        if d(text="Google").exists(timeout=5):
            d(text="Google").click()
        else:
            _click_pct(d, 0.29, 0.34)
        time.sleep(5)  # tunggu 3-5s

        # ── Step 5: Create account → For my personal use ──
        _log(f"📧 [5/14] Create account → For my personal use")
        _click_pct(d, 0.246, 0.571)  # Create account
        time.sleep(1.5)
        _click_pct(d, 0.271, 0.637)  # For my personal use
        time.sleep(3)

        # ── Step 6: First name + Tab + Last name + Next ──
        _log(f"📧 [6/14] Nama: {first} {last}")
        _click_pct(d, 0.236, 0.318)  # focus First name
        time.sleep(0.8)
        _type(d, first)
        time.sleep(0.5)
        _key(d, "KEYCODE_TAB")  # pindah ke Last name
        time.sleep(0.5)
        _type(d, last)
        time.sleep(0.5)
        if d(text="Next").exists(timeout=3):
            d(text="Next").click()
        else:
            _click_pct(d, 0.819, 0.894)
        time.sleep(3)

        # ── Step 7: Birth + Gender ──
        # Bulan dropdown: tap → pilih bulan (Aug+ wajib scroll dropdown internal)
        _log(f"📧 [7/14] Birth {day}/{month}/{year} · Gender {result['gender']}")
        _click_pct(d, 0.271, 0.318)  # tap dropdown bulan
        time.sleep(2.5)              # tunggu dropdown fully open + animation done

        MONTHS = ["January", "February", "March", "April", "May", "June",
                  "July", "August", "September", "October", "November", "December"]
        target_month_str = MONTHS[month - 1]

        # ── Klik bulan (strict bounds inside red box dropdown) ──
        # Red box area dropdown (dari screenshot user):
        #   x: 4% → 40% lebar layar
        #   y: 42% → 97% tinggi layar
        # Hanya klik kalau element bounds berada DI DALAM area ini
        # Scroll juga dilakukan DI DALAM area ini (x=22%, y dari 88% → 50%)
        w, h = d.window_size()
        DROPDOWN_X_MIN = int(w * 0.02)
        DROPDOWN_X_MAX = int(w * 0.45)
        DROPDOWN_Y_MIN = int(h * 0.40)
        DROPDOWN_Y_MAX = int(h * 0.99)

        def _bounds_inside_dropdown(b: dict) -> bool:
            """Cek apakah bounds element berada DI DALAM red box dropdown."""
            l, t = b.get("left", 0), b.get("top", 0)
            r, bb = b.get("right", 0), b.get("bottom", 0)
            return (l >= DROPDOWN_X_MIN and r <= DROPDOWN_X_MAX and
                    t >= DROPDOWN_Y_MIN and bb <= DROPDOWN_Y_MAX and
                    r > l and bb > t)

        def _scroll_dropdown_up():
            """Scroll dropdown DI DALAM red box (swipe naik = munculin item bawah)."""
            d.swipe(int(w * 0.22), int(h * 0.85), int(w * 0.22), int(h * 0.55), duration=0.5)
            time.sleep(0.9)

        clicked = False
        max_attempts = 8
        for attempt in range(max_attempts):
            # Coba 3 selector sequentially
            target = None
            for sel in (
                lambda: d(text=target_month_str),
                lambda: d(textMatches=f"^{target_month_str}$"),
                lambda: d(text=target_month_str, className="android.widget.CheckedTextView"),
            ):
                try:
                    candidate = sel()
                    if candidate.exists(timeout=0.5):
                        target = candidate
                        break
                except Exception:
                    continue

            if target is not None:
                try:
                    info = target.info
                    bounds = info.get("bounds", {})
                    if _bounds_inside_dropdown(bounds):
                        # Bounds inside red box — click center koordinat exact
                        cx = (bounds["left"] + bounds["right"]) // 2
                        cy = (bounds["top"] + bounds["bottom"]) // 2
                        d.click(cx, cy)
                        clicked = True
                        _log(f"📧    ✓ Bulan {target_month_str} di-click @ ({cx},{cy})")
                        break
                    else:
                        _log(f"📧    ⤵ {target_month_str} ada tapi bounds di luar dropdown → scroll")
                except Exception as _ie:
                    _log(f"⚠ Bounds extract gagal: {_ie}")

            # Scroll dropdown internal
            try:
                _scroll_dropdown_up()
            except Exception:
                pass

        if not clicked:
            _log(f"⚠ Bulan {target_month_str} gak ke-click setelah {max_attempts}x — fallback coord di tengah dropdown")
            _click_pct(d, 0.22, 0.65)  # tengah red box
        time.sleep(1.5)

        # Tab → Day
        _key(d, "KEYCODE_TAB")
        _type(d, str(day))
        time.sleep(0.4)

        # Tab → Year
        _key(d, "KEYCODE_TAB")
        _type(d, str(year))
        time.sleep(0.4)

        # Tab → Enter (open gender dropdown)
        _key(d, "KEYCODE_TAB")
        _key(d, "KEYCODE_ENTER")
        time.sleep(1)

        # Pilih gender — Female ada di list, geser dengan arrow / pakai text
        if gender == "M":
            if d(text="Male").exists(timeout=3):
                d(text="Male").click()
            else:
                _key(d, "KEYCODE_DPAD_DOWN")
                _key(d, "KEYCODE_SPACE")
        else:
            if d(text="Female").exists(timeout=3):
                d(text="Female").click()
            else:
                _key(d, "KEYCODE_DPAD_DOWN")
                _key(d, "KEYCODE_DPAD_DOWN")
                _key(d, "KEYCODE_SPACE")
        time.sleep(1.5)

        # Next
        if d(text="Next").exists(timeout=3):
            d(text="Next").click()
        else:
            _click_pct(d, 0.79, 0.891)
        time.sleep(3)

        # ── Step 8: Email username + Next (dgn retry kalau username taken) ──
        # 2 variasi screen:
        #   A. Direct input — field langsung available, tinggal ketik
        #   B. Suggested usernames — wajib klik "Create your own Gmail address" dulu
        username_attempts = 0
        max_username_retry = 3
        suffix = ""
        username = ""

        # Detect variasi B: cari text "Create your own Gmail address"
        variant_b = False
        for kw in ("Create your own Gmail address", "Create your own", "buat alamat Gmail sendiri", "Buat alamat"):
            if d(textContains=kw).exists(timeout=2):
                _log(f"📧 [8/14] Variant B detected — klik 'Create your own Gmail address'")
                d(textContains=kw).click()
                variant_b = True
                time.sleep(2)
                break
        if not variant_b:
            for kw in ("Choose your", "Pilih alamat", "suggested", "Saran"):
                if d(textContains=kw).exists(timeout=1):
                    _log(f"📧 [8/14] Variant B detected (suggestions screen) — coord click 'Create your own'")
                    _click_pct(d, 0.097, 0.475)
                    variant_b = True
                    time.sleep(2)
                    break

        while username_attempts < max_username_retry:
            username = _gen_username(first, last, suffix)
            _log(f"📧 [8/14] Username: {username}@gmail.com")
            _type(d, username)
            time.sleep(0.5)
            if d(text="Next").exists(timeout=3):
                d(text="Next").click()
            else:
                _click_pct(d, 0.872, 0.836)
            time.sleep(3)

            # Cek apakah ada error "That username is taken"
            taken = False
            for kw in ("taken", "already", "tidak tersedia", "sudah digunakan"):
                if d(textContains=kw).exists(timeout=2):
                    taken = True
                    break
            if not taken:
                break
            # Username taken → tambah suffix unik
            suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=3))
            _log(f"⚠ Username taken — retry dgn suffix '{suffix}'")
            username_attempts += 1
            # Clear field — backspace dari end
            _key(d, "KEYCODE_MOVE_END")
            for _ in range(len(username) + 5):
                _key(d, "KEYCODE_DEL")
            time.sleep(0.5)

        if username_attempts >= max_username_retry:
            result["error"] = "Username retry max — semua taken"
            _close_app(d)
            return result

        result["email"] = f"{username}@gmail.com"

        # ── Step 9: Password + Next ──
        _log(f"📧 [9/14] Password")
        _type(d, password)
        time.sleep(0.5)
        # Sometimes there's a confirm password field — tab and retype
        _key(d, "KEYCODE_TAB")
        _type(d, password)
        time.sleep(0.5)
        if d(text="Next").exists(timeout=3):
            d(text="Next").click()
        else:
            _click_pct(d, 0.776, 0.842)
        time.sleep(3)

        # ── Step 10: Save password popup ──
        _log(f"📧 [10/14] Save password popup")
        if d(resourceId="android:id/autofill_save_yes").exists(timeout=5):
            d(resourceId="android:id/autofill_save_yes").click()
        elif d(text="Save").exists(timeout=3):
            d(text="Save").click()
        else:
            _click_pct(d, 0.836, 0.9)
        time.sleep(2)

        # ── Step 11: Review → Next ──
        _log(f"📧 [11/14] Review → Next")
        if d(text="Next").exists(timeout=8):
            d(text="Next").click()
        else:
            _click_pct(d, 0.812, 0.894)
        time.sleep(3)

        # ── Step 12: Scroll 8x → I agree → wait 10-15s ──
        _log(f"📧 [12/14] Scroll 8x → I agree")
        for _ in range(8):
            _swipe_long(d)
        time.sleep(0.5)
        # Coba klik "I agree" via text dulu, fallback coord
        if d(text="I agree").exists(timeout=3):
            d(text="I agree").click()
        else:
            _click_pct(d, 0.827, 0.888)
        _log(f"📧 ⏳ Tunggu 13s...")
        time.sleep(13)

        # ── Step 13: Scroll 3x → Not now ──
        _log(f"📧 [13/14] Scroll 3x → Not now")
        for _ in range(3):
            _swipe_long(d)
        time.sleep(0.5)
        if d(text="Not now").exists(timeout=3):
            d(text="Not now").click()
        else:
            _click_pct(d, 0.131, 0.89)
        time.sleep(3)

        # ── Step 14: Selesai → wait 10s → close app ──
        _log(f"📧 [14/14] Selesai — tunggu 10s")
        time.sleep(10)
        _close_app(d)

        # Unlock rotation (kembalikan ke default user)
        try:
            d.freeze_rotation(False)
        except Exception:
            pass

        result["status"] = "ok"
        _log(f"✅ Gmail dibuat: {result['email']}")
        return result

    except Exception as e:
        result["error"] = str(e)
        _log(f"❌ Error: {e}")
        try:
            d = u2.connect(serial)
            _close_app(d)
            try:
                d.freeze_rotation(False)
            except Exception:
                pass
        except Exception:
            pass
        return result
