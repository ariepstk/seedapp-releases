"""Dashboard Page — Makmur-inspired"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QScrollArea, QGridLayout
)
from PyQt6.QtCore import Qt
from src.core.database import ProjectRepo, DatasetRepo, VideoRepo


STATUS_BADGE = {
    "antrian":  ("Antrian",  "badgeAntrian"),
    "berjalan": ("Berjalan", "badgeBerjalan"),
    "berhenti": ("Berhenti", "badgeBerhenti"),
    "selesai":  ("Selesai",  "badgeSelesai"),
    "error":    ("Error",    "badgeError"),
}


def _theme():
    try:
        from src.ui.main_window import current_theme
        return current_theme()
    except Exception:
        return "light"


class StatCard(QFrame):
    def __init__(self, label: str, value: str, accent: str, bg: str, icon: str = ""):
        super().__init__()
        self.setObjectName("dashStatCard")
        self._accent = accent
        self._bg     = bg
        self._val_lbl = None  # init dulu agar _apply_style tidak error

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(6)

        top = QHBoxLayout()
        if icon:
            icon_lbl = QLabel(icon)
            icon_lbl.setStyleSheet(
                f"font-size:22px; background:transparent; border:none;")
            top.addWidget(icon_lbl)
        top.addStretch()
        lay.addLayout(top)

        self._val_lbl = QLabel(value)
        self._val_lbl.setStyleSheet(
            f"font-size:30px; font-weight:800; color:{accent}; background:transparent; border:none;")
        self._val_lbl.setObjectName("dashStatVal")
        lay.addWidget(self._val_lbl)

        lbl = QLabel(label)
        lbl.setStyleSheet(
            "font-size:12px; font-weight:500; color:#8a9bb0; background:transparent; border:none; text-transform:uppercase; letter-spacing:0.5px;")
        lay.addWidget(lbl)

        self._apply_style()  # dipanggil setelah _val_lbl siap

    def _apply_style(self):
        try:
            from src.ui.main_window import current_theme
            t = current_theme()
        except Exception:
            t = "light"
        if t == "dark":
            bg   = "#242538"
            bord = "#2e2f50"
        else:
            bg   = self._bg
            bord = "#e8edf5"
        if self._val_lbl:
            self._val_lbl.setStyleSheet(
                f"font-size:30px; font-weight:800; color:{self._accent}; background:transparent; border:none;")
        self.setStyleSheet(
            f"#dashStatCard {{ background:{bg}; border:1px solid {bord}; "
            f"border-radius:12px; border-top: 3px solid {self._accent}; }}"
            f"#dashStatCard:hover {{ border-color: {self._accent}; }}"
        )

    def set_value(self, v: str):
        self._val_lbl.setText(v)


class DashboardPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── Top header bar ──
        self._header = QFrame()
        self._header.setObjectName("pageHeader")
        self._header.setFixedHeight(64)
        hlay = QHBoxLayout(self._header)
        hlay.setContentsMargins(28, 0, 28, 0)
        title = QLabel("Dashboard")
        title.setObjectName("pageTitle")
        hlay.addWidget(title)
        hlay.addStretch()
        outer.addWidget(self._header)

        # ── Divider ──
        div = QFrame(); div.setFixedHeight(1); div.setObjectName("headerDivider")
        outer.addWidget(div)

        # ── Scrollable content ──
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(24)

        # ── Stat cards row ──
        cards_lay = QHBoxLayout()
        cards_lay.setSpacing(14)

        self.card_project = StatCard("Total Project", "0", "#6c63ff", "#faf9ff", "📱")
        self.card_dataset  = StatCard("Total Dataset",  "0", "#00c48c", "#f0fdf8", "📋")
        self.card_total    = StatCard("Total Video",    "0", "#3b82f6", "#eff6ff", "🎬")
        self.card_selesai  = StatCard("Selesai",        "0", "#00c48c", "#f0fdf4", "✅")
        self.card_error    = StatCard("Error",          "0", "#dc2626", "#fef2f2", "❌")

        for card in [self.card_project, self.card_dataset,
                     self.card_total, self.card_selesai, self.card_error]:
            cards_lay.addWidget(card)
        layout.addLayout(cards_lay)

        # ── Recent projects section ──
        sec_hdr = QHBoxLayout()
        sec_lbl = QLabel("Project Terbaru")
        sec_lbl.setObjectName("sectionTitle")
        sec_hdr.addWidget(sec_lbl)
        sec_hdr.addStretch()
        layout.addLayout(sec_hdr)

        # Table-like header
        self._proj_container = QFrame()
        self._proj_container.setObjectName("dashCard")
        self._proj_container.setObjectName("dashCard")
        self._proj_layout = QVBoxLayout(self._proj_container)
        self._proj_layout.setContentsMargins(0, 0, 0, 0)
        self._proj_layout.setSpacing(0)

        # Column header
        self._col_hdr = QFrame()
        self._ch_lay = QHBoxLayout(self._col_hdr)
        self._ch_lay.setContentsMargins(20, 10, 20, 10)
        self._col_labels = []
        for txt, stretch in [("Nama Project", 3), ("Dataset", 2), ("Total", 1),
                              ("Selesai", 1), ("Error", 1), ("Status", 1)]:
            l = QLabel(txt)
            self._col_labels.append(l)
            self._ch_lay.addWidget(l, stretch)
        self._proj_layout.addWidget(self._col_hdr)

        self._rows_widget = QWidget()
        self._rows_layout = QVBoxLayout(self._rows_widget)
        self._rows_layout.setContentsMargins(0, 0, 0, 0)
        self._rows_layout.setSpacing(0)
        self._proj_layout.addWidget(self._rows_widget)

        layout.addWidget(self._proj_container)
        layout.addStretch()

        scroll.setWidget(content)
        outer.addWidget(scroll, 1)

        self.refresh()

    def refresh(self):
        # Re-apply card styles for theme changes
        for card in [self.card_project, self.card_dataset,
                     self.card_total, self.card_selesai, self.card_error]:
            card._apply_style()

        # Re-apply table header theme
        t = _theme()
        if t == "dark":
            self._col_hdr.setStyleSheet(
                "background:#242538; border-radius:12px 12px 0 0; border-bottom:1px solid #2e2f50;")
            for l in self._col_labels:
                l.setStyleSheet("font-size:11px; font-weight:700; color:#5a5c8a; "
                               "letter-spacing:0.5px; background:transparent;")
        else:
            self._col_hdr.setStyleSheet(
                "background:#f7f8fa; border-radius:12px 12px 0 0; border-bottom:1px solid #e0e6ed;")
            for l in self._col_labels:
                l.setStyleSheet("font-size:11px; font-weight:700; color:#8a9bb0; "
                               "letter-spacing:0.5px; background:transparent;")

        projects = ProjectRepo.get_all()
        datasets = DatasetRepo.get_all()

        total_video   = sum(d.get("total_video", 0) for d in datasets)
        total_selesai = sum(p.get("selesai", 0) for p in projects)
        total_error   = sum(p.get("error", 0) for p in projects)

        self.card_project.set_value(str(len(projects)))
        self.card_dataset.set_value(str(len(datasets)))
        self.card_total.set_value(str(total_video))
        self.card_selesai.set_value(str(total_selesai))
        self.card_error.set_value(str(total_error))

        # Clear rows
        while self._rows_layout.count():
            item = self._rows_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for i, p in enumerate(projects[:10]):
            row = self._make_row(p, i)
            self._rows_layout.addWidget(row)

        if not projects:
            empty = QLabel("Belum ada project")
            empty.setStyleSheet("color:#8a9bb0; font-size:13px; background:transparent;")
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty.setFixedHeight(60)
            self._rows_layout.addWidget(empty)

    def _make_row(self, p: dict, idx: int) -> QFrame:
        t = _theme()
        if t == "dark":
            bg      = "#1e1f36"
            bg_alt  = "#242538"
            border  = "#2a2b48"
            text    = "#e0e1f0"
            text_dim= "#5a5c8a"
            hover   = "#2a2b48"
        else:
            bg      = "#ffffff"
            bg_alt  = "#f9fafb"
            border  = "#f0f4f8"
            text    = "#1a2332"
            text_dim= "#8a9bb0"
            hover   = "#f7f8fa"

        bg_color = bg_alt if idx % 2 == 1 else bg
        row = QFrame()
        row.setStyleSheet(
            f"QFrame {{ background:{bg_color}; border:none; border-bottom:1px solid {border}; }}"
            f"QFrame:hover {{ background:{hover}; }}"
        )
        lay = QHBoxLayout(row)
        lay.setContentsMargins(20, 12, 20, 12)
        lay.setSpacing(0)

        def cell(txt, stretch, bold=False, color=None):
            l = QLabel(txt)
            c = color or text
            l.setStyleSheet(
                f"font-size:13px; color:{c}; background:transparent; border:none;"
                + (" font-weight:600;" if bold else ""))
            l.setWordWrap(False)
            lay.addWidget(l, stretch)

        cell(p.get("name", "—"), 3, bold=True)
        cell(p.get("dataset_name") or "—", 2, color=text_dim)
        cell(str(p.get("total", 0)), 1, color=text)
        cell(str(p.get("selesai", 0)), 1, color="#16a34a")
        cell(str(p.get("error", 0)), 1, color="#dc2626")

        # Badge
        sk = p.get("status", "antrian")
        b_text, b_obj = STATUS_BADGE.get(sk, ("Antrian", "badgeAntrian"))
        badge = QLabel(b_text)
        badge.setObjectName(b_obj)
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setFixedWidth(72)
        lay.addWidget(badge, 1)

        return row
