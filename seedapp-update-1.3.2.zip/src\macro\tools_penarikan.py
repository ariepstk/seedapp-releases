"""
Tools — Penarikan Saldo ShopeePay via QRIS
Flow: Buka Shopee → Scrape saldo → ShopeePay → QRIS → Pilih QR dari galeri → Input nominal → Bayar
"""

import re
import time
import uiautomator2 as u2

SHOPEE_PACKAGE   = "com.shopee.id"
WAIT_TIMEOUT     = 10  # Elemen wajib
OPTIONAL_TIMEOUT = 3   # Elemen opsional (mungkin tidak muncul)


def _force_close_foreground(d):
    try:
        current = d.app_current()
        pkg = current.get("package", "")
        if pkg:
            d.app_stop(pkg)
    except Exception:
        pass


def _start_shopee(d, clone: bool):
    d.shell("settings put system accelerometer_rotation 0")
    d.shell("settings put system user_rotation 0")
    if clone:
        d.shell(f"am start --user 999 -n {SHOPEE_PACKAGE}/com.shopee.app.ui.home.HomeActivity_")
    else:
        d.app_start(SHOPEE_PACKAGE)
    time.sleep(3)


def _dismiss_popup(d):
    """Tutup popup/dialog yang mungkin muncul saat buka Shopee."""
    for _ in range(3):
        if d(description="Close").exists(timeout=OPTIONAL_TIMEOUT):
            d(description="Close").click()
            time.sleep(0.5)
        elif d(text="Nanti Saja").exists(timeout=OPTIONAL_TIMEOUT):
            d(text="Nanti Saja").click()
            time.sleep(0.5)
        elif d(text="Lewati").exists(timeout=OPTIONAL_TIMEOUT):
            d(text="Lewati").click()
            time.sleep(0.5)
        else:
            break


def _parse_nominal(saldo_str: str) -> str:
    """'Rp209.506' → '209506'"""
    return re.sub(r'[^0-9]', '', saldo_str) or "0"


def penarikan_shopeepay(serial: str, clone: bool, log=None, sync_key: str = "") -> dict:
    """
    Penarikan saldo ShopeePay via QRIS dari galeri.
    Return: {"username": str, "saldo": str, "error": str|None}
    """
    def _log(msg):
        if log: log(msg)

    result = {"username": "—", "saldo": "—", "nama_tujuan": "—", "error": None}

    try:
        d = u2.connect(serial)
        _log(f"📱 Terhubung ke {serial}")

        # ── 1. Buka Shopee ──────────────────────────────
        _log("🚀 Membuka Shopee...")
        _force_close_foreground(d)
        _start_shopee(d, clone)
        time.sleep(1)
        _dismiss_popup(d)

        # ── 2. Navigasi ke tab Saya ──────────────────────
        _log("👤 Navigasi ke tab Saya...")
        tab_saya = d(description="tab_bar_button_me")
        if not tab_saya.exists(timeout=WAIT_TIMEOUT):
            tab_saya = d(text="Saya")
        if not tab_saya.exists(timeout=WAIT_TIMEOUT):
            result["error"] = "Tab Saya tidak ditemukan"
            _log(f"❌ {result['error']}"); return result
        tab_saya.click()
        time.sleep(2)
        _dismiss_popup(d)

        # ── 3. Scrape username ───────────────────────────
        _log("🔍 Scrape username...")
        el_user = d(resourceId="labelUserName")
        if el_user.exists(timeout=WAIT_TIMEOUT):
            result["username"] = el_user.get_text() or "—"
            _log(f"✅ Username: {result['username']}")
        else:
            _log("⚠ Username tidak ditemukan")

        # ── 4. Scrape saldo ──────────────────────────────
        _log("💰 Scrape saldo ShopeePay...")
        els = d.xpath('//*[@resource-id="meCircleSubtitleView"]//android.widget.TextView').all()
        if els:
            result["saldo"] = els[0].attrib.get("text", "Rp0") or "Rp0"
            _log(f"✅ Saldo: {result['saldo']}")
        else:
            result["error"] = "Elemen saldo tidak ditemukan"
            _log(f"❌ {result['error']}"); return result

        nominal = _parse_nominal(result["saldo"])
        if nominal == "0":
            result["error"] = "Saldo 0, penarikan dibatalkan"
            _log(f"❌ {result['error']}"); return result

        # ── 5. Klik ShopeePay di Dompet Saya ────────────
        _log("💳 Klik ShopeePay...")
        sp_btn = d(text="ShopeePay")
        if not sp_btn.exists(timeout=WAIT_TIMEOUT):
            result["error"] = "Tombol ShopeePay tidak ditemukan"
            _log(f"❌ {result['error']}"); return result
        sp_btn.click()
        time.sleep(5)

        # ── 6. Dismiss biometrik popup (Atur Nanti) ──────
        atur_nanti = d(resourceId="com.shopee.id.dfpluginshopeepay:id/later_button")
        if not atur_nanti.exists(timeout=OPTIONAL_TIMEOUT):
            atur_nanti = d(text="Atur Nanti")
        if atur_nanti.exists(timeout=OPTIONAL_TIMEOUT):
            _log("🔒 Dismiss biometrik popup...")
            atur_nanti.click()
            time.sleep(1)

        # ── 7. Klik QRIS (bottom nav, koordinat) ─────────
        _log("📷 Klik QRIS...")
        d.click(0.504, 0.88)
        time.sleep(2)

        # ── 8. Klik ikon Photo (galeri) di halaman scan ──
        _log("🖼 Buka galeri dari QRIS scanner...")
        photo_btn = d(resourceId="com.shopee.id:id/photo_button")
        if not photo_btn.exists(timeout=WAIT_TIMEOUT):
            # Fallback: koordinat kanan atas
            d.click(0.916, 0.07)
        else:
            photo_btn.click()
        time.sleep(2)

        # ── 9. Klik gambar pertama di galeri ─────────────
        _log("📂 Pilih gambar pertama dari galeri...")
        first_img = d.xpath('//*[@resource-id="com.shopee.id:id/recycler_view"]/android.widget.FrameLayout')
        imgs = first_img.all()
        if imgs:
            imgs[0].click()
        else:
            result["error"] = "Gambar di galeri tidak ditemukan"
            _log(f"❌ {result['error']}"); return result
        time.sleep(2)

        # ── 10. Konfirmasi pilih gambar (done_button) ────
        _log("✅ Konfirmasi gambar QR...")
        done_btn = d(resourceId="com.shopee.id:id/done_button")
        if done_btn.exists(timeout=WAIT_TIMEOUT):
            done_btn.click()
        else:
            # Fallback koordinat kanan atas
            d.click(0.922, 0.076)
        time.sleep(5)

        # ── 11. Input nominal saldo ──────────────────────
        _log(f"💵 Input nominal: {nominal}...")
        inp = d(className="android.widget.EditText")
        if inp.exists(timeout=WAIT_TIMEOUT):
            inp.click()
            time.sleep(0.5)
            inp.clear_text()
            d.send_keys(nominal)
        else:
            result["error"] = "Field nominal tidak ditemukan"
            _log(f"❌ {result['error']}"); return result

        # Klik "Selesai" di keyboard custom ShopeePay
        selesai_btn = d(resourceId="com.shopee.id.dfpluginshopeepay:id/shopeepaysdk_money_keyboard_num_confirm")
        if selesai_btn.exists(timeout=OPTIONAL_TIMEOUT):
            _log("⌨ Klik Selesai keyboard...")
            selesai_btn.click()
        time.sleep(1)

        # ── 12. Klik Lanjutkan (opsional) ───────────────
        lanjut = d(text="Lanjutkan")
        if lanjut.exists(timeout=OPTIONAL_TIMEOUT):
            _log("▶ Klik Lanjutkan...")
            lanjut.click()
            time.sleep(3)
        else:
            _log("⏭ Tombol Lanjutkan tidak muncul, skip...")

        # ── 13. Klik Bayar Sekarang ──────────────────────
        _log("💸 Klik Bayar Sekarang...")
        bayar = d(text="Bayar Sekarang")
        if not bayar.exists(timeout=WAIT_TIMEOUT):
            result["error"] = "Tombol Bayar Sekarang tidak ditemukan"
            _log(f"❌ {result['error']}"); return result
        bayar.click()
        time.sleep(3)

        # ── 14. Input PIN ────────────────────────────────
        _log("🔐 Input PIN...")
        try:
            import base64
            pin = base64.b64decode(sync_key).decode() if sync_key else ""
        except Exception:
            pin = ""
        if not pin:
            result["error"] = "sync_key tidak diset atau tidak valid"
            _log(f"❌ {result['error']}"); return result
        d.send_keys(pin)
        time.sleep(3)

        # ── 15. Scrape hasil transaksi ───────────────────
        # Cek sukses via labelAmount
        label_amount = d(resourceId="labelAmount")
        if label_amount.exists(timeout=WAIT_TIMEOUT):
            saldo_ditarik = label_amount.get_text() or "—"
            result["saldo"] = saldo_ditarik
            _log(f"✅ Nominal ditarik: {saldo_ditarik}")
        else:
            result["error"] = "Transaksi gagal / labelAmount tidak ditemukan"
            _log(f"❌ {result['error']}")

        # Scrape nama tujuan
        el_tujuan = d(textContains="SYAMSUL BAHRI")
        if el_tujuan.exists(timeout=OPTIONAL_TIMEOUT):
            result["nama_tujuan"] = el_tujuan.get_text() or "—"
            _log(f"✅ Tujuan: {result['nama_tujuan']}")
        else:
            result["nama_tujuan"] = "Tujuan tidak dikenal"
            _log(f"⚠ {result['nama_tujuan']}")

        time.sleep(1)

        # ── 16. Klik OK ──────────────────────────────────
        _log("✅ Klik OK...")
        ok_btn = d(text="OK")
        if ok_btn.exists(timeout=OPTIONAL_TIMEOUT):
            ok_btn.click()
        time.sleep(3)

        _log(f"✅ Penarikan selesai — {result['username']} | {result['saldo']} → {result.get('nama_tujuan','—')}")

    except Exception as e:
        result["error"] = str(e)
        _log(f"❌ Error: {e}")

    return result
