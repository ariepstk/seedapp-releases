"""
runner_reupload.py
ProjectRunner khusus mode Reupload Shopee.
TERPISAH dari runner.py (Generate AI).

Flow per item:
  1. Ambil data dari kolom rs_* (rs_url, rs_judul, rs_produk)
  2. Proses video (download → mute → frame → upscale → mix song)
  3. Upload ke Shopee
  4. Cleanup HP
"""

import os
import time
import random

from src.core.database import ProjectRepo, VideoRepo, UploadStatsRepo
from src.macro import reupload_shopee
from src.core.debug_logger import dlog
from src.core.error_categories import format_error


def _safe_disconnect(d):
    """Tutup koneksi u2 dengan aman — cegah zombie connection di ADB daemon."""
    if d is None:
        return
    try:
        if hasattr(d, '_default_session'):
            d._default_session.close()
    except Exception:
        pass
    try:
        if hasattr(d, 'stop_uiautomator'):
            d.stop_uiautomator()
    except Exception:
        pass


def _interruptible_sleep(seconds: int, stop_flag_fn, log_fn=None, label=""):
    for i in range(int(seconds), 0, -1):
        if stop_flag_fn():
            if log_fn: log_fn("⏹ Jeda dibatalkan.")
            return
        time.sleep(1)


class ProjectRunnerReupload:

    def __init__(self, project_id: int, device_serial: str = None,
                 log_fn=None, stop_flag_fn=None, target_selesai: int = 0,
                 hashtag_tambahan: str = "",
                 watch_min: int = 600, watch_max: int = 1800,
                 jeda_tiktok_shopee: int = 30,
                 folder_sound: str = "", folder_frame_border: str = "",
                 retry_video_id: int = 0,
                 shopee_clone: bool = False,
                 mix_sound: bool = True,
                 auto_hapus_cache: bool = True,
                 fast_mode: bool = False):

        self.project_id          = project_id
        self.device_serial       = device_serial
        self.log_fn              = log_fn or print
        self.stop_flag_fn        = stop_flag_fn or (lambda: False)
        self.target_selesai      = target_selesai
        self.hashtag_tambahan    = hashtag_tambahan
        self.watch_min           = watch_min
        self.watch_max           = watch_max
        self.jeda_tiktok_shopee  = jeda_tiktok_shopee
        self.folder_sound        = folder_sound
        self.folder_frame_border = folder_frame_border
        self.retry_video_id      = retry_video_id
        self.shopee_clone        = shopee_clone
        self.mix_sound           = mix_sound
        self.auto_hapus_cache    = auto_hapus_cache
        self.fast_mode           = fast_mode

    def log(self, msg): self.log_fn(msg)
    def is_stopped(self): return self.stop_flag_fn()

    def _connect(self):
        import uiautomator2 as u2
        try:
            return u2.connect(self.device_serial) if self.device_serial else u2.connect()
        except Exception as e:
            self.log(format_error(e, f"Connect {self.device_serial or 'default'}"))
            raise

    def run(self) -> tuple[int, int]:
        p = ProjectRepo.get_by_id(self.project_id)
        if not p or not p.get("dataset_id"):
            self.log("❌ Project tidak punya dataset!"); return 0, 0

        use_frame = p.get("rs_use_frame", "on") == "on"
        use_song  = p.get("rs_use_song",  "on") == "on"

        # Retry mode
        if self.retry_video_id:
            all_items = VideoRepo.get_by_project(self.project_id, status_filter="semua")
            items = [x for x in all_items if x["id"] == self.retry_video_id]
            if not items:
                self.log(f"❌ Video id={self.retry_video_id} tidak ditemukan"); return 0, 0
        else:
            items = VideoRepo.get_by_project(self.project_id, status_filter="antrian")
            if not items:
                self.log("ℹ️  Tidak ada video dengan status Antrian."); return 0, 0

        self.log(f"── {p['name']} | Reupload Shopee | "
                 f"Frame={'ON' if use_frame else 'OFF'} | "
                 f"Song={'ON' if use_song else 'OFF'} | "
                 f"Clone={'ON' if self.shopee_clone else 'OFF'} | "
                 f"Nonton={self.watch_min}~{self.watch_max}s | "
                 f"Jeda={self.jeda_tiktok_shopee}s | "
                 f"Target: {self.target_selesai} | {self.device_serial or 'default'} ──")

        # Persiapan awal
        try:
            d = self._connect()
            d.shell("settings put system accelerometer_rotation 0")
            d.shell("find /sdcard/DCIM -maxdepth 2 -name 'rs_*.mp4' -delete")
            _safe_disconnect(d); d = None
        except Exception as e:
            self.log(format_error(e, "Persiapan awal"))

        ProjectRepo.update_status(self.project_id, "berjalan")

        success = 0
        error   = 0

        for _idx, item in enumerate(items):
            if self.is_stopped():
                self.log("⏹  Dihentikan oleh pengguna."); break

            if self.target_selesai > 0 and success >= self.target_selesai:
                self.log(f"🎯 Target {self.target_selesai} video selesai!"); break

            item_no      = item.get("no")
            video_url    = item.get("rs_url", "").strip()
            file_lokal   = item.get("rs_file_lokal", "").strip()
            # Kalau sudah converted, pakai file lokal (skip download & proses)
            if file_lokal and os.path.exists(file_lokal) and os.path.getsize(file_lokal) > 500_000:
                video_url = f"__LOCAL__{file_lokal}"
            _raw_caption = item.get("rs_judul", "").strip()
            _hashtag     = self.hashtag_tambahan.strip() if hasattr(self, "hashtag_tambahan") else ""
            if _hashtag:
                _max_judul = 150 - len(_hashtag) - 1
                caption = _raw_caption[:_max_judul] + " " + _hashtag
            else:
                caption = _raw_caption      # kolom Judul → deskripsi
            raw_caption = _raw_caption      # tanpa hashtag, untuk fallback search
            product_link = item.get("rs_produk", "").strip()     # kolom Produk → link import

            # Resolve video FRESH dari halaman produk kalau rs_url kosong
            # (alur baru: CSV video sengaja dikosongkan → ambil saat upload).
            if not video_url and product_link:
                try:
                    from src.macro.shopee_resolver import resolve_video_url
                    fresh = resolve_video_url(product_link, log=self.log)
                    if fresh:
                        video_url = fresh
                        try:
                            VideoRepo.update_fields(item["id"], {"rs_url": fresh})
                        except Exception:
                            pass
                except Exception as e:
                    self.log(f"⚠ [{item_no}] resolve video gagal: {e}")

            if not video_url:
                self.log(f"⚠ [{item_no}] rs_url kosong & tak bisa resolve, skip!")
                VideoRepo.update_status_by_project(
                    self.project_id, item["id"], "error",
                    status_shopee="error"
                )
                VideoRepo.save_error_message(
                    self.project_id, item["id"], error_shopee="rs_url kosong"
                )
                # skip tidak hitung sebagai error target
                continue

            # Set proses
            VideoRepo.update_status_by_project(
                self.project_id, item["id"], "proses", status_shopee="proses"
            )
            dlog(self.device_serial, f"RS START item {item_no}")

            try:
                d = self._connect()
            except Exception:
                VideoRepo.update_status_by_project(
                    self.project_id, item["id"], "error", status_shopee="error"
                )
                VideoRepo.save_error_message(
                    self.project_id, item["id"], error_shopee="Device tidak terhubung"
                )
                error += 1
                # Delay 10s agar tidak rapid-loop saat semua device offline
                _interruptible_sleep(10, self.is_stopped, self.log, "Connect retry delay")
                continue

            rand_id_used = str(item_no)  # fallback
            p_name_pre = ProjectRepo.get_by_id(self.project_id).get("name", "")
            def _on_success():
                _sc = success + 1
                _sc_str = f"({_sc}" + (f"/{self.target_selesai}" if self.target_selesai > 0 else "") + ")"
                self.log(f"✅ {p_name_pre} — Shopee ✓  {_sc_str}")

            ok = False
            err_msg = ""
            try:
                ok, err_msg, rand_id_used = reupload_shopee.run_upload_flow(
                    d              = d,
                    caption        = caption,
                    product_link   = product_link,
                    video_url      = video_url,
                    item_id        = item_no,
                    log_fn         = self.log,
                    watch_min      = self.watch_min,
                    watch_max      = self.watch_max,
                    total_target   = self.target_selesai,
                    serial         = self.device_serial,
                    folder_frame   = self.folder_frame_border,
                    folder_sound   = self.folder_sound,
                    use_frame      = use_frame,
                    use_song       = use_song,
                    is_retry       = bool(self.retry_video_id),
                    success_fn     = _on_success,
                    raw_caption    = raw_caption,
                    shopee_clone   = self.shopee_clone,
                    fast_mode      = self.fast_mode,
                )
            except Exception as e:
                self.log(format_error(e, f"Reupload [{item_no}]"))
                err_msg = str(e)
            finally:
                if self.auto_hapus_cache:
                    try:
                        reupload_shopee.cleanup_hp_reupload(d, rand_id_used, self.log)
                    except Exception as ce:
                        self.log(f"⚠ Cleanup HP: {ce}")
                _safe_disconnect(d); d = None

            # Update status
            overall = "selesai" if ok else "error"
            VideoRepo.update_status_by_project(
                self.project_id, item["id"], overall,
                status_shopee=overall
            )
            if not ok and err_msg:
                VideoRepo.save_error_message(
                    self.project_id, item["id"], error_shopee=err_msg
                )

            if ok:
                success += 1
                UploadStatsRepo.record(self.device_serial, "reupload")
                # Cek target setelah success increment
                if self.target_selesai > 0 and success >= self.target_selesai:
                    dlog(self.device_serial, f"RS item {item_no} — OK")
                    break
            elif "__EXPIRED__" in (err_msg or ""):
                # Link video expired — coba SELAMATKAN: resolve URL fresh dari halaman produk.
                fresh = None
                if product_link:
                    try:
                        from src.macro.shopee_resolver import resolve_video_url
                        fresh = resolve_video_url(product_link, log=self.log)
                    except Exception as e:
                        self.log(f"⚠ resolve (expired) gagal: {e}")
                if fresh:
                    try:
                        VideoRepo.update_fields(item["id"], {"rs_url": fresh})
                    except Exception:
                        pass
                    VideoRepo.update_status_by_project(
                        self.project_id, item["id"], "antrian", status_shopee="antrian"
                    )
                    self.log(f"🔄 [{item_no}] URL expired → URL fresh disimpan, kembali ke antrian")
                else:
                    _clean_msg = err_msg.replace("__EXPIRED__ ", "")
                    VideoRepo.delete_by_id(item["id"], self.project_id)
                    self.log(f"🗑 Item dihapus — Link video expired (rs_{rand_id_used})")
            else:
                error += 1
                _err_detail = f" — {err_msg}" if err_msg else ""
                self.log(f"❌ Sudah {error}x Gagal{_err_detail}")

            dlog(self.device_serial, f"RS item {item_no} — {'OK' if ok else 'FAIL'}")

            # Jeda antar video
            _remaining = items[_idx+1:]
            _target_reached = self.target_selesai > 0 and success >= self.target_selesai
            if (not self.is_stopped() and not _target_reached
                    and _remaining and self.jeda_tiktok_shopee > 0):
                jeda = self.jeda_tiktok_shopee
                self.log(f"━━━ Jeda {jeda}s sebelum video berikutnya ━━━")
                _interruptible_sleep(jeda, self.is_stopped, self.log)

        # Final
        if self.is_stopped():
            final = "berhenti"
        elif self.target_selesai > 0 and success >= self.target_selesai:
            final = "selesai"
        elif error == 0:
            final = "selesai"
        else:
            final = "berhenti"

        ProjectRepo.update_status(self.project_id, final)

        total = success + error
        self.log(f"━━━━━━━━━━ Ringkasan Reupload ━━━━━━━━━━")
        if error == 0:
            self.log(f"🛍 Shopee  ✅ {success}/{total}")
        else:
            self.log(f"🛍 Shopee  ✅ {success}/{total}  ❌ {error}/{total}")
        return success, error
