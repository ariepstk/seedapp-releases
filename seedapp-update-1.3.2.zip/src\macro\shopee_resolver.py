"""
shopee_resolver.py
Resolve URL video Shopee FRESH dari URL produk (kolom rs_produk) saat reupload.
Dipakai sebagai pengganti/penyelamat kalau rs_url kosong atau expired.

Alur: URL produk -> ekstrak shop_id/item_id -> panggil /api/v4/pdp/get_pc
      (dengan cookies sesi Shopee) -> ambil video_info_list -> URL .mp4.

Cookies disimpan/dimuat dari data/shopee_cookies.json (di-set sekali via
endpoint /api/shopee-cookies dari extension, atau manual).
"""

import os
import re
import json
import requests

# curl_cffi meniru TLS fingerprint Chrome → lolos WAF Shopee (requests biasa kena 403).
try:
    from curl_cffi import requests as _cffi
except Exception:
    _cffi = None

COOKIES_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "shopee_cookies.json")

_BASE_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
    "Accept": "application/json",
    "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "x-api-source": "pc",
    "x-shopee-language": "id",
    "x-requested-with": "XMLHttpRequest",
}


# ── Cookies: MULTI-SET (rotasi antar akun) ──────────────────────────
# Disimpan sebagai list: [{"label": "akun 1", "jar": {name:value}}, ...]
# Format lama (dict tunggal) otomatis dimigrasi jadi 1 set.
import random as _random


def load_cookie_sets():
    try:
        with open(COOKIES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return []
    if isinstance(data, dict):  # format lama → 1 set
        if data and all(isinstance(v, str) for v in data.values()):
            return [{"label": "default", "jar": data}]
        return []
    if isinstance(data, list):
        out = []
        for s in data:
            if isinstance(s, dict) and isinstance(s.get("jar"), dict) and s["jar"]:
                e = {"label": str(s.get("label") or "set"), "jar": s["jar"]}
                if isinstance(s.get("cookies"), list) and s["cookies"]:
                    e["cookies"] = s["cookies"]   # atribut lengkap (domain/secure/httpOnly/dll)
                out.append(e)
        return out
    return []


def _save_sets(sets):
    os.makedirs(os.path.dirname(COOKIES_PATH), exist_ok=True)
    with open(COOKIES_PATH, "w", encoding="utf-8") as f:
        json.dump(sets, f)


def add_cookie_set(cookies, label=None):
    """Tambah 1 set cookies (akun). Return jumlah total set sekarang.
    Simpan jar {name:value} (utk HTTP) + 'cookies' atribut LENGKAP (utk browser/login)."""
    jar = _normalize_cookies(cookies)
    if not jar:
        return -1  # tak ada cookie valid
    full = _to_playwright_cookies(cookies)   # atribut lengkap kalau JSON EditThisCookie
    sets = load_cookie_sets()
    entry = {"label": label or ("akun " + str(len(sets) + 1)), "jar": jar}
    if full:
        entry["cookies"] = full
    sets.append(entry)
    _save_sets(sets)
    return len(sets)


def delete_cookie_set(index):
    sets = load_cookie_sets()
    if 0 <= index < len(sets):
        sets.pop(index)
        _save_sets(sets)
        return True
    return False


def clear_cookies():
    try:
        if os.path.exists(COOKIES_PATH):
            os.remove(COOKIES_PATH)
        return True
    except Exception:
        return False


# ── Rotasi merata (LRU) + skip akun bermasalah ─────────────────────
import time as _time
ROTATION_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "cookie_rotation.json")
BLOCK_COOLDOWN_SEC = 15 * 60   # akun yang kena block diistirahatkan 15 menit


def _set_key(s):
    """Kunci stabil per akun: pakai SPC_U (user id Shopee) kalau ada, else label."""
    jar = s.get("jar", {})
    return ("u:" + str(jar["SPC_U"])) if jar.get("SPC_U") else ("l:" + str(s.get("label") or "set"))


def _load_rotation():
    try:
        with open(ROTATION_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_rotation(state):
    try:
        os.makedirs(os.path.dirname(ROTATION_PATH), exist_ok=True)
        tmp = ROTATION_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f)
        os.replace(tmp, ROTATION_PATH)   # tulis atomik (aman dari banyak proses)
    except Exception:
        pass


def _pick_set_index(sets):
    """Inti rotasi MERATA (LRU): pilih akun paling lama tak terpakai yang TIDAK
    sedang cooldown (akibat block). Update last_used. Return (idx, key)."""
    state = _load_rotation()
    now = _time.time()
    keys = [_set_key(s) for s in sets]
    cand = [i for i in range(len(sets)) if state.get(keys[i], {}).get("blocked_until", 0) <= now]
    if not cand:
        cand = list(range(len(sets)))   # semua sedang cooldown → tetap pakai (daripada gagal total)
    oldest = min(state.get(keys[i], {}).get("last_used", 0) for i in cand)
    best = [i for i in cand if state.get(keys[i], {}).get("last_used", 0) == oldest]
    idx = _random.choice(best)          # tie-break acak di antara yang sama-sama paling lama
    key = keys[idx]
    st = state.get(key, {})
    st["last_used"] = now
    state[key] = st
    _save_rotation(state)
    return idx, key


def pick_cookie_jar():
    """Rotasi merata → kembalikan (jar, key). ({}, None) kalau kosong."""
    sets = load_cookie_sets()
    if not sets:
        return {}, None
    idx, key = _pick_set_index(sets)
    return sets[idx]["jar"], key


def pick_cookie_set():
    """Sama spt pick_cookie_jar tapi kembalikan SET utuh (label+jar) + key.
    Dipakai resolver BROWSER: 1 profil Chrome per akun, dirotasi MERATA (LRU)."""
    sets = load_cookie_sets()
    if not sets:
        return None, None
    idx, key = _pick_set_index(sets)
    return sets[idx], key


def mark_blocked(key, seconds=BLOCK_COOLDOWN_SEC):
    """Tandai 1 akun sedang bermasalah → diistirahatkan (di-skip) sampai cooldown habis."""
    if not key:
        return
    state = _load_rotation()
    st = state.get(key, {})
    st["blocked_until"] = _time.time() + seconds
    state[key] = st
    _save_rotation(state)


def cookies_info():
    """Untuk UI: daftar set + jumlah cookies tiap set."""
    sets = load_cookie_sets()
    return {
        "sets": [{"label": s["label"], "count": len(s["jar"])} for s in sets],
        "total_sets": len(sets),
        "total_cookies": sum(len(s["jar"]) for s in sets),
    }


# ── Shim kompatibilitas (extension button & CLI tetap jalan) ──
def save_cookies(cookies, label=None):
    return add_cookie_set(cookies, label or "extension")


def load_cookies():
    return pick_cookie_jar()[0]


def has_cookies():
    return len(load_cookie_sets()) > 0


def _normalize_cookies(cookies):
    # Kalau string yang isinya JSON (mis. export EditThisCookie / [{name,value},...]),
    # parse dulu jadi list/dict sebelum diproses.
    if isinstance(cookies, str):
        s = cookies.strip()
        if s[:1] in ("[", "{"):
            try:
                cookies = json.loads(s)
            except Exception:
                pass
    jar = {}
    if isinstance(cookies, str):
        # Format header "a=b; c=d"
        for part in cookies.split(";"):
            if "=" in part:
                k, v = part.split("=", 1)
                jar[k.strip()] = v.strip()
    elif isinstance(cookies, dict):
        jar = {str(k): str(v) for k, v in cookies.items()}
    elif isinstance(cookies, list):
        for c in cookies:
            if isinstance(c, dict) and c.get("name"):
                jar[str(c["name"])] = str(c.get("value", ""))
    return jar


_SAMESITE_MAP = {"no_restriction": "None", "none": "None", "lax": "Lax", "strict": "Strict"}


def _to_playwright_cookies(cookies):
    """Dari export EditThisCookie (list dict lengkap: domain/path/secure/httpOnly/
    sameSite/expirationDate) → list cookie siap-pakai Playwright dgn atribut DIPERTAHANKAN.
    Penting utk login Shopee: SPC_EC/SPC_ST/SPC_SEC_SI itu httpOnly+secure & domain bisa
    beda (shopee.co.id vs .shopee.co.id). Return [] kalau input bukan format itu
    (mis. header string name=value → tak ada atribut)."""
    if isinstance(cookies, str):
        s = cookies.strip()
        if s[:1] in ("[", "{"):
            try:
                cookies = json.loads(s)
            except Exception:
                return []
        else:
            return []
    if isinstance(cookies, dict):
        cookies = [cookies]
    if not isinstance(cookies, list):
        return []
    out = []
    for c in cookies:
        if not (isinstance(c, dict) and c.get("name")):
            continue
        pc = {
            "name": str(c["name"]),
            "value": str(c.get("value", "")),
            "domain": str(c.get("domain") or ".shopee.co.id"),
            "path": str(c.get("path") or "/"),
            "secure": bool(c.get("secure", False)),
            "httpOnly": bool(c.get("httpOnly", False)),
        }
        ss = _SAMESITE_MAP.get(str(c.get("sameSite", "")).lower())
        if ss == "None" and not pc["secure"]:
            ss = None   # Chromium tolak sameSite=None tanpa secure
        if ss:
            pc["sameSite"] = ss
        exp = c.get("expirationDate")
        if exp and not c.get("session"):
            try:
                pc["expires"] = float(exp)
            except Exception:
                pass
        out.append(pc)
    return out


# ── Parsing ─────────────────────────────────────────────────────────
def extract_ids(product_url):
    """Ambil (shop_id, item_id) dari URL produk Shopee.
    Format: .../nama-i.{shop}.{item}  ATAU  .../product/{shop}/{item}
    """
    if not product_url:
        return None
    m = re.search(r"i\.(\d+)\.(\d+)", product_url) or re.search(r"product/(\d+)/(\d+)", product_url)
    if not m:
        return None
    return m.group(1), m.group(2)


def _pick_video_url(vlist):
    if not isinstance(vlist, list) or not vlist:
        return ""
    v = vlist[0]
    for fmt in (v.get("formats") or []):
        if isinstance(fmt, dict) and fmt.get("url"):
            return fmt["url"]
    df = v.get("default_format")
    if isinstance(df, dict) and df.get("url"):
        return df["url"]
    if v.get("video_url"):
        return v["video_url"]
    if v.get("video_id"):
        return "https://cvf.shopee.co.id/file/" + str(v["video_id"])
    return ""


def _extract_video_from_html(html):
    """Ambil URL mp4 dari video_info_list yang ada di __INITIAL_STATE__ (SSR) halaman produk.
    Halaman HTML tembus WAF; endpoint API get_pc tidak (403). Maka kita parse dari HTML.
    """
    idx = html.find('"video_info_list":')
    if idx < 0:
        return ""
    start = html.find('[', idx)
    if start < 0:
        return ""
    # Bracket-matching untuk ambil array video_info_list lengkap, lalu json.loads.
    depth = 0
    in_str = False
    esc = False
    end = -1
    limit = min(len(html), start + 300000)
    for k in range(start, limit):
        c = html[k]
        if in_str:
            if esc:
                esc = False
            elif c == '\\':
                esc = True
            elif c == '"':
                in_str = False
        else:
            if c == '"':
                in_str = True
            elif c == '[':
                depth += 1
            elif c == ']':
                depth -= 1
                if depth == 0:
                    end = k + 1
                    break
    if end < 0:
        return ""
    try:
        vlist = json.loads(html[start:end])
    except Exception:
        return ""
    return _pick_video_url(vlist)


# ── Resolve ─────────────────────────────────────────────────────────
def resolve_video_url(product_url, log=None, timeout=20):
    """Ambil URL video .mp4 dari URL produk. Return '' kalau gagal.

    Sejak Shopee pindah ke client-side rendering (web ver. 2026.06.v3), HTML
    mentah & API get_pc TIDAK lagi memuat video → UTAMAKAN resolver BROWSER
    (headless Chrome via Playwright, rotasi cookies MERATA antar akun). Fallback
    ke parsing HTML SSR lama hanya kalau Playwright/Chrome tak tersedia.
    """
    if not extract_ids(product_url):
        if log: log(f"⚠ resolver: tidak bisa baca shop/item id dari {product_url}")
        return ""
    # 1) Resolver BROWSER (utama) — satu-satunya yg masih dapat video pasca-CSR.
    try:
        from src.macro.shopee_browser_resolver import resolve_via_browser, browser_available
        if browser_available():
            return resolve_via_browser(product_url, log=log, timeout=max(timeout, 30))
    except Exception as e:
        if log: log(f"⚠ resolver browser tak aktif ({e}); pakai metode HTML lama")
    # 2) Fallback lama (HTML SSR) — dipertahankan kalau Playwright belum terpasang.
    return _resolve_via_html(product_url, log=log, timeout=timeout)


def _resolve_via_html(product_url, log=None, timeout=20):
    """[LAMA] Ambil video dari SSR __INITIAL_STATE__ di HTML. Mati sejak Shopee CSR,
    tapi disisakan sebagai fallback."""
    ids = extract_ids(product_url)
    if not ids:
        return ""
    shop_id, item_id = ids

    jar, ck_key = pick_cookie_jar()   # LRU rotasi + skip akun yg lagi cooldown
    page_url = f"https://shopee.co.id/product/{shop_id}/{item_id}"

    try:
        if _cffi is not None:
            r = _cffi.get(page_url, cookies=jar or None, impersonate="chrome", timeout=timeout)
        else:
            r = requests.get(page_url, headers=_BASE_HEADERS, cookies=jar or None, timeout=timeout)
    except Exception as e:
        if log: log(f"⚠ resolver request gagal: {e}")
        return ""

    if r.status_code in (403, 429):
        mark_blocked(ck_key)   # akun ini bermasalah → istirahatkan
        raise RuntimeError(f"__BLOCKED__ HTTP {r.status_code} saat buka halaman produk")

    html = r.text or ""
    if "video_info_list" not in html:
        # Halaman terlalu kecil + kata kunci verifikasi → kemungkinan diblok/captcha
        if len(html) < 80000 and re.search(r"verif|captcha|robot|akamai", html, re.I):
            mark_blocked(ck_key)
            raise RuntimeError("__BLOCKED__ Halaman verifikasi/captcha")
        if log: log(f"🎬 resolver {item_id}: tidak ada video di halaman")
        return ""

    video = _extract_video_from_html(html)
    if log:
        log(f"🎬 resolver {item_id}: {'OK' if video else 'tidak ada video'}")
    return video


if __name__ == "__main__":
    # Tes mandiri:
    #   Simpan cookies:  python -m src.macro.shopee_resolver savecookies "SPC_F=...; SPC_EC=...; ..."
    #   Resolve video :  python -m src.macro.shopee_resolver "<URL produk Shopee>"
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if len(sys.argv) < 2:
        print("Pakai:")
        print("  Simpan cookies : python -m src.macro.shopee_resolver savecookies \"<isi header Cookie>\"")
        print("  Resolve video  : python -m src.macro.shopee_resolver \"<URL produk Shopee>\"")
        print(f"\nCookies di-load dari: {os.path.abspath(COOKIES_PATH)} | ada: {has_cookies()}")
        sys.exit(0)

    if sys.argv[1] == "savecookies":
        if len(sys.argv) < 3:
            print("Sertakan isi Cookie. Contoh: savecookies \"SPC_F=...; SPC_EC=...\"")
            sys.exit(1)
        n = save_cookies(sys.argv[2])
        print(f"✅ {n} cookies tersimpan di {os.path.abspath(COOKIES_PATH)}")
        sys.exit(0)

    try:
        out = resolve_video_url(sys.argv[1], log=print)
        print("\nHASIL URL VIDEO:", out or "(kosong / tidak ada)")
    except Exception as e:
        print("\nERROR:", e)
