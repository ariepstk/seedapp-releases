"""
worker_process.py — Dijalankan sebagai subprocess terpisah per HP.
Komunikasi via file:
  - log_file  : JSON per baris, UI polling
  - stop_file : kalau file ini ada → berhenti
"""

import sys
import os
import argparse
import json
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)


def log_write(log_file: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    line = json.dumps({"ts": ts, "msg": msg}) + "\n"
    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
    except Exception:
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project_id",    type=int, required=True)
    parser.add_argument("--log_file",      type=str, required=True)
    parser.add_argument("--stop_file",     type=str, required=True)
    parser.add_argument("--device_serial", type=str, default="")
    parser.add_argument("--target",        type=int, default=0)
    parser.add_argument("--watch_min",          type=int, default=600)
    parser.add_argument("--watch_max",          type=int, default=1800)
    parser.add_argument("--jeda_tiktok_shopee", type=int, default=30)
    parser.add_argument("--delay_start_antar_hp", type=int, default=20)
    parser.add_argument("--folder_sound", type=str, default="D:\\TikTok\\sounds")
    parser.add_argument("--folder_frame_border", type=str, default="")
    parser.add_argument("--retry_video_id", type=int, default=0)
    parser.add_argument("--retry_platform", type=str, default="")
    parser.add_argument("--mode", type=str, default="generate_ai")
    parser.add_argument("--hashtag_tambahan", type=str, default="")
    parser.add_argument("--max_retry", type=int, default=10)
    parser.add_argument("--shopee_clone", type=lambda x: x.lower() == 'true', default=None)
    parser.add_argument("--use_mix_sound", type=str, default=None)
    parser.add_argument("--fast_mode", type=lambda x: x.lower() == 'true', default=False)
    args = parser.parse_args()

    # Truncate log file — log selalu fresh setiap start
    try:
        with open(args.log_file, "w", encoding="utf-8") as f:
            pass  # kosongkan file
    except: pass

    def log(msg): log_write(args.log_file, msg)
    def is_stopped(): return os.path.exists(args.stop_file)

    serial = args.device_serial or None

    # Baca shopee_clone, mix_sound, tiktok_search_keywords dari settings.json
    _shopee_clone     = False
    _mix_sound        = True
    _auto_hapus_cache = True
    _tiktok_keywords  = "remix terbaru"
    try:
        _settings_path = os.path.join(os.path.dirname(ROOT), "data", "settings.json")
        if os.path.exists(_settings_path):
            with open(_settings_path, "r", encoding="utf-8") as _sf:
                _s = json.load(_sf)
                _shopee_clone     = _s.get("shopee_clone", False)
                _mix_sound        = _s.get("mix_sound", True)
                _auto_hapus_cache = _s.get("auto_hapus_cache", True)
                _tiktok_keywords  = _s.get("tiktok_search_keywords", "remix terbaru") or "remix terbaru"
    except Exception:
        pass

    # Override shopee_clone jika dikirim dari modal start
    if args.shopee_clone is not None:
        _shopee_clone = args.shopee_clone
    # Override mix_sound dari project setting (hanya Generate AI)
    if args.use_mix_sound is not None and args.mode != 'reupload_shopee':
        _mix_sound = args.use_mix_sound.lower() == 'on'

    log("✅ Mulai upload...")

    try:
        if args.mode == "reupload_shopee":
            from src.macro.runner_reupload import ProjectRunnerReupload
            runner = ProjectRunnerReupload(
                project_id          = args.project_id,
                device_serial       = serial,
                log_fn              = log,
                stop_flag_fn        = is_stopped,
                target_selesai      = args.target,
                watch_min           = args.watch_min,
                watch_max           = args.watch_max,
                jeda_tiktok_shopee  = args.jeda_tiktok_shopee,
                folder_sound        = args.folder_sound,
                folder_frame_border = args.folder_frame_border,
                retry_video_id      = args.retry_video_id,
                hashtag_tambahan    = args.hashtag_tambahan,

                shopee_clone        = _shopee_clone,
                mix_sound           = _mix_sound,
                auto_hapus_cache    = _auto_hapus_cache,
                fast_mode           = args.fast_mode,
            )
        else:
            from src.macro.runner import ProjectRunner
            runner = ProjectRunner(
                project_id          = args.project_id,
                device_serial       = serial,
                log_fn              = log,
                stop_flag_fn        = is_stopped,
                target_selesai      = args.target,
                watch_min           = args.watch_min,
                watch_max           = args.watch_max,
                jeda_tiktok_shopee  = args.jeda_tiktok_shopee,
                retry_video_id      = args.retry_video_id,
                retry_platform      = args.retry_platform,
                folder_sound        = args.folder_sound,
                max_retry           = args.max_retry,

                shopee_clone        = _shopee_clone,
                mix_sound           = _mix_sound,
                auto_hapus_cache    = _auto_hapus_cache,
                fast_mode           = args.fast_mode,
                tiktok_search_keywords = _tiktok_keywords,
            )
        success, error = runner.run()
        log(f"__DONE__ success={success} error={error}")
        sys.exit(0)
    except Exception as e:
        import traceback
        log(f"❌ Fatal error: {e}")
        log(traceback.format_exc())
        sys.exit(1)
    finally:
        # Hapus stop file kalau ada
        try:
            if os.path.exists(args.stop_file):
                os.remove(args.stop_file)
        except: pass


if __name__ == "__main__":
    main()
