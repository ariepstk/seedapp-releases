"""
SeedApp v2 — FastAPI Web Server
Jalankan: python server.py
Buka    : http://localhost:8000
"""

import os
import sys
import json
import asyncio
import subprocess
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional, List, Union

ROOT = os.path.dirname(os.path.abspath(__file__))
INTERNAL_ROOT = os.path.dirname(ROOT)  # _internal/
sys.path.insert(0, ROOT)

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict

from src.core.database import DatasetRepo, VideoRepo, ProjectRepo, SchedHistoryRepo, init_db, get_connection
from src.core.log_manager import log_file_path, stop_file_path
from src.macro import adb_helper
from src.license.checker import check_license, activate, get_hwid, is_activated

# ── Init DB ──────────────────────────────────────────
init_db()

# ── License Check ─────────────────────────────────────
_LICENSE_VALID = False
_LICENSE_MSG   = "not_activated"

def _init_license():
    global _LICENSE_VALID, _LICENSE_MSG
    valid, msg = check_license()
    _LICENSE_VALID = valid
    _LICENSE_MSG   = msg
    pass

_init_license()

VERSION_CHECK_URL = "https://raw.githubusercontent.com/ariepstk/seedapp-releases/main/version.json"
def _read_version():
    try:
        vf = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "version.txt")
        with open(vf, "r") as f: return f.read().strip()
    except: return "0.0.0"
APP_VERSION = _read_version()
SERVER_START_TIME = int(__import__("time").time())

@asynccontextmanager
async def lifespan(app):
    global _scheduler
    # startup
    if _APSCHEDULER_OK:
        _scheduler = AsyncIOScheduler()
        _scheduler.start()
        _scheduler_reschedule()
    yield
    # shutdown
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None

app = FastAPI(title="SeedApp v2", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

# ── Static files ─────────────────────────────────────
STATIC_DIR = os.path.join(ROOT, "static")
# Fallback jika static/ belum ada
os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def root():
    if not _LICENSE_VALID:
        return FileResponse(
            os.path.join(STATIC_DIR, "activate.html"),
            headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache"}
        )
    return FileResponse(
        os.path.join(STATIC_DIR, "index.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache"}
    )


# ── License API ───────────────────────────────────────
class ActivateBody(BaseModel):
    key: str

@app.post("/api/license/activate")
def license_activate(body: ActivateBody):
    global _LICENSE_VALID, _LICENSE_MSG
    ok, msg = activate(body.key)
    if ok:
        _LICENSE_VALID = True
        _LICENSE_MSG   = "ok"
    return {"ok": ok, "message": msg}

@app.get("/api/license/status")
def license_status():
    from src.license.checker import get_license_info
    info = get_license_info()
    return {
        "valid":        _LICENSE_VALID,
        "message":      _LICENSE_MSG,
        "key":          info.get("key", ""),
        "hwid":         get_hwid(),
        "activated_at": info.get("activated_at", ""),
        "last_checked": info.get("last_checked", ""),
    }

@app.get("/api/version")
def get_version():
    return {"version": APP_VERSION, "check_url": VERSION_CHECK_URL, "start_time": SERVER_START_TIME}

# ── Cookies Shopee (multi-set / rotasi akun, untuk resolve video reupload) ──
@app.post("/api/shopee-cookies")
async def add_shopee_cookies(request: Request):
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Body JSON tidak valid")
    cookies = body.get("cookies") if isinstance(body, dict) else None
    label = body.get("label") if isinstance(body, dict) else None
    if not cookies:
        raise HTTPException(400, "Field 'cookies' kosong")
    from src.macro.shopee_resolver import add_cookie_set, cookies_info
    try:
        n = add_cookie_set(cookies, label)
    except Exception as e:
        raise HTTPException(500, f"Gagal simpan cookies: {e}")
    if n < 0:
        raise HTTPException(400, "Tidak ada cookie valid pada input")
    return {"ok": True, "total_sets": n, **cookies_info()}

@app.get("/api/shopee-cookies/status")
def shopee_cookies_status():
    from src.macro.shopee_resolver import cookies_info
    return {"ok": True, **cookies_info()}

@app.delete("/api/shopee-cookies")
def delete_all_shopee_cookies():
    from src.macro.shopee_resolver import clear_cookies
    return {"ok": clear_cookies()}

@app.delete("/api/shopee-cookies/{index}")
def delete_one_shopee_cookie_set(index: int):
    from src.macro.shopee_resolver import delete_cookie_set
    return {"ok": delete_cookie_set(index)}

# ── Slideshow generator (judul + galeri gambar → video 9:16) ──
SS_SETTINGS_FILE = os.path.join(INTERNAL_ROOT, "data", "slideshow_settings.json")
SS_STATE = {"running": False, "done": 0, "total": 0, "ok": 0, "fail": 0, "log": [], "result": "", "stop": False}

def _ss_load_settings():
    try:
        with open(SS_SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

@app.get("/api/slideshow/settings")
def ss_get_settings():
    default_prompt = ""
    try:
        from src.macro.slideshow_generator import DEFAULTS as _SSD
        merged = dict(_SSD); merged.update(_ss_load_settings() or {})
        default_prompt = _SSD.get("ai_prompt", "")
    except Exception:
        merged = _ss_load_settings()
    return {"ok": True, "settings": merged, "default_prompt": default_prompt}

@app.post("/api/slideshow/settings")
async def ss_save_settings(request: Request):
    body = await request.json()
    s = body.get("settings") if isinstance(body, dict) else None
    if not isinstance(s, dict):
        raise HTTPException(400, "settings tidak valid")
    os.makedirs(os.path.dirname(SS_SETTINGS_FILE), exist_ok=True)
    with open(SS_SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(s, f)
    return {"ok": True}

@app.get("/api/slideshow/status")
def ss_status():
    st = dict(SS_STATE)
    st["log"] = SS_STATE["log"][-40:]
    return st

@app.post("/api/slideshow/stop")
def ss_stop():
    SS_STATE["stop"] = True
    return {"ok": True}

SS_PREVIEW_DIR = os.path.join(INTERNAL_ROOT, "data", "ss_preview")

@app.post("/api/slideshow/preview-voice")
async def ss_preview_voice(request: Request):
    """Sintesis 1 kalimat contoh dgn engine/suara terpilih → mp3 utk didengar (tanpa generate video)."""
    body = await request.json()
    settings = (body.get("settings") or {}) if isinstance(body, dict) else {}
    text = (body.get("text") or "").strip() or \
        "Halo guys, produk ini bahannya premium dan nyaman banget. Yuk langsung checkout sekarang!"
    import asyncio
    from src.macro import slideshow_generator as SG
    os.makedirs(SS_PREVIEW_DIR, exist_ok=True)
    # nama file UNIK per request (cegah ke-cache / ketuker antar engine)
    out = os.path.join(SS_PREVIEW_DIR, "preview_%s.mp3" % os.urandom(4).hex())
    try:
        # jalankan di THREAD terpisah → lepas dari event loop FastAPI (edge-tts pakai asyncio.run)
        engine = await asyncio.to_thread(SG._synthesize, text, dict(settings), out, None)
    except Exception as e:
        raise HTTPException(500, f"Gagal sintesis: {e}")
    if not os.path.exists(out) or os.path.getsize(out) < 200:
        raise HTTPException(500, "Suara gagal dibuat")
    # bersihkan file preview lama (sisakan yg ini)
    try:
        for fn in os.listdir(SS_PREVIEW_DIR):
            fp = os.path.join(SS_PREVIEW_DIR, fn)
            if fp != out and fn.startswith("preview_"):
                os.remove(fp)
    except Exception:
        pass
    return FileResponse(out, media_type="audio/mpeg", headers={"X-Engine": engine, "Cache-Control": "no-store"})

@app.get("/api/slideshow/result")
def ss_result():
    p = SS_STATE.get("result")
    if not p or not os.path.exists(p):
        raise HTTPException(404, "Belum ada hasil")
    return FileResponse(p, filename=os.path.basename(p), media_type="text/csv")

def _ss_parse_csv(text):
    import csv, io
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return []
    hdr = [h.strip().lower() for h in rows[0]]
    def col(name): return hdr.index(name) if name in hdr else -1
    ji, gi, pi = col("judul"), col("gambar"), col("produk")
    out = []
    for r in rows[1:]:
        if not any(r): continue
        def g(i): return r[i].strip() if 0 <= i < len(r) and r[i] else ""
        out.append({"judul": g(ji), "gambar": g(gi), "produk": g(pi)})
    return out

def _ss_worker(items, settings):
    import csv, threading
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from src.macro import slideshow_generator as SG
    out_dir = (settings.get("output_folder") or "").strip() or os.path.join(INTERNAL_ROOT, "data", "slideshow_videos")
    os.makedirs(out_dir, exist_ok=True)
    _lock = threading.Lock()
    def log(m):
        SS_STATE["log"].append(m)
    # Jumlah video diproses bersamaan (paralel). Default aman utk multi-core; bisa di-set lewat settings.
    try:
        workers = int(settings.get("ss_workers") or 0)
    except Exception:
        workers = 0
    if workers < 1:
        workers = max(1, min(6, (os.cpu_count() or 4) // 4))
    total = len(items)
    log(f"🚀 Mulai {total} video — {workers} paralel")
    results = {}

    def _one(idx, it):
        if SS_STATE["stop"]:
            return
        title = it.get("judul", "")
        imgs = [u for u in (it.get("gambar", "") or "").split("|") if u.strip()]
        if not title or not imgs:
            with _lock:
                SS_STATE["fail"] += 1; SS_STATE["done"] += 1
            log(f"⚠ #{idx+1} dilewati (judul/gambar kosong)")
            return
        safe = "".join(c for c in title[:40] if c.isalnum() or c in " -_").strip().replace(" ", "_")
        out_path = os.path.join(out_dir, f"ss_{idx+1:04d}_{safe or 'video'}.mp4")
        log(f"▶ #{idx+1}/{total}: {title[:42]}")
        try:
            SG.generate(title, imgs, settings, out_path, log=log)
            with _lock:
                SS_STATE["ok"] += 1; SS_STATE["done"] += 1
                results[idx] = {"judul": title, "file_lokal": out_path, "produk": it.get("produk", "")}
        except Exception as e:
            with _lock:
                SS_STATE["fail"] += 1; SS_STATE["done"] += 1
            log(f"❌ #{idx+1} gagal: {e}")

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(_one, idx, it) for idx, it in enumerate(items)]
        for _ in as_completed(futs):
            if SS_STATE["stop"]:
                break
    result_rows = [results[i] for i in sorted(results)]
    # tulis CSV hasil (kolom File Lokal = path video → siap import ke dataset reupload)
    res_path = os.path.join(out_dir, "slideshow_result.csv")
    with open(res_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Judul", "Url", "Deskripsi", "Gambar", "Sumber", "File Lokal", "Produk", "Keranjang Kuning", "Link Affiliate"])
        for r in result_rows:
            w.writerow([r["judul"], "", "", "", "shopee", r["file_lokal"], r["produk"], "", ""])
    SS_STATE["result"] = res_path
    SS_STATE["running"] = False
    log(f"✅ Selesai — {SS_STATE['ok']} sukses, {SS_STATE['fail']} gagal. CSV: {res_path}")

@app.post("/api/slideshow/run")
async def ss_run(request: Request):
    if SS_STATE["running"]:
        raise HTTPException(400, "Masih ada proses berjalan")
    body = await request.json()
    csv_text = (body.get("csv") or "") if isinstance(body, dict) else ""
    settings = (body.get("settings") or {}) if isinstance(body, dict) else {}
    items = _ss_parse_csv(csv_text)
    if not items:
        raise HTTPException(400, "CSV kosong / tidak ada baris")
    import threading
    SS_STATE.update({"running": True, "done": 0, "total": len(items), "ok": 0, "fail": 0, "log": [], "result": "", "stop": False})
    threading.Thread(target=_ss_worker, args=(items, settings), daemon=True).start()
    return {"ok": True, "total": len(items)}

@app.post("/api/run-update")
def run_update():
    import subprocess, threading
    def _run():
        import time
        time.sleep(1)
        update_bat = os.path.join(INTERNAL_ROOT, "..", "update.bat")
        update_bat = os.path.normpath(update_bat)
        subprocess.Popen(["cmd.exe", "/c", "start", "", update_bat], shell=False)
    threading.Thread(target=_run, daemon=True).start()
    return {"message": "Update dimulai"}


# ══════════════════════════════════════════════════════
#  WEBSOCKET MANAGER
# ══════════════════════════════════════════════════════
class ConnectionManager:
    def __init__(self):
        # project_id -> list of websockets
        self._conns: dict[int, list[WebSocket]] = {}
        # global listeners (project_id = 0)
        self._global: list[WebSocket] = []

    async def connect(self, ws: WebSocket, project_id: int = 0):
        await ws.accept()
        if project_id == 0:
            self._global.append(ws)
        else:
            self._conns.setdefault(project_id, []).append(ws)

    def disconnect(self, ws: WebSocket, project_id: int = 0):
        if project_id == 0:
            self._global = [c for c in self._global if c != ws]
        else:
            if project_id in self._conns:
                self._conns[project_id] = [c for c in self._conns[project_id] if c != ws]

    async def broadcast_log(self, project_id: int, entry: dict):
        """Kirim log ke semua subscriber project ini + global listener."""
        msg = json.dumps({"type": "log", "project_id": project_id, **entry})
        dead = []
        for ws in self._conns.get(project_id, []):
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append((ws, project_id))
        for ws in self._global:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append((ws, 0))
        for ws, pid in dead:
            self.disconnect(ws, pid)

    async def broadcast_status(self, project_id: int, status: str):
        msg = json.dumps({"type": "status", "project_id": project_id, "status": status})
        dead = []
        for ws in self._conns.get(project_id, []) + self._global:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append((ws, project_id if ws in self._conns.get(project_id, []) else 0))
        for ws, pid in dead:
            self.disconnect(ws, pid)

    async def broadcast_event(self, event: dict):
        """Kirim event arbitrer ke semua global listener."""
        msg = json.dumps(event)
        dead = []
        for ws in self._global:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self._global = [c for c in self._global if c != ws]


manager = ConnectionManager()


# ══════════════════════════════════════════════════════
#  LOG POLLER — tail log file per project
# ══════════════════════════════════════════════════════
_pollers: dict[int, asyncio.Task] = {}


async def _poll_log(project_id: int, log_file: str, stop_file: str):
    """Tail log file dan broadcast ke websocket."""
    last_pos = 0
    while True:
        await asyncio.sleep(0.4)
        try:
            if not os.path.exists(log_file):
                continue
            with open(log_file, "r", encoding="utf-8") as f:
                f.seek(last_pos)
                lines = f.readlines()
                last_pos = f.tell()
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    entry = {"ts": datetime.now().strftime("%H:%M:%S"), "msg": line}
                await manager.broadcast_log(project_id, entry)

                # Deteksi selesai
                if "__DONE__" in entry.get("msg", ""):
                    ProjectRepo.update_status(project_id, "selesai")
                    await manager.broadcast_status(project_id, "selesai")
                    _pollers.pop(project_id, None)
                    return
        except Exception:
            pass

        # Cek apakah subprocess masih hidup
        if project_id in _active_procs:
            proc = _active_procs[project_id]
            if proc.poll() is not None:
                # Subprocess sudah berhenti
                _active_procs.pop(project_id, None)
                _pollers.pop(project_id, None)
                proj = ProjectRepo.get_by_id(project_id)
                if proj and proj["status"] == "berjalan":
                    ProjectRepo.update_status(project_id, "berhenti")
                    await manager.broadcast_status(project_id, "berhenti")
                return


_active_procs: dict[int, subprocess.Popen] = {}


# ══════════════════════════════════════════════════════
#  WEBSOCKET ENDPOINTS
# ══════════════════════════════════════════════════════
@app.websocket("/ws/log/{project_id}")
async def ws_log(websocket: WebSocket, project_id: int):
    """Subscribe ke log realtime project tertentu."""
    await manager.connect(websocket, project_id)
    # Kirim log history dulu
    log_file = log_file_path(project_id)
    if os.path.exists(log_file):
        try:
            with open(log_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except Exception:
                        entry = {"ts": "??:??:??", "msg": line}
                    await websocket.send_text(
                        json.dumps({"type": "log", "project_id": project_id, **entry})
                    )
        except Exception:
            pass
    try:
        while True:
            await websocket.receive_text()  # keep alive
    except WebSocketDisconnect:
        manager.disconnect(websocket, project_id)


@app.websocket("/ws/monitor")
async def ws_monitor(websocket: WebSocket):
    """Subscribe ke semua update status project (untuk monitor page)."""
    await manager.connect(websocket, 0)
    # Kirim history log semua project yang punya log file
    try:
        logs_dir = os.path.join(ROOT, "logs")
        if os.path.isdir(logs_dir):
            for fname in sorted(os.listdir(logs_dir)):
                if not fname.startswith("log_") or not fname.endswith(".txt"):
                    continue
                try:
                    pid = int(fname[4:-4])
                except ValueError:
                    continue
                fpath = os.path.join(logs_dir, fname)
                try:
                    with open(fpath, "r", encoding="utf-8") as f2:
                        for line in f2:
                            line = line.strip()
                            if not line:
                                continue
                            try:
                                entry = json.loads(line)
                            except Exception:
                                entry = {"ts": "??:??:??", "msg": line}
                            await websocket.send_text(
                                json.dumps({"type": "log", "project_id": pid, **entry})
                            )
                except Exception:
                    pass
    except Exception:
        pass
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, 0)


@app.get("/api/monitor/history")
async def monitor_history():
    """Return history log semua project untuk populate monLogs di frontend."""
    result = {}
    logs_dir = os.path.join(ROOT, "logs")
    if not os.path.isdir(logs_dir):
        return result
    for fname in sorted(os.listdir(logs_dir)):
        if not fname.startswith("log_") or not fname.endswith(".txt"):
            continue
        try:
            pid = int(fname[4:-4])
        except ValueError:
            continue
        fpath = os.path.join(logs_dir, fname)
        entries = []
        try:
            with open(fpath, "r", encoding="utf-8") as f2:
                for line in f2:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except Exception:
                        entry = {"ts": "??:??:??", "msg": line}
                    entries.append(entry)
        except Exception:
            pass
        if entries:
            result[str(pid)] = entries
    return result


@app.delete("/api/monitor/logs/{project_id}")
async def delete_monitor_log(project_id: int):
    """Hapus log file untuk project tertentu."""
    fpath = os.path.join(ROOT, "logs", f"log_{project_id}.txt")
    try:
        if os.path.exists(fpath):
            os.remove(fpath)
    except Exception:
        pass
    return {"ok": True}


# ══════════════════════════════════════════════════════
#  DATASET API
# ══════════════════════════════════════════════════════
class DatasetCreate(BaseModel):
    name: str
    description: str = ""
    format: str = "generate_ai"

class DatasetUpdate(BaseModel):
    name: str
    description: str = ""


@app.get("/api/datasets")
def get_datasets():
    return DatasetRepo.get_all()


@app.post("/api/datasets/sync-all")
async def sync_all_spreadsheets_now():
    """Manual trigger: sync semua dataset yang punya spreadsheet terdaftar."""
    result = await _sync_all_spreadsheets()
    return result


@app.post("/api/datasets/{dataset_id}/sync-auto")
async def sync_single_dataset_auto(dataset_id: int):
    """Sync 1 dataset menggunakan spreadsheet_url yang sudah tersimpan di DB.
    Flow: sync dulu → dedup belakangan (hapus baris duplikat link_tiktok dalam dataset).
    """
    import re as _re4
    from src.core.database import get_connection
    ds = DatasetRepo.get_by_id(dataset_id)
    if not ds:
        raise HTTPException(404, "Dataset tidak ditemukan")

    # Opsi A: Global URL always wins. Per-dataset URL cuma fallback legacy.
    settings = load_settings()
    global_url = settings.get("global_spreadsheet_url", "")
    ss_url = global_url or ds.get("spreadsheet_url", "")
    if not ss_url:
        raise HTTPException(400, "Dataset belum punya spreadsheet URL (set di Settings > Spreadsheet URL Global)")
    m = _re4.search(r'/spreadsheets/d/([^/#?]+)', ss_url)
    if not m:
        raise HTTPException(400, "URL bukan Google Sheets yang valid")
    sheet_id = m.group(1)
    # Tab name: kalau pakai global, tab name = nama dataset. Kalau per-dataset URL, pakai sheet_name tersimpan.
    if global_url:
        sheet_name = ds.get("name", "") or None
    else:
        sheet_name = ds.get("sheet_name", "") or ds.get("name", "") or None

    # Fetch with retry
    rows = None
    last_err = None
    for attempt in range(3):
        try:
            rows = await asyncio.to_thread(
                _fetch_sheet_rows, sheet_id, sheet_name=sheet_name, spreadsheet_url=ss_url
            )
            break
        except Exception as e:
            last_err = e
            if attempt < 2:
                await asyncio.sleep(2)
    if rows is None:
        raise HTTPException(502, f"Gagal fetch: {last_err}")

    if len(rows) < 2:
        return {"dataset": ds["name"], "new": 0, "error": "Sheet kosong"}

    hdr = [h.strip().lower() if h else "" for h in rows[0]]
    def _hc(name, fb=None):
        try: return hdr.index(name.lower())
        except ValueError: return _col_index(fb) if fb else -1
    vi  = _hc("video_result", "G")
    pi  = _hc("product_shopee", "C")
    ci  = _hc("caption_shopee", "B")
    cti = _hc("caption_tiktok")
    lti = _hc("link_tiktok")
    kti = _hc("keranjang_tiktok")
    def g(row, i): return row[i].strip() if i >= 0 and i < len(row) else ""

    # Dedup by link_tiktok (stabil), fallback video_result
    # Build map untuk auto-update video_result kalau URL berubah (CDN → Gdrive)
    conn = get_connection()
    try:
        existing = {}  # {dedup_key: {"id": int, "video_result": str}}
        for r in conn.execute(
            "SELECT id, link_tiktok, video_result FROM video_items WHERE dataset_id=?",
            (dataset_id,)).fetchall():
            k = (r[1] or '').strip() or (r[2] or '').strip()
            if k:
                existing[k] = {"id": r[0], "video_result": (r[2] or '').strip()}
        max_no = conn.execute(
            "SELECT COALESCE(MAX(CAST(no AS INTEGER)),0) FROM video_items WHERE dataset_id=?",
            (dataset_id,)).fetchone()[0]
    finally:
        conn.close()
    next_no = int(max_no) + 1

    to_insert = []
    to_update = []  # [(video_id, new_url), ...]
    row_numbers_new = []
    row_numbers_existing = []
    for i, row in enumerate(rows[1:], start=2):
        video_url = g(row, vi)
        if not video_url or not _validate_video_url(video_url):
            continue
        link_tt = g(row, lti)
        dedup_key = link_tt or video_url
        if dedup_key in existing:
            ex = existing[dedup_key]
            # Kalau URL berubah → schedule update
            if ex.get("id") and ex.get("video_result") != video_url:
                to_update.append((ex["id"], video_url))
            row_numbers_existing.append(i)
            continue
        to_insert.append((dataset_id, next_no, g(row, ci), g(row, pi),
                           g(row, cti), link_tt, g(row, kti), video_url))
        row_numbers_new.append(i)
        existing[dedup_key] = {"id": -1, "video_result": video_url}
        next_no += 1

    # Apply UPDATEs (URL change)
    if to_update:
        conn_u = get_connection()
        try:
            for vid, new_url in to_update:
                conn_u.execute(
                    "UPDATE video_items SET video_result=? WHERE id=?",
                    (new_url, vid)
                )
            conn_u.commit()
        finally:
            conn_u.close()

    if to_insert:
        conn2 = get_connection()
        try:
            conn2.executemany("""
                INSERT OR IGNORE INTO video_items
                (dataset_id,no,caption_shopee,product_shopee,
                 caption_tiktok,link_tiktok,keranjang_tiktok,video_result)
                VALUES (?,?,?,?,?,?,?,?)
            """, to_insert)
            conn2.commit()
        finally:
            conn2.close()
        _sync_project_videos_for_dataset(dataset_id)

    # Update kolom H di Google Sheet → "Shopee Sync" (baru + existing)
    all_rows_to_mark = row_numbers_new + row_numbers_existing
    if all_rows_to_mark:
        try:
            _update_sheet_column_h(sheet_id, sheet_name or "", all_rows_to_mark)
        except Exception:
            pass  # gagal update sheet tidak block sync

    # ── Auto-dedup (AFTER sync): hapus duplikat link_tiktok kalau ada ──
    duplicates_removed = 0
    dedup_conn = get_connection()
    try:
        cur = dedup_conn.execute("""
            DELETE FROM video_items
            WHERE id IN (
              SELECT v.id FROM video_items v
              WHERE v.dataset_id = ?
                AND COALESCE(v.link_tiktok,'') != ''
                AND EXISTS (
                  SELECT 1 FROM video_items v2
                  WHERE v2.dataset_id = v.dataset_id
                    AND COALESCE(v2.link_tiktok,'') = COALESCE(v.link_tiktok,'')
                    AND v2.id < v.id
                )
            )
        """, (dataset_id,))
        duplicates_removed = cur.rowcount or 0
        dedup_conn.commit()
    finally:
        dedup_conn.close()

    return {"dataset": ds["name"], "new": len(to_insert), "updated": len(to_update), "duplicates_removed": duplicates_removed}


@app.get("/api/datasets/{dataset_id}")
def get_dataset(dataset_id: int):
    ds = DatasetRepo.get_by_id(dataset_id)
    if not ds:
        raise HTTPException(404, "Dataset tidak ditemukan")
    return ds


@app.post("/api/datasets")
def create_dataset(body: DatasetCreate):
    ds_id = DatasetRepo.create(body.name, body.description, body.format)
    return {"id": ds_id, "message": "Dataset berhasil dibuat"}


@app.put("/api/datasets/{dataset_id}")
def update_dataset(dataset_id: int, body: DatasetUpdate):
    DatasetRepo.update(dataset_id, body.name, body.description)
    return {"message": "Dataset diupdate"}


@app.delete("/api/datasets/{dataset_id}")
def delete_dataset(dataset_id: int):
    DatasetRepo.delete(dataset_id)
    return {"message": "Dataset dihapus"}


@app.get("/api/datasets/{dataset_id}/videos")
def get_videos(dataset_id: int):
    return VideoRepo.get_by_dataset(dataset_id)


@app.delete("/api/datasets/{dataset_id}/videos/{video_id}")
def delete_video(dataset_id: int, video_id: int):
    """Soft delete — set deleted=1 biar tidak re-import saat sync berikutnya."""
    from src.core.database import get_connection
    conn = get_connection()
    try:
        conn.execute(
            "UPDATE video_items SET deleted=1 WHERE id=? AND dataset_id=?",
            (video_id, dataset_id),
        )
        # Mark semua project_videos yang pakai video ini sebagai skip
        conn.execute(
            "UPDATE project_videos SET status='skip', updated_at=datetime('now','localtime') "
            "WHERE video_id=?",
            (video_id,),
        )
        conn.commit()
    finally:
        conn.close()
    return {"message": "Video dihapus"}


@app.post("/api/datasets/{dataset_id}/import")
async def import_dataset_xlsx(dataset_id: int, request: Request):
    """Import xlsx/csv — auto-detect format dari header."""
    import base64, io
    try:
        body = await request.json()
        b64 = body.get("file_b64", "")
        fname = body.get("filename", "").lower()
        data = base64.b64decode(b64)

        rows_raw = []

        if fname.endswith(".csv"):
            import csv
            text = data.decode("utf-8-sig", errors="replace")
            reader = csv.reader(io.StringIO(text))
            rows_raw = list(reader)
        else:
            try:
                import openpyxl
                wb = openpyxl.load_workbook(io.BytesIO(data), data_only=True)
                ws = wb.active
                rows_raw = [[c.value for c in row] for row in ws.iter_rows()]
            except ImportError:
                raise HTTPException(500, "openpyxl belum terinstall")

        if not rows_raw:
            raise HTTPException(400, "File kosong")

        # Normalize headers
        raw_headers = [str(h).strip().lower() if h else "" for h in rows_raw[0]]

        def col(name):
            try: return raw_headers.index(name.lower())
            except ValueError: return -1

        # Ambil format dari dataset DB (tidak auto-detect lagi)
        ds_info = DatasetRepo.get_by_id(dataset_id)
        ds_format = body.get("format") or (ds_info.get("format") if ds_info else "generate_ai") or "generate_ai"
        is_reupload = ds_format == "reupload_shopee"

        items = []
        if is_reupload:
            # Format Reupload Shopee
            j_i  = col("judul");   u_i  = col("url");       d_i  = col("deskripsi")
            g_i  = col("gambar");  s_i  = col("sumber");    fl_i = col("file lokal")
            p_i  = col("produk");  kk_i = col("keranjang kuning"); la_i = col("link affiliate")
            def g(r, i): return str(r[i]).strip() if i >= 0 and i < len(r) and r[i] is not None else ""
            auto_no = 0
            for row in rows_raw[1:]:
                if not any(row): continue
                auto_no += 1
                items.append({
                    "no":                  str(auto_no),
                    # Kolom rs_* khusus Reupload Shopee
                    "rs_judul":            g(row, j_i),
                    "rs_url":              g(row, u_i),
                    "rs_deskripsi":        g(row, d_i),
                    "rs_gambar":           g(row, g_i),
                    "rs_sumber":           g(row, s_i),
                    "rs_file_lokal":       g(row, fl_i),
                    "rs_produk":           g(row, p_i),
                    "rs_keranjang_kuning": g(row, kk_i),
                    "rs_link_affiliate":   g(row, la_i),
                })
            format_label = "Reupload Shopee"
        else:
            # Format Generate AI
            no_i = col("no");  cs_i = col("caption_shopee"); ps_i = col("product_shopee")
            ct_i = col("caption_tiktok"); lt_i = col("link_tiktok")
            kt_i = col("keranjang_tiktok"); vr_i = col("video_result")
            def g(r, i): return str(r[i]).strip() if i >= 0 and i < len(r) and r[i] is not None else ""
            for row in rows_raw[1:]:
                if not any(row): continue
                items.append({
                    "no": g(row, no_i), "caption_shopee": g(row, cs_i), "product_shopee": g(row, ps_i),
                    "caption_tiktok": g(row, ct_i), "link_tiktok": g(row, lt_i),
                    "keranjang_tiktok": g(row, kt_i), "video_result": g(row, vr_i)
                })
            format_label = "Generate AI"

        if not items:
            raise HTTPException(400, "Tidak ada data yang bisa diimport")

        # ── Blacklist filter (Reupload Shopee saja) ──
        blacklisted_count = 0
        if is_reupload:
            settings_data = {}
            try:
                settings_path = SETTINGS_FILE
                if os.path.exists(settings_path):
                    with open(settings_path, "r", encoding="utf-8") as sf:
                        settings_data = json.load(sf)
            except Exception:
                pass
            keywords = [k.strip().lower() for k in settings_data.get("blacklist_keywords", []) if k.strip()]
            if keywords:
                filtered = []
                for item in items:
                    judul = item.get("rs_judul", "").lower()
                    if any(kw in judul for kw in keywords):
                        blacklisted_count += 1
                    else:
                        filtered.append(item)
                # Re-nomor setelah filter
                for i, item in enumerate(filtered):
                    item["no"] = str(i + 1)
                items = filtered

        VideoRepo.bulk_insert(dataset_id, items)
        DatasetRepo.update_format(dataset_id, "reupload_shopee" if is_reupload else "generate_ai")

        added = len(items)
        if is_reupload and blacklisted_count > 0:
            msg = f"✅ Import selesai — {added} video berhasil ditambahkan & {blacklisted_count} berhasil dihapus blacklist"
        else:
            msg = f"Berhasil import {added} baris ({format_label})"
        return {"message": msg, "count": added, "blacklisted": blacklisted_count, "format": ds_format}
    except HTTPException: raise
    except Exception as e:
        raise HTTPException(400, str(e))


# ══════════════════════════════════════════════════════
#  SYNC SPREADSHEET API
# ══════════════════════════════════════════════════════

@app.get("/api/sheets-meta")
def get_sheets_meta(url: str):
    """Fetch daftar sheet tabs. Prioritas: OAuth API → scraping HTML publik."""
    import re, requests as _req

    m = re.search(r'/spreadsheets/d/([^/#?]+)', url.strip())
    if not m:
        raise HTTPException(400, "URL tidak valid")
    sheet_id = m.group(1)

    # Coba OAuth API dulu (Sheets API v4 spreadsheets.get)
    try:
        access_token = get_google_access_token()
        resp = _req.get(
            f"https://sheets.googleapis.com/v4/spreadsheets/{sheet_id}?fields=sheets.properties.title",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        sheets = [{"name": s["properties"]["title"]} for s in data.get("sheets", [])]
        if sheets:
            return {"sheets": sheets, "sheet_id": sheet_id}
    except Exception:
        pass  # fallback ke scraping HTML publik

    # Fallback: scraping HTML (hanya works jika sheet public)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
    try:
        resp = _req.get(
            f"https://docs.google.com/spreadsheets/d/{sheet_id}/edit",
            headers=headers, timeout=20, allow_redirects=True
        )
        resp.raise_for_status()
        names = re.findall(r'docs-sheet-tab-caption\">([^<]+)<', resp.text)
        if names:
            return {"sheets": [{"name": n.strip()} for n in names if n.strip()], "sheet_id": sheet_id}
    except Exception:
        pass

    raise HTTPException(403, "Tidak bisa membaca daftar tab — hubungkan Google di Settings atau share sheet ke publik")


class SyncSpreadsheetBody(BaseModel):
    spreadsheet_url: str
    video_col:   str = "G"
    product_col: str = "C"
    caption_col: str = "B"
    dedup:      bool = True
    dry_run:    bool = False
    gid:        Optional[str] = None        # fallback GID manual
    sheet_name: Optional[str] = None       # nama tab (prioritas utama)
    update_sheet_status: bool = False   # Write "Shopee Sync" ke kolom H
    clean_sync: bool = False            # Hapus baris yang tidak ada lagi di Sheet (preserve history)


def _col_index(letter: str) -> int:
    """'A' → 0, 'B' → 1, ... 'Z' → 25"""
    return ord(letter.strip().upper()[0]) - ord('A')


def _to_export_url(url: str, gid_override: str = None, sheet_name: str = None) -> str:
    """Konversi Google Sheets URL → CSV.
    Prioritas: sheet_name (gviz) > gid_override > gid dari URL > default gid=0
    """
    import re, urllib.parse
    url = url.strip()
    m = re.search(r'/spreadsheets/d/([^/#?]+)', url)
    if not m:
        if "export?format=csv" in url or "gviz/tq" in url:
            return url
        raise ValueError("URL bukan Google Sheets yang valid")
    sheet_id = m.group(1)

    # Pakai gviz/tq?sheet=NAME — paling andal, tidak butuh GID
    if sheet_name:
        return (f"https://docs.google.com/spreadsheets/d/{sheet_id}"
                f"/gviz/tq?tqx=out:csv&sheet={urllib.parse.quote(sheet_name)}")

    # Fallback ke gid
    if gid_override:
        gid = gid_override
    else:
        gid_m = re.search(r'[#&?]gid=(\d+)', url)
        gid = gid_m.group(1) if gid_m else "0"
    return f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"


def _validate_video_url(url: str) -> bool:
    """True jika URL adalah B-CDN atau Google Drive."""
    url = url.strip()
    return (
        url.startswith("https://s-storage.b-cdn.net/") or
        url.startswith("https://drive.google.com/") or
        url.startswith("http://s-storage.b-cdn.net/")
    )


@app.post("/api/datasets/{dataset_id}/sync-spreadsheet")
async def sync_spreadsheet(dataset_id: int, body: SyncSpreadsheetBody):
    from src.core.database import get_connection

    ds = DatasetRepo.get_by_id(dataset_id)
    if not ds:
        raise HTTPException(404, "Dataset tidak ditemukan")

    # Ambil sheet_id dari URL
    import re as _re2
    m2 = _re2.search(r'/spreadsheets/d/([^/#?]+)', body.spreadsheet_url)
    if not m2:
        raise HTTPException(400, "URL bukan Google Sheets yang valid")
    sheet_id_str = m2.group(1)

    # Fetch rows — OAuth API jika tersambung, fallback CSV public
    try:
        rows = _fetch_sheet_rows(
            sheet_id_str,
            sheet_name=body.sheet_name,
            gid=body.gid,
            spreadsheet_url=body.spreadsheet_url,
        )
    except Exception as e:
        raise HTTPException(502, f"Gagal fetch spreadsheet: {e}")

    if len(rows) < 2:
        raise HTTPException(400, "Spreadsheet kosong atau hanya header")

    # Detect kolom dari header row (prioritas) — fallback ke letter-based
    header_row = [h.strip().lower() if h else "" for h in rows[0]]
    def _hcol(name, fallback_letter=None):
        try: return header_row.index(name.lower())
        except ValueError: return _col_index(fallback_letter) if fallback_letter else -1

    vi  = _hcol("video_result",     body.video_col)
    pi  = _hcol("product_shopee",   body.product_col)
    ci  = _hcol("caption_shopee",   body.caption_col)
    cti = _hcol("caption_tiktok")
    lti = _hcol("link_tiktok")
    kti = _hcol("keranjang_tiktok")

    def g(row, i):
        return row[i].strip() if i >= 0 and i < len(row) else ""

    # Dedup by link_tiktok (stabil terhadap perubahan URL video CDN → Gdrive).
    # Fallback ke video_result kalau link_tiktok kosong.
    # Build key→(id, video_result) map untuk auto-update saat URL berubah.
    existing_keys: dict = {}  # {dedup_key: {"id": int, "video_result": str}}
    next_no = 1
    conn = get_connection()
    try:
        if body.dedup:
            rows_db = conn.execute(
                "SELECT id, link_tiktok, video_result FROM video_items WHERE dataset_id=?",
                (dataset_id,)
            ).fetchall()
            for r in rows_db:
                k = (r[1] or '').strip() or (r[2] or '').strip()
                if k:
                    existing_keys[k] = {"id": r[0], "video_result": (r[2] or '').strip()}
        max_no = conn.execute(
            "SELECT COALESCE(MAX(CAST(no AS INTEGER)),0) FROM video_items WHERE dataset_id=?",
            (dataset_id,)
        ).fetchone()[0]
        next_no = int(max_no) + 1
    finally:
        conn.close()

    imported, skipped, updated, error_list = 0, 0, 0, []
    items_to_insert = []
    items_to_update = []   # [(video_id, new_video_result), ...]
    row_numbers_to_update = []

    for i, row in enumerate(rows[1:], start=2):  # baris ke-2 dst (skip header)
        video_url = g(row, vi)
        if not video_url:
            skipped += 1
            continue
        if not _validate_video_url(video_url):
            # Hitung sebagai error, bukan skipped
            error_list.append({"row": i, "url": video_url, "reason": "URL tidak valid (bukan B-CDN/Drive)"})
            continue
        link_tt = g(row, lti)
        dedup_key = link_tt or video_url
        if body.dedup and dedup_key in existing_keys:
            existing = existing_keys[dedup_key]
            # Kalau URL berubah → schedule UPDATE (CDN → Gdrive case)
            if existing["video_result"] != video_url:
                items_to_update.append((existing["id"], video_url))
                updated += 1
            else:
                skipped += 1
            continue
        existing_keys[dedup_key] = {"id": -1, "video_result": video_url}  # mark inserted
        items_to_insert.append({
            "no":               next_no,
            "caption_shopee":   g(row, ci),
            "product_shopee":   g(row, pi),
            "caption_tiktok":   g(row, cti),
            "link_tiktok":      g(row, lti),
            "keranjang_tiktok": g(row, kti),
            "video_result":     video_url,
        })
        row_numbers_to_update.append(i)
        next_no += 1
        imported += 1

    # dry_run: hanya preview, tidak insert
    projects_synced = 0
    sheet_update_result = {"success": False, "updated": 0, "error": None}
    cleaned_count = 0      # baris dihapus (orphan tanpa history)
    preserved_count = 0    # baris di-skip (orphan dengan history upload)
    if not body.dry_run:
        # ── UPDATE existing rows yang URL-nya berubah (CDN → Gdrive) ──
        if items_to_update:
            conn_u = get_connection()
            try:
                for vid_id, new_url in items_to_update:
                    conn_u.execute(
                        "UPDATE video_items SET video_result=? WHERE id=?",
                        (new_url, vid_id)
                    )
                conn_u.commit()
            finally:
                conn_u.close()

        if items_to_insert:
            conn2 = get_connection()
            try:
                for item in items_to_insert:
                    conn2.execute("""
                        INSERT OR IGNORE INTO video_items
                        (dataset_id,no,caption_shopee,product_shopee,caption_tiktok,
                         link_tiktok,keranjang_tiktok,video_result)
                        VALUES (?,?,?,?,?,?,?,?)
                    """, (
                        dataset_id, item['no'],
                        item['caption_shopee'], item['product_shopee'],
                        item['caption_tiktok'], item['link_tiktok'],
                        item['keranjang_tiktok'], item['video_result'],
                    ))
                conn2.commit()
            finally:
                conn2.close()

            # Sync project_videos — tambahkan video baru ke semua project yang pakai dataset ini
            projects_synced = _sync_project_videos_for_dataset(dataset_id)

        # ── CLEAN SYNC: hapus baris yang tidak ada lagi di Sheet ──
        # Pakai dedup key link_tiktok (stabil), fallback video_result
        if body.clean_sync:
            sheet_keys = set()
            for row in rows[1:]:
                url = g(row, vi)
                if url and _validate_video_url(url):
                    link_tt = g(row, lti)
                    sheet_keys.add(link_tt or url)

            conn3 = get_connection()
            try:
                orphans = conn3.execute(
                    "SELECT id, link_tiktok, video_result FROM video_items WHERE dataset_id=? AND COALESCE(deleted,0)=0",
                    (dataset_id,)
                ).fetchall()

                delete_ids = []
                skip_ids   = []
                for vi_id, vi_link, vi_url in orphans:
                    vi_key = (vi_link or '').strip() or (vi_url or '').strip()
                    if vi_key in sheet_keys:
                        continue
                    has_history = conn3.execute("""
                        SELECT COUNT(*) FROM project_videos
                        WHERE video_id=? AND (
                            status_shopee IN ('selesai','error')
                            OR status_tiktok IN ('selesai','error')
                        )
                    """, (vi_id,)).fetchone()[0]
                    if has_history > 0:
                        skip_ids.append(vi_id)
                    else:
                        delete_ids.append(vi_id)

                if delete_ids:
                    ph = ",".join("?" * len(delete_ids))
                    conn3.execute(f"DELETE FROM video_items WHERE id IN ({ph})", delete_ids)
                    cleaned_count = len(delete_ids)
                if skip_ids:
                    ph2 = ",".join("?" * len(skip_ids))
                    conn3.execute(
                        f"UPDATE project_videos SET status='skip', updated_at=datetime('now','localtime') "
                        f"WHERE video_id IN ({ph2})",
                        skip_ids,
                    )
                    preserved_count = len(skip_ids)
                conn3.commit()
            finally:
                conn3.close()

        # Simpan spreadsheet info ke dataset (untuk daily sync) — selalu, bukan hanya saat ada item baru
        DatasetRepo.update_spreadsheet(
            dataset_id,
            body.spreadsheet_url,
            body.sheet_name or "",
        )

        # Write-back ke Google Sheets jika diminta
        if body.update_sheet_status and row_numbers_to_update:
            import re as _re
            m = _re.search(r'/spreadsheets/d/([^/#?]+)', body.spreadsheet_url)
            if m:
                sheet_update_result = _update_sheet_column_h(
                    m.group(1), body.sheet_name or "", row_numbers_to_update
                )

    return {
        "imported":       imported if not body.dry_run else 0,
        "would_import":   imported if body.dry_run else None,
        "skipped":        skipped,
        "updated":        updated if not body.dry_run else 0,
        "errors":         len(error_list),
        "details":        error_list[:20],
        "dry_run":        body.dry_run,
        "projects_synced": projects_synced,
        "export_url":     body.spreadsheet_url,
        "sheet_update":   sheet_update_result,
        "updated_rows":   sheet_update_result.get("updated", 0),
        "cleaned":        cleaned_count,
        "preserved":      preserved_count,
    }


@app.post("/api/datasets/{dataset_id}/sync-spreadsheet-and-update")
async def sync_spreadsheet_and_update(dataset_id: int, body: SyncSpreadsheetBody):
    """Sync spreadsheet + update kolom H = 'Shopee Sync' untuk baris yang diimport."""
    # Pydantic model immutable — buat copy dengan update_sheet_status=True
    data = body.dict() if hasattr(body, "dict") else body.model_dump()
    data["update_sheet_status"] = True
    new_body = SyncSpreadsheetBody(**data)
    return await sync_spreadsheet(dataset_id, new_body)


def _sync_project_videos_for_dataset(dataset_id: int) -> int:
    """Tambahkan video baru ke project_videos semua project yang pakai dataset ini."""
    conn = get_connection()
    try:
        projects = conn.execute(
            "SELECT id FROM projects WHERE dataset_id=?", (dataset_id,)
        ).fetchall()
    finally:
        conn.close()
    for p in projects:
        VideoRepo.init_project_videos(p[0], dataset_id)
    return len(projects)


# ══════════════════════════════════════════════════════
#  PROJECT API
# ══════════════════════════════════════════════════════
class ProjectCreate(BaseModel):
    name: str
    description: str = ""
    dataset_id: Optional[int] = None
    device_serial: str = ""
    upload_target: str = "shopee_tiktok"
    mode: str = "generate_ai"
    rs_use_frame: str = "on"
    rs_use_song: str = "on"
    use_mix_sound: str = "on"
    sched_enabled: str = "off"
    sched_target: int = 10
    shopee_username: str = ""


class ProjectUpdate(BaseModel):
    name: str
    description: str = ""
    dataset_id: Optional[int] = None
    device_serial: str = ""
    upload_target: str = "shopee_tiktok"
    mode: str = "generate_ai"
    status: str = "antrian"
    rs_use_frame: str = "on"
    rs_use_song: str = "on"
    use_mix_sound: str = "on"
    sched_enabled: str = "off"
    sched_target: int = 10
    shopee_username: str = ""


@app.get("/api/projects")
def get_projects():
    return ProjectRepo.get_all()


@app.get("/api/projects/steps")
def get_project_steps():
    """Return step upload terkini untuk semua project yang sedang berjalan."""
    import re
    result = {}
    running = [p for p in ProjectRepo.get_all() if p.get("status") == "berjalan"]
    for p in running:
        project_id = p["id"]
        lf = log_file_path(project_id)
        if not os.path.exists(lf):
            continue
        try:
            with open(lf, "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in reversed(lines[-100:]):
                try:
                    data = json.loads(line.strip())
                    msg = data.get("msg", "")
                    m = re.search(r'\[(\d+)/10\]', msg)
                    if m:
                        result[project_id] = {"step": int(m.group(1)), "msg": msg}
                        break
                except Exception:
                    pass
        except Exception:
            pass
    return result


@app.get("/api/projects/{project_id}")
def get_project(project_id: int):
    p = ProjectRepo.get_by_id(project_id)
    if not p:
        raise HTTPException(404, "Project tidak ditemukan")
    stats = VideoRepo.get_stats_by_project(project_id)
    return {**p, **stats}


def _check_duplicate_device_username(device_serial: str, shopee_username: str, exclude_id: int = None):
    """Cek apakah kombinasi HP + username sudah dipakai project lain."""
    if not device_serial or not shopee_username:
        return
    all_projects = ProjectRepo.get_all()
    for p in all_projects:
        if exclude_id and p["id"] == exclude_id:
            continue
        if p.get("device_serial") == device_serial and (p.get("shopee_username") or "").lower() == shopee_username.lower():
            raise HTTPException(400, f"HP {device_serial} sudah punya project dengan username '{shopee_username}'")


@app.post("/api/projects")
def create_project(body: ProjectCreate):
    _check_duplicate_device_username(body.device_serial, body.shopee_username)
    pid = ProjectRepo.create(
        body.name, body.description,
        body.dataset_id, body.device_serial, body.upload_target, body.mode,
        body.rs_use_frame, body.rs_use_song, body.use_mix_sound,
        body.sched_enabled, body.sched_target, body.shopee_username
    )
    return {"id": pid, "message": "Project berhasil dibuat"}


@app.put("/api/projects/{project_id}")
def update_project(project_id: int, body: ProjectUpdate):
    p = ProjectRepo.get_by_id(project_id)
    if not p:
        raise HTTPException(404)
    _check_duplicate_device_username(body.device_serial, body.shopee_username, exclude_id=project_id)
    ProjectRepo.update(
        project_id, body.name, body.description,
        body.dataset_id, body.status, body.device_serial, body.upload_target, body.mode,
        body.rs_use_frame, body.rs_use_song, body.use_mix_sound,
        body.sched_enabled, body.sched_target, body.shopee_username
    )
    _scheduler_reschedule()
    return {"message": "Project diupdate"}


@app.delete("/api/projects/{project_id}")
def delete_project(project_id: int):
    ProjectRepo.delete(project_id)
    return {"message": "Project dihapus"}


@app.get("/api/projects/{project_id}/videos")
def get_project_videos(project_id: int, status: str = "semua"):
    return VideoRepo.get_by_project(project_id, status)


@app.get("/api/projects/{project_id}/stats")
def get_project_stats(project_id: int):
    return VideoRepo.get_stats_by_project(project_id)


# ── START / STOP ──────────────────────────────────────
class StartBody(BaseModel):
    target: int = 2
    watch_min: int = 600
    watch_max: int = 1800
    shopee_clone: bool = False
    jeda_tiktok_shopee: int = 30
    delay_start_antar_hp: int = 20
    folder_sound: str = "D:\\TikTok\\sounds"
    folder_frame_border: str = "D:\\TikTok\\SeedApp v2\\Frame GIF"
    hashtag_tambahan: str = ""
    max_retry: int = 10


@app.post("/api/projects/{project_id}/start")
async def start_project(project_id: int, body: StartBody):
    p = ProjectRepo.get_by_id(project_id)
    if not p:
        raise HTTPException(404, "Project tidak ditemukan")
    if project_id in _active_procs and _active_procs[project_id].poll() is None:
        return {"message": "Sudah berjalan"}

    # Bersihkan stop file
    stop_file = stop_file_path(project_id)
    log_file  = log_file_path(project_id)
    try:
        if os.path.exists(stop_file):
            os.remove(stop_file)
    except Exception:
        pass

    worker_script = os.path.join(ROOT, "src", "core", "worker_process.py")
    cmd = [
        sys.executable, worker_script,
        f"--project_id={project_id}",
        f"--log_file={log_file}",
        f"--stop_file={stop_file}",
        f"--device_serial={p.get('device_serial', '')}",
        f"--target={body.target}",
        f"--watch_min={body.watch_min}",
        f"--watch_max={body.watch_max}",
        f"--jeda_tiktok_shopee={body.jeda_tiktok_shopee}",
        f"--delay_start_antar_hp={body.delay_start_antar_hp}",
        f"--folder_sound={body.folder_sound}",
        f"--folder_frame_border={body.folder_frame_border}",
        f"--mode={p.get('mode', 'generate_ai')}",
        f"--hashtag_tambahan={body.hashtag_tambahan}",
        f"--max_retry={body.max_retry}",
        f"--shopee_clone={body.shopee_clone}",
        f"--use_mix_sound={p.get('use_mix_sound', 'on')}",
    ]
    proc = subprocess.Popen(
        cmd, cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    _active_procs[project_id] = proc
    ProjectRepo.update_status(project_id, "berjalan")
    await manager.broadcast_status(project_id, "berjalan")

    # Start log poller
    task = asyncio.create_task(_poll_log(project_id, log_file, stop_file))
    _pollers[project_id] = task

    return {"message": "Project dimulai", "pid": proc.pid}


@app.post("/api/projects/{project_id}/stop")
async def stop_project(project_id: int):
    # 1. Tulis stop file (sinyal ke runner loop)
    stop_file = stop_file_path(project_id)
    try:
        open(stop_file, "w").close()
    except Exception:
        pass

    # 2. Terminate subprocess langsung — stop instan
    proc = _active_procs.get(project_id)
    if proc and proc.poll() is None:
        try:
            proc.terminate()          # SIGTERM — graceful
            await asyncio.sleep(2)
            if proc.poll() is None:   # Masih hidup? Force kill
                proc.kill()
        except Exception:
            pass
        _active_procs.pop(project_id, None)

    # 3. Cancel log poller
    task = _pollers.get(project_id)
    if task and not task.done():
        task.cancel()
        _pollers.pop(project_id, None)

    ProjectRepo.update_status(project_id, "berhenti")
    await manager.broadcast_status(project_id, "berhenti")
    return {"message": "Stop signal dikirim"}


class StartMassalBody(BaseModel):
    ids: list[int]
    target: int = 10
    watch_min: int = 600
    watch_max: int = 1800
    shopee_clone: bool = False
    jeda_tiktok_shopee: int = 30
    delay_start_antar_hp: int = 20
    folder_sound: str = "D:\\TikTok\\sounds"
    folder_frame_border: str = "D:\\TikTok\\SeedApp v2\\Frame GIF"
    hashtag_tambahan: str = ""
    max_retry: int = 10


@app.post("/api/projects/start-massal")
async def start_massal(body: StartMassalBody):
    import asyncio

    async def _run():
        for i, project_id in enumerate(body.ids):
            p = ProjectRepo.get_by_id(project_id)
            if not p:
                continue
            if project_id in _active_procs and _active_procs[project_id].poll() is None:
                continue

            stop_file = stop_file_path(project_id)
            log_file  = log_file_path(project_id)
            try:
                if os.path.exists(stop_file):
                    os.remove(stop_file)
            except Exception:
                pass

            worker_script = os.path.join(ROOT, "src", "core", "worker_process.py")
            cmd = [
                sys.executable, worker_script,
                f"--project_id={project_id}",
                f"--log_file={log_file}",
                f"--stop_file={stop_file}",
                f"--device_serial={p.get('device_serial', '')}",
                f"--target={body.target}",
                f"--watch_min={body.watch_min}",
                f"--watch_max={body.watch_max}",
                f"--jeda_tiktok_shopee={body.jeda_tiktok_shopee}",
                f"--delay_start_antar_hp={body.delay_start_antar_hp}",
                f"--folder_sound={body.folder_sound}",
                f"--folder_frame_border={body.folder_frame_border}",
                f"--mode={p.get('mode', 'generate_ai')}",
                f"--hashtag_tambahan={body.hashtag_tambahan}",
                f"--max_retry={body.max_retry}",
                f"--shopee_clone={body.shopee_clone}",
                f"--use_mix_sound={p.get('use_mix_sound', 'on')}",
            ]
            proc = subprocess.Popen(
                cmd, cwd=ROOT,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            _active_procs[project_id] = proc
            ProjectRepo.update_status(project_id, "berjalan")
            await manager.broadcast_status(project_id, "berjalan")
            task = asyncio.create_task(_poll_log(project_id, log_file, stop_file))
            _pollers[project_id] = task

            if i < len(body.ids) - 1:
                await asyncio.sleep(body.delay_start_antar_hp)

    asyncio.create_task(_run())
    return {"message": f"{len(body.ids)} project dijadwalkan"}


# ── Stealth Upload — sequential with IP reset ──────────────────

_stealth_task: Optional[asyncio.Task] = None
_stealth_stop_flag = False
_stealth_queue: dict = {
    "all_ids": [],          # semua project ID yang dipilih (urutan)
    "done_ids": [],         # project yang sudah selesai (per loop)
    "current_ids": [],      # project yang sedang upload (batch)
    "pending_ids": [],      # project yang belum mulai (per loop)
    "current_loop": 0,      # loop yang sedang berjalan (1..total_loops)
    "total_loops": 1,       # jumlah loop total
}


class StartMassalStealthBody(BaseModel):
    ids: list[int]
    target: int = 10                 # legacy: total per HP (pakai kalau videos_per_loop=0)
    videos_per_loop: int = 0         # videos per HP per loop (0 = pakai target sebagai legacy)
    loop_count: int = 1              # jumlah loop (default 1 = backward compat)
    watch_min: int = 600
    watch_max: int = 1800
    shopee_clone: bool = False
    jeda_tiktok_shopee: int = 30
    folder_sound: str = "D:\\TikTok\\sounds"
    folder_frame_border: str = "D:\\TikTok\\SeedApp v2\\Frame GIF"
    hashtag_tambahan: str = ""
    max_retry: int = 10


@app.post("/api/projects/start-massal-stealth")
async def start_massal_stealth(body: StartMassalStealthBody):
    global _stealth_task, _stealth_stop_flag

    if _stealth_task and not _stealth_task.done():
        raise HTTPException(400, "Stealth upload sedang berjalan")

    settings = load_settings()
    tethering_serial = settings.get("stealth_tethering_device", "")
    batch_size = int(settings.get("stealth_batch", 1))
    print(f"[stealth] Batch per Cycle = {batch_size}")

    if not tethering_serial:
        raise HTTPException(400, "HP Tethering belum dipilih di Settings")

    # Hitung loop & target per loop (backward compat)
    _videos_per_loop = body.videos_per_loop if body.videos_per_loop > 0 else body.target
    _loop_count = max(1, body.loop_count)
    print(f"[stealth] Loop = {_loop_count}, Videos per Loop = {_videos_per_loop}, Total per HP = {_loop_count * _videos_per_loop}")

    _stealth_stop_flag = False
    _stealth_queue["all_ids"] = list(body.ids)
    _stealth_queue["done_ids"] = []
    _stealth_queue["current_ids"] = []
    _stealth_queue["pending_ids"] = list(body.ids)
    _stealth_queue["current_loop"] = 0
    _stealth_queue["total_loops"] = _loop_count

    async def _stealth_run():
        global _stealth_stop_flag
        from src.macro.adb_helper import airplane_toggle, wifi_toggle, wifi_off_all, airplane_then_hotspot_reset, lock_rotation_portrait
        from src.macro.shopee_only import switch_shopee_account

        # Log helper: tulis ke log file project yg sedang aktif
        _current_log_file = [None]
        def slog(msg):
            print(f"[stealth] {msg}")
            lf = _current_log_file[0]
            if lf:
                ts = datetime.now().strftime("%H:%M:%S")
                try:
                    with open(lf, "a", encoding="utf-8") as f:
                        f.write(json.dumps({"ts": ts, "msg": msg}) + "\n")
                except Exception:
                    pass

        # Kumpulkan semua device serial dari project yang dipilih
        projects = []
        for pid in body.ids:
            p = ProjectRepo.get_by_id(pid)
            if p:
                projects.append(p)

        if not projects:
            return

        # Kumpulkan serial semua HP (selain tethering) untuk WiFi OFF
        all_serials = list(set(
            p["device_serial"] for p in projects
            if p.get("device_serial") and p["device_serial"] != tethering_serial
        ))

        # Urutkan: tethering dulu, lalu sisanya
        # Juga pastikan project dgn HP sama TIDAK masuk batch yang sama
        # (spread supaya multi-account di 1 HP dijalankan sequential)
        tethering_projects = [p for p in projects if p.get("device_serial") == tethering_serial]
        other_projects = [p for p in projects if p.get("device_serial") != tethering_serial]

        # Arrange batch-aware: greedy fill per batch, skip project di device yang udah
        # ada di batch yang sama. Ini mencegah 2 project HP yg sama tabrakan.
        def _arrange_no_collision(plist, bsize):
            remaining = list(plist)
            result = []
            while remaining:
                batch = []
                devices_used = set()
                i = 0
                while i < len(remaining) and len(batch) < bsize:
                    d = remaining[i].get("device_serial", "")
                    if d not in devices_used:
                        batch.append(remaining.pop(i))
                        devices_used.add(d)
                    else:
                        i += 1
                if not batch:
                    # Sisa cuma same-device — paksa ambil 1 (akan ada batch lebih kecil)
                    batch.append(remaining.pop(0))
                result.extend(batch)
            return result

        # Tethering dulu (priority), lalu others — tapi keduanya batch-aware
        ordered_raw = tethering_projects + other_projects
        ordered = _arrange_no_collision(ordered_raw, batch_size)

        from src.macro.adb_helper import hotspot_enable, hotspot_is_active

        # Lock rotation portrait di SEMUA HP yg ikut stealth (HP tethering + non-tethering)
        # Penting: tap coord di Quick Settings depend on portrait layout.
        # Kalau HP rotate ke landscape pas upload, swipe-tap bakal nyasar.
        all_serials_full = list(set([p.get("device_serial", "") for p in projects if p.get("device_serial")]))
        slog(f"🔒 Lock rotation portrait — {len(all_serials_full)} device")
        for _ds in all_serials_full:
            await asyncio.to_thread(lock_rotation_portrait, _ds, None)

        # Pastikan hotspot HP tethering aktif sebelum mulai
        slog(f"📡 Cek hotspot HP tethering — {tethering_serial}")
        if not await asyncio.to_thread(hotspot_is_active, tethering_serial):
            slog(f"📡 Hotspot belum aktif, mengaktifkan...")
            await asyncio.to_thread(hotspot_enable, tethering_serial, slog)
            await asyncio.sleep(3)
        else:
            slog(f"📡 Hotspot sudah aktif")

        # WiFi OFF semua HP non-tethering
        slog(f"📶 WiFi OFF semua HP ({len(all_serials)} device)")
        await asyncio.to_thread(wifi_off_all, all_serials, slog)
        await asyncio.sleep(2)

        # ── OUTER LOOP: Round-robin per Loop ──
        # Tiap loop iteration: semua HP upload `videos_per_loop` video, terus next loop
        for _loop_idx in range(_loop_count):
            if _stealth_stop_flag:
                break

            _stealth_queue["current_loop"] = _loop_idx + 1
            slog(f"🔁 LOOP {_loop_idx + 1}/{_loop_count} dimulai")

            # Reset queue tracking untuk loop baru (kecuali loop pertama)
            if _loop_idx > 0:
                _stealth_queue["done_ids"] = []
                _stealth_queue["current_ids"] = []
                _stealth_queue["pending_ids"] = list(body.ids)
                # Reset project status ke 'berjalan' biar UI gak kelihatan selesai prematur
                for pid in body.ids:
                    try:
                        ProjectRepo.update_status(pid, "berjalan")
                        await manager.broadcast_status(pid, "berjalan")
                    except Exception:
                        pass

            # Proses per batch — semua project dalam batch jalan PARALLEL
            i = 0
            while i < len(ordered):
                if _stealth_stop_flag:
                    break

                batch = ordered[i:i + batch_size]

                # Cek apakah batch ini HANYA berisi HP tethering
                batch_has_non_tethering = any(
                    p.get("device_serial") != tethering_serial for p in batch
                )

                if batch_has_non_tethering:
                    # Combined flow: buka panel SEKALI → airplane ON → 5s → airplane OFF → 5s → hotspot ON → 5s → close
                    await asyncio.to_thread(airplane_then_hotspot_reset, tethering_serial, slog)

                    if _stealth_stop_flag:
                        break

                if _stealth_stop_flag:
                    break

                slog(f"📦 Loop {_loop_idx + 1}/{_loop_count} · Batch {i // batch_size + 1} — {len(batch)} project")

                # 1. WiFi ON semua HP dalam batch
                for proj in batch:
                    ds = proj.get("device_serial", "")
                    if ds and ds != tethering_serial:
                        await asyncio.to_thread(wifi_toggle, ds, True, slog)
                if batch_has_non_tethering:
                    await asyncio.sleep(5)  # tunggu koneksi ke hotspot stabil

                # 2. Switch akun Shopee jika project punya shopee_username
                #    Hanya switch 1x per device (batch tidak boleh punya >1 username per HP)
                switched_devices = set()
                for proj in batch:
                    if _stealth_stop_flag:
                        break
                    username = (proj.get("shopee_username") or "").strip()
                    device_serial = proj.get("device_serial", "")
                    if username and device_serial and device_serial not in switched_devices:
                        switched_devices.add(device_serial)
                        shopee_clone = str(body.shopee_clone).lower() == 'true'
                        try:
                            import uiautomator2 as u2
                            d = await asyncio.to_thread(u2.connect, device_serial)
                            ok = await asyncio.to_thread(
                                switch_shopee_account, d, username, slog, shopee_clone
                            )
                            if not ok:
                                slog(f"⚠ Switch akun {username} gagal di {device_serial}, lanjut upload...")
                            try:
                                await asyncio.to_thread(d.stop_uiautomator)
                            except Exception:
                                pass
                        except Exception as e:
                            slog(f"⚠ Switch akun error: {e}")

                # 3. Start semua worker subprocess secara parallel
                batch_procs = {}  # {project_id: proc}
                for proj in batch:
                    if _stealth_stop_flag:
                        break

                    project_id = proj["id"]
                    device_serial = proj.get("device_serial", "")

                    # Update queue tracking
                    if project_id in _stealth_queue["pending_ids"]:
                        _stealth_queue["pending_ids"].remove(project_id)
                    if project_id not in _stealth_queue["current_ids"]:
                        _stealth_queue["current_ids"].append(project_id)

                    stop_file = stop_file_path(project_id)
                    log_file = log_file_path(project_id)
                    try:
                        if os.path.exists(stop_file):
                            os.remove(stop_file)
                    except Exception:
                        pass

                    worker_script = os.path.join(ROOT, "src", "core", "worker_process.py")
                    cmd = [
                        sys.executable, worker_script,
                        f"--project_id={project_id}",
                        f"--log_file={log_file}",
                        f"--stop_file={stop_file}",
                        f"--device_serial={device_serial}",
                        f"--target={_videos_per_loop}",
                        f"--watch_min={body.watch_min}",
                        f"--watch_max={body.watch_max}",
                        f"--jeda_tiktok_shopee={body.jeda_tiktok_shopee}",
                        f"--delay_start_antar_hp=0",
                        f"--folder_sound={body.folder_sound}",
                        f"--folder_frame_border={body.folder_frame_border}",
                        f"--mode={proj.get('mode', 'generate_ai')}",
                        f"--hashtag_tambahan={body.hashtag_tambahan}",
                        f"--max_retry={body.max_retry}",
                        f"--shopee_clone={body.shopee_clone}",
                        f"--use_mix_sound={proj.get('use_mix_sound', 'on')}",
                        f"--fast_mode=true",
                    ]
                    proc = subprocess.Popen(
                        cmd, cwd=ROOT,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    batch_procs[project_id] = proc
                    _active_procs[project_id] = proc
                    ProjectRepo.update_status(project_id, "berjalan")
                    await manager.broadcast_status(project_id, "berjalan")
                    task = asyncio.create_task(_poll_log(project_id, log_file, stop_file))
                    _pollers[project_id] = task

                # 3. Tunggu SEMUA worker dalam batch selesai
                while batch_procs:
                    if _stealth_stop_flag:
                        # Stop semua proses dalam batch
                        for pid, proc in batch_procs.items():
                            try:
                                proc.terminate()
                            except Exception:
                                pass
                        await asyncio.sleep(2)
                        for pid, proc in batch_procs.items():
                            try:
                                if proc.poll() is None:
                                    proc.kill()
                            except Exception:
                                pass
                            poller = _pollers.pop(pid, None)
                            if poller and not poller.done():
                                poller.cancel()
                            ProjectRepo.update_status(pid, "berhenti")
                            await manager.broadcast_status(pid, "berhenti")
                            _active_procs.pop(pid, None)
                        batch_procs.clear()
                        break

                    # Cek mana yang sudah selesai
                    done_pids = [pid for pid, proc in batch_procs.items() if proc.poll() is not None]
                    for pid in done_pids:
                        batch_procs.pop(pid)
                        _active_procs.pop(pid, None)
                        _stealth_queue["done_ids"].append(pid)
                        if pid in _stealth_queue["current_ids"]:
                            _stealth_queue["current_ids"].remove(pid)

                    # current_ids otomatis terupdate di atas

                    await asyncio.sleep(2)

                # 4. WiFi OFF semua HP dalam batch
                for proj in batch:
                    ds = proj.get("device_serial", "")
                    if ds and ds != tethering_serial:
                        await asyncio.to_thread(wifi_toggle, ds, False, slog)
                await asyncio.sleep(1)

                _stealth_queue["current_ids"] = []
                i += batch_size

            # End of inner while (1 loop iteration done)
            slog(f"✅ LOOP {_loop_idx + 1}/{_loop_count} selesai")

        # Reset queue saat selesai
        _stealth_queue["current_ids"] = []
        _stealth_queue["pending_ids"] = []
        _stealth_stop_flag = False

    _stealth_task = asyncio.create_task(_stealth_run())
    return {"message": f"Stealth upload dimulai — {len(body.ids)} project"}


@app.post("/api/projects/stop-stealth")
async def stop_stealth():
    global _stealth_stop_flag
    _stealth_stop_flag = True
    return {"message": "Stealth stop signal dikirim"}


@app.get("/api/stealth/status")
async def stealth_status():
    running = _stealth_task is not None and not _stealth_task.done()
    return {
        "running": running,
        "queue": _stealth_queue,
    }


@app.get("/api/videos/{video_id}")
def get_video(video_id: int):
    from src.core.database import get_connection
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM video_items WHERE id = ?", [video_id]).fetchone()
        if not row:
            raise HTTPException(404, "Video tidak ditemukan")
        return dict(row)
    finally:
        conn.close()

@app.delete("/api/videos/{video_id}")
def delete_video_item(video_id: int):
    from src.core.database import get_connection
    conn = get_connection()
    try:
        conn.execute("DELETE FROM video_items WHERE id=?", (video_id,))
        conn.execute("DELETE FROM project_videos WHERE video_id=?", (video_id,))
        conn.commit()
    finally:
        conn.close()
    return {"message": "Video dihapus"}

@app.patch("/api/videos/{video_id}")
async def update_video(video_id: int, request: Request):
    data = await request.json()
    allowed = [
        'product_shopee','caption_shopee','caption_tiktok','link_tiktok','keranjang_tiktok','video_result',
        'status_shopee','status_tiktok',
        'rs_judul','rs_url','rs_deskripsi','rs_gambar','rs_sumber',
        'rs_file_lokal','rs_produk','rs_keranjang_kuning','rs_link_affiliate'
    ]
    update = {k: v for k, v in data.items() if k in allowed}
    if not update:
        raise HTTPException(400, "Tidak ada field valid")
    project_id = data.get('project_id')
    VideoRepo.update_fields(video_id, update, project_id=project_id)
    return {"message": "Tersimpan"}

# ── CONVERT ──────────────────────────────────────────
_convert_procs: dict[int, "subprocess.Popen"] = {}

class ConvertBody(BaseModel):
    folder_frame:  str = ""
    folder_sound:  str = ""
    use_frame:     str = "on"
    use_song:      str = "on"
    output_dir:    str = ""

@app.post("/api/projects/{project_id}/convert")
async def start_convert(project_id: int, body: ConvertBody):
    if project_id in _active_procs:
        return {"ok": False, "msg": "Project sedang run, tidak bisa convert"}
    if project_id in _convert_procs:
        proc = _convert_procs[project_id]
        if proc.poll() is None:
            return {"ok": False, "msg": "Convert sedang berjalan"}

    p = ProjectRepo.get_by_id(project_id)
    if not p:
        return {"ok": False, "msg": "Project tidak ditemukan"}

    settings = load_settings()
    output_dir = body.output_dir or os.path.join(settings.get("folder_data", "data"), "converted")
    converter_script = os.path.join(ROOT, "src", "core", "converter.py")

    cmd = [
        sys.executable, converter_script,
        "--project_id",   str(project_id),
        "--folder_frame", body.folder_frame or settings.get("folder_frame_border", ""),
        "--folder_sound", body.folder_sound or settings.get("folder_sound", ""),
        "--use_frame",    p.get("rs_use_frame", "on"),
        "--use_song",     p.get("rs_use_song",  "on"),
        "--output_dir",   output_dir,
    ]

    proc = subprocess.Popen(cmd, cwd=ROOT,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,  # merge stderr → stdout agar error terlihat di log
                            text=False)  # binary mode — decode manual utf-8 agar tidak cp1252
    _convert_procs[project_id] = proc

    # Stream log convert via log file + _poll_log (sama seperti worker)
    conv_log_file  = os.path.join(ROOT, "logs", f"convert_{project_id}.log")
    conv_stop_file = os.path.join(ROOT, "logs", f"convert_{project_id}.stop")
    os.makedirs(os.path.join(ROOT, "logs"), exist_ok=True)
    # Hapus log lama
    for f in [conv_log_file, conv_stop_file]:
        try: os.remove(f)
        except Exception: pass

    import threading
    _pipe_done = threading.Event()

    def _pipe_to_file():
        try:
            with open(conv_log_file, "w", encoding="utf-8") as lf:
                for raw in proc.stdout:
                    line = raw.decode("utf-8", errors="replace")
                    lf.write(line)
                    lf.flush()
        except Exception as e:
            # Tulis error ke log file agar terlihat di activity log
            try:
                with open(conv_log_file, "a", encoding="utf-8") as lf:
                    ts = datetime.now().strftime("%H:%M:%S")
                    lf.write(json.dumps({"ts": ts, "msg": f"❌ Convert error: {e}"}) + "\n")
                    lf.flush()
            except Exception:
                pass
        finally:
            _pipe_done.set()

    threading.Thread(target=_pipe_to_file, daemon=True).start()

    async def _poll_convert():
        last_pos  = 0
        done_seen = False
        while True:
            await asyncio.sleep(0.4)
            try:
                if os.path.exists(conv_log_file):
                    with open(conv_log_file, "r", encoding="utf-8") as lf:
                        lf.seek(last_pos)
                        lines = lf.readlines()
                        last_pos = lf.tell()
                    for line in lines:
                        line = line.strip()
                        if not line: continue
                        try:
                            entry = json.loads(line)
                        except Exception:
                            entry = {"ts": datetime.now().strftime("%H:%M:%S"), "msg": line}
                        await manager.broadcast_log(project_id, entry)
                        if "__CONVERT_DONE__" in entry.get("msg", ""):
                            done_seen = True
            except Exception:
                pass
            # Exit setelah pipe selesai DAN semua baris sudah terbaca
            if _pipe_done.is_set():
                # Satu kali flush terakhir
                try:
                    if os.path.exists(conv_log_file):
                        with open(conv_log_file, "r", encoding="utf-8") as lf:
                            lf.seek(last_pos)
                            lines = lf.readlines()
                        for line in lines:
                            line = line.strip()
                            if not line: continue
                            try:
                                entry = json.loads(line)
                            except Exception:
                                entry = {"ts": datetime.now().strftime("%H:%M:%S"), "msg": line}
                            await manager.broadcast_log(project_id, entry)
                except Exception:
                    pass
                _convert_procs.pop(project_id, None)
                return

    asyncio.ensure_future(_poll_convert())
    return {"ok": True, "msg": "Convert dimulai"}


@app.post("/api/projects/{project_id}/stop-convert")
async def stop_convert(project_id: int):
    proc = _convert_procs.pop(project_id, None)
    if proc and proc.poll() is None:
        proc.terminate()
        return {"ok": True, "msg": "Convert dihentikan"}
    return {"ok": False, "msg": "Convert tidak sedang berjalan"}


@app.get("/api/projects/{project_id}/convert-summary")
def get_convert_summary(project_id: int):
    p = ProjectRepo.get_by_id(project_id)
    if not p:
        return {"total": 0, "converted": 0, "belum": 0}
    return VideoRepo.get_convert_summary(project_id)


@app.post("/api/projects/{project_id}/retry")
async def retry_failed(project_id: int):
    VideoRepo.reset_failed_to_antrian(project_id)
    return {"message": "Video gagal direset ke antrian"}


class RetryVideoBody(BaseModel):
    video_id: int
    platform: str  # "shopee" atau "tiktok"

class BulkDeleteBody(BaseModel):
    ids: List[int]  # list of project_videos.id

@app.post("/api/projects/{project_id}/delete-videos")
async def bulk_delete_project_videos(project_id: int, body: BulkDeleteBody):
    """Hapus beberapa video dari project_videos saja (dataset tidak terpengaruh)."""
    VideoRepo.delete_bulk_by_ids(body.ids)
    return {"deleted": len(body.ids)}

@app.post("/api/projects/{project_id}/retry-video")
async def retry_single_video(project_id: int, body: RetryVideoBody):
    """Retry upload 1 video untuk platform tertentu (shopee/tiktok)."""
    p = ProjectRepo.get_by_id(project_id)
    if not p:
        raise HTTPException(404, "Project tidak ditemukan")
    if project_id in _active_procs and _active_procs[project_id].poll() is None:
        raise HTTPException(400, "Project sedang berjalan")
    if body.platform not in ("shopee", "tiktok"):
        raise HTTPException(400, "Platform tidak valid")

    # Set platform yg di-retry ke proses, platform lain tidak disentuh
    if body.platform == "shopee":
        VideoRepo.update_status_by_project(project_id, body.video_id, "proses",
                                            status_shopee="proses")
    else:
        VideoRepo.update_status_by_project(project_id, body.video_id, "proses",
                                            status_tiktok="proses")

    # Bersihkan stop file
    stop_file = stop_file_path(project_id)
    log_file  = log_file_path(project_id)
    try:
        if os.path.exists(stop_file):
            os.remove(stop_file)
    except Exception:
        pass

    cfg = load_settings()
    cmd = [
        sys.executable, os.path.join(ROOT, "src", "core", "worker_process.py"),
        f"--project_id={project_id}",
        f"--log_file={log_file}",
        f"--stop_file={stop_file}",
        f"--device_serial={p.get('device_serial', '')}",
        f"--target=0",
        f"--watch_min={cfg.get('watch_min', 600)}",
        f"--watch_max={cfg.get('watch_max', 1800)}",
        f"--jeda_tiktok_shopee={cfg.get('jeda_tiktok_shopee', 30)}",
        "--folder_sound=" + str(cfg.get('folder_sound', 'D:\\TikTok\\sounds')),
        "--folder_frame_border=" + str(cfg.get('folder_frame_border', '')),
        "--mode=" + str(p.get('mode', 'generate_ai')),
        f"--retry_video_id={body.video_id}",
        f"--retry_platform={body.platform}",
        f"--max_retry={cfg.get('max_retry', 10)}",
        f"--use_mix_sound={p.get('use_mix_sound', 'on')}",
    ]
    proc = subprocess.Popen(cmd, cwd=ROOT,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    _active_procs[project_id] = proc
    ProjectRepo.update_status(project_id, "berjalan")
    await manager.broadcast_status(project_id, "berjalan")

    task = asyncio.create_task(_poll_log(project_id, log_file, stop_file))
    _pollers[project_id] = task
    return {"message": "Retry dimulai", "pid": proc.pid}



# ── STATS ─────────────────────────────────────────────
@app.get("/api/stats/daily")
def get_daily_stats(days: int = 30):
    from src.core.database import UploadStatsRepo
    return {"rows": UploadStatsRepo.get_daily(days)}


@app.get("/api/projects/{project_id}/error-summary")
def get_error_summary(project_id: int):
    """Ringkasan error per kategori untuk project ini."""
    from src.core.error_categories import categorize_error, _CATEGORY_HINT
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT error_shopee, error_tiktok FROM project_videos
            WHERE project_id=? AND (error_shopee != '' OR error_tiktok != '')
        """, (project_id,)).fetchall()
    finally:
        conn.close()
    summary = {}
    total_error_count = 0
    for row in rows:
        for err_msg in [row["error_shopee"], row["error_tiktok"]]:
            if not err_msg:
                continue
            total_error_count += 1
            cat, emoji = categorize_error(err_msg)
            if cat not in summary:
                summary[cat] = {"count": 0, "emoji": emoji, "hint": _CATEGORY_HINT.get(cat, ""), "samples": []}
            summary[cat]["count"] += 1
            if len(summary[cat]["samples"]) < 3:
                summary[cat]["samples"].append(err_msg[:150])
    return {"project_id": project_id, "categories": summary, "total_errors": total_error_count}

# ── ADB ───────────────────────────────────────────────
_last_known_devices: set | None = None  # None = belum pernah dipanggil (skip events pertama)
_adb_cache: dict = {"result": None, "ts": 0}
_ADB_CACHE_TTL = 10  # detik — hindari spam adb devices

@app.get("/api/adb/devices")
def get_adb_devices():
    global _last_known_devices
    try:
        import time as _time
        now = _time.time()
        # Gunakan cache jika masih fresh
        if _adb_cache["result"] is not None and (now - _adb_cache["ts"]) < _ADB_CACHE_TTL:
            return _adb_cache["result"]

        raw = adb_helper.get_devices()
        devices = []
        current_serials = set()
        aliases = load_settings().get("device_aliases", {})
        for d in raw:
            serial = d.get("serial", "")
            label  = d.get("label", serial)
            model  = label.split("(")[0].strip() if "(" in label else label
            alias  = aliases.get(serial, model)
            devices.append({"serial": serial, "label": label, "model": model, "alias": alias, "status": "device"})
            current_serials.add(serial)

        # Detect perubahan device (connect/disconnect)
        # Skip events pada panggilan pertama agar tidak spam toast saat page load
        events = []
        if _last_known_devices is not None:
            newly_connected = current_serials - _last_known_devices
            newly_disconnected = _last_known_devices - current_serials
            for s in newly_connected:
                alias = aliases.get(s, s)
                events.append({"type": "connected", "serial": s, "alias": alias})
            for s in newly_disconnected:
                alias = aliases.get(s, s)
                events.append({"type": "disconnected", "serial": s, "alias": alias})
        _last_known_devices = current_serials

        result = {"devices": devices, "events": events}
        _adb_cache["result"] = result
        _adb_cache["ts"] = now
        return result
    except Exception as e:
        return {"devices": [], "events": [], "error": str(e)}


# ══════════════════════════════════════════════════════
#  SETTINGS API
# ══════════════════════════════════════════════════════
SETTINGS_FILE = os.path.join(INTERNAL_ROOT, "data", "settings.json")
GOOGLE_CREDS_FILE = os.path.join(INTERNAL_ROOT, "data", "google_creds.json")

# ── Settings Model (Pydantic Validation) ─────────────
class SettingsModel(BaseModel):
    watch_min: int = 600
    watch_max: int = 1800
    jeda_tiktok_shopee: int = 30
    delay_start_antar_hp: int = 20
    folder_sound: str = "D:\\TikTok\\sounds"
    folder_frame_border: str = "D:\\TikTok\\SeedApp v2\\Frame GIF"
    timeout_ui: int = 30
    retry_delay: int = 5
    folder_video: str = ""
    folder_data: str = "D:\\TikTok\\SeedApp v2\\data"
    folder_temp: str = "D:\\TikTok\\SeedApp v2\\temp"
    folder_log: str = ""
    auto_hapus_cache: bool = True
    log_per_sesi: bool = True
    adb_path: str = "adb"
    auto_reconnect: bool = True
    skip_offline: bool = True
    target_per_hp: int = 10
    max_retry: int = 10
    upscale_video: bool = True
    biarkan_terbuka_jika_error: bool = True
    blacklist_keywords: list = []
    hashtag_tambahan: str = ""
    shopee_clone: bool = False
    mix_sound: bool = True
    stealth_mode: bool = False
    stealth_tethering_device: str = ""
    stealth_batch: int = 1
    tiktok_search_keywords: str = "remix terbaru"
    global_spreadsheet_url: str = ""
    sync_key: str = ""
    device_aliases: dict = {}
    remote_api_key: str = ""
    sched_global_enabled: bool = False
    sched_time: str = "08:00"

    model_config = ConfigDict(extra="allow")  # izinkan field tambahan agar backward compatible

DEFAULT_SETTINGS = SettingsModel().model_dump()


def load_settings() -> dict:
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
        except Exception:
            # File corrupt / tidak bisa di-parse → pakai default
            print(f"  ⚠️  settings.json corrupt, pakai default settings")
            return DEFAULT_SETTINGS.copy()
        # Merge dengan default dulu agar field baru tidak hilang, lalu validasi
        merged = {**DEFAULT_SETTINGS, **saved}
        try:
            validated = SettingsModel(**merged)
            return validated.model_dump()
        except Exception:
            # Validasi gagal → tetap pakai merged tanpa validasi (backward compat)
            return merged
    return DEFAULT_SETTINGS.copy()


def save_settings(data: dict):
    os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
    # Merge dengan default agar field yang tidak dikirim tetap ada
    merged = {**DEFAULT_SETTINGS, **data}
    try:
        validated = SettingsModel(**merged)
        merged = validated.model_dump()
    except Exception:
        pass  # fallback simpan as-is jika validasi gagal (backward compat)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)


# ══════════════════════════════════════════════════════
#  GOOGLE OAUTH2 HELPERS
# ══════════════════════════════════════════════════════

def load_google_creds() -> dict:
    try:
        with open(GOOGLE_CREDS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_google_creds(data: dict):
    os.makedirs(os.path.dirname(GOOGLE_CREDS_FILE), exist_ok=True)
    with open(GOOGLE_CREDS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_google_access_token() -> str:
    """Return valid access token, auto-refresh if expired."""
    import time
    creds = load_google_creds()
    if not creds.get("refresh_token"):
        raise ValueError("Google Sheets belum terhubung")

    # Token masih valid (dengan buffer 60 detik)
    if time.time() < creds.get("token_expiry", 0) - 60 and creds.get("access_token"):
        return creds["access_token"]

    # Refresh
    import requests as _req
    resp = _req.post("https://oauth2.googleapis.com/token", data={
        "client_id":     creds["client_id"],
        "client_secret": creds["client_secret"],
        "refresh_token": creds["refresh_token"],
        "grant_type":    "refresh_token",
    }, timeout=15)
    resp.raise_for_status()
    token_data = resp.json()

    creds["access_token"]  = token_data["access_token"]
    creds["token_expiry"]  = time.time() + token_data.get("expires_in", 3600)
    save_google_creds(creds)
    return creds["access_token"]


def _fetch_sheet_rows(spreadsheet_id: str, sheet_name: str = None,
                      gid: str = None, spreadsheet_url: str = None) -> list:
    """Fetch baris spreadsheet. Prioritas: OAuth API → public CSV fallback."""
    import requests as _req, urllib.parse
    # Coba OAuth API dulu
    try:
        access_token = get_google_access_token()
        # Build A1 notation — wrap sheet name in single quotes to handle spaces/special chars
        if sheet_name:
            escaped = sheet_name.replace("'", "\\'")
            range_a1 = f"'{escaped}'!A:Z"
        else:
            range_a1 = "A:Z"
        url = (f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}"
               f"/values/{urllib.parse.quote(range_a1)}")
        resp = _req.get(url, headers={"Authorization": f"Bearer {access_token}"}, timeout=20)
        resp.raise_for_status()
        values = resp.json().get("values", [])
        # Normalisasi: tiap row sama panjang (pad dengan "")
        max_len = max((len(r) for r in values), default=0)
        return [r + [""] * (max_len - len(r)) for r in values]
    except Exception:
        pass  # fallback ke CSV public

    # Fallback: CSV public
    if not spreadsheet_url:
        raise ValueError("spreadsheet_url diperlukan untuk fallback CSV")
    export_url = _to_export_url(spreadsheet_url, gid_override=gid, sheet_name=sheet_name)
    resp = _req.get(export_url, headers={"User-Agent": "Mozilla/5.0"},
                    timeout=30, allow_redirects=True)
    resp.raise_for_status()
    import csv, io
    raw = resp.content.decode("utf-8-sig", errors="replace")
    return list(csv.reader(io.StringIO(raw)))


def _update_sheet_column_h(spreadsheet_id: str, sheet_name: str,
                            row_numbers: list, value: str = "Shopee Sync") -> dict:
    """Batch-update column H of given 1-based row numbers to `value`.
    Returns {"success": bool, "updated": int, "error": str|None}
    """
    if not row_numbers:
        return {"success": True, "updated": 0, "error": None}
    try:
        access_token = get_google_access_token()
    except ValueError as e:
        return {"success": False, "updated": 0, "error": str(e)}

    import requests as _req
    # Build range list — use single-cell ranges for non-contiguous rows
    sheet_prefix = f"'{sheet_name}'!" if sheet_name else ""
    data = [
        {"range": f"{sheet_prefix}H{row}", "values": [[value]]}
        for row in row_numbers
    ]

    try:
        resp = _req.post(
            f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values:batchUpdate",
            headers={"Authorization": f"Bearer {access_token}",
                     "Content-Type": "application/json"},
            json={"valueInputOption": "RAW", "data": data},
            timeout=30,
        )
        if resp.ok:
            return {"success": True, "updated": len(row_numbers), "error": None}
        else:
            err = resp.json().get("error", {}).get("message", resp.text[:200])
            return {"success": False, "updated": 0, "error": err}
    except Exception as e:
        return {"success": False, "updated": 0, "error": str(e)}


# ── Google OAuth Endpoints ────────────────────────────

class GoogleCredsBody(BaseModel):
    client_id: str
    client_secret: str


@app.get("/api/google/status")
def google_status():
    creds = load_google_creds()
    return {
        "connected":   bool(creds.get("refresh_token")),
        "client_id":   creds.get("client_id", ""),
        "email":       creds.get("email", ""),
    }


@app.post("/api/google/credentials")
def save_google_credentials_endpoint(body: GoogleCredsBody):
    creds = load_google_creds()
    creds["client_id"]     = body.client_id.strip()
    creds["client_secret"] = body.client_secret.strip()
    # Clear existing tokens when credentials change
    creds.pop("refresh_token", None)
    creds.pop("access_token",  None)
    creds.pop("token_expiry",  None)
    creds.pop("email",         None)
    save_google_creds(creds)
    return {"message": "Credentials disimpan"}


@app.get("/api/google/auth-url")
def google_auth_url(request: Request):
    import urllib.parse
    creds = load_google_creds()
    if not creds.get("client_id") or not creds.get("client_secret"):
        raise HTTPException(400, "Client ID dan Client Secret belum diisi")
    # Use the request's base URL so it works on any port
    base = str(request.base_url).rstrip("/")
    redirect_uri = f"{base}/api/google/callback"
    params = {
        "client_id":     creds["client_id"],
        "redirect_uri":  redirect_uri,
        "response_type": "code",
        "scope":         "https://www.googleapis.com/auth/spreadsheets",
        "access_type":   "offline",
        "prompt":        "consent",
    }
    url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(params)
    return {"url": url, "redirect_uri": redirect_uri}


@app.get("/api/google/callback")
async def google_callback(request: Request, code: str = None, error: str = None):
    from fastapi.responses import HTMLResponse
    if error or not code:
        return HTMLResponse(f"""
        <html><body style="font-family:sans-serif;text-align:center;padding:40px">
        <h2>❌ Otorisasi dibatalkan</h2><p>{error or 'Tidak ada code'}</p>
        <p>Tutup tab ini dan coba lagi.</p></body></html>""")

    import requests as _req, time
    creds = load_google_creds()
    base = str(request.base_url).rstrip("/")
    redirect_uri = f"{base}/api/google/callback"

    resp = _req.post("https://oauth2.googleapis.com/token", data={
        "client_id":     creds.get("client_id", ""),
        "client_secret": creds.get("client_secret", ""),
        "code":          code,
        "redirect_uri":  redirect_uri,
        "grant_type":    "authorization_code",
    }, timeout=15)

    if not resp.ok:
        return HTMLResponse(f"""
        <html><body style="font-family:sans-serif;text-align:center;padding:40px">
        <h2>❌ Token exchange gagal</h2><pre>{resp.text[:300]}</pre>
        <p>Tutup tab ini dan coba lagi.</p></body></html>""")

    token_data = resp.json()
    creds["access_token"]  = token_data["access_token"]
    creds["refresh_token"] = token_data.get("refresh_token", creds.get("refresh_token", ""))
    creds["token_expiry"]  = time.time() + token_data.get("expires_in", 3600)

    # Fetch email
    try:
        me = _req.get("https://www.googleapis.com/oauth2/v2/userinfo",
                      headers={"Authorization": f"Bearer {creds['access_token']}"}, timeout=10)
        creds["email"] = me.json().get("email", "")
    except Exception:
        creds["email"] = ""

    save_google_creds(creds)
    return HTMLResponse("""
    <html><body style="font-family:sans-serif;text-align:center;padding:40px;background:#f9f9f9">
    <div style="max-width:400px;margin:auto;background:#fff;padding:32px;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.1)">
    <div style="font-size:48px;margin-bottom:16px">✅</div>
    <h2 style="margin:0 0 8px">Google Sheets Terhubung!</h2>
    <p style="color:#666">Kembali ke SeedApp dan refresh halaman Settings.</p>
    <script>setTimeout(()=>window.close(),2000);</script>
    </div></body></html>""")


@app.post("/api/google/disconnect")
def google_disconnect():
    creds = load_google_creds()
    for k in ("refresh_token", "access_token", "token_expiry", "email"):
        creds.pop(k, None)
    save_google_creds(creds)
    return {"message": "Google Sheets terputus"}


@app.get("/api/settings")
def get_settings():
    return load_settings()


@app.post("/api/settings")
def post_settings(body: dict):
    current = load_settings()
    current.update(body)
    save_settings(current)
    return {"message": "Pengaturan disimpan"}


# ══════════════════════════════════════════════════════
#  TOOLS
# ══════════════════════════════════════════════════════
class ToolsRunBody(BaseModel):
    tujuan: str                      # shopee_original | shopee_clone
    aksi: str                        # cek_saldo | cek_pelanggaran
    device: Union[str, List[str]]    # "all" | serial | [serial, ...]

@app.post("/api/tools/run")
async def run_tools(body: ToolsRunBody):
    from src.macro.tools_shopee_pay import scrape_shopee_pay
    from src.macro.tools_pelanggaran import scrape_pelanggaran
    import subprocess
    from concurrent.futures import ThreadPoolExecutor
    import asyncio

    clone = body.tujuan == "shopee_clone"

    # Tentukan list device
    if body.device == "all":
        try:
            out = subprocess.check_output(["adb", "devices"], text=True)
            serials = [
                line.split()[0]
                for line in out.splitlines()[1:]
                if line.strip() and "\tdevice" in line
            ]
        except Exception:
            serials = []
    elif isinstance(body.device, list):
        serials = body.device
    else:
        serials = [body.device]

    if not serials:
        return {"results": [], "error": "Tidak ada device terhubung"}

    def run_one(serial):
        if body.aksi == "cek_saldo":
            row = scrape_shopee_pay(serial=serial, clone=clone)
        elif body.aksi == "cek_pelanggaran":
            row = scrape_pelanggaran(serial=serial, clone=clone)
        elif body.aksi == "penarikan_saldo":
            from src.macro.tools_penarikan import penarikan_shopeepay
            _sync_key = load_settings().get("sync_key", "")
            row = penarikan_shopeepay(serial=serial, clone=clone, sync_key=_sync_key)
        elif body.aksi == "create_gmail":
            from src.macro.tools_gmail import create_gmail
            row = create_gmail(serial=serial)
        else:
            row = {"error": "Aksi tidak dikenal"}
        row["device"] = serial
        return row

    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor(max_workers=len(serials)) as executor:
        futures = [loop.run_in_executor(executor, run_one, s) for s in serials]
        results = await asyncio.gather(*futures)

    return {"results": [r for r in results if r is not None]}



# ══════════════════════════════════════════════════════
#  SCHEDULER — APScheduler, jalankan project tiap hari jam X
# ══════════════════════════════════════════════════════
try:
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from apscheduler.triggers.cron import CronTrigger
    _APSCHEDULER_OK = True
except ImportError:
    _APSCHEDULER_OK = False

_scheduler: "AsyncIOScheduler | None" = None
_SCHED_JOB_ID = "seedapp_daily_start"


async def _sync_all_spreadsheets() -> dict:
    """Sync semua dataset yang punya spreadsheet_url terdaftar.
    Fetch HTTP dilakukan PARALLEL, DB insert sequential.
    Return: {"datasets_synced": int, "new_videos": int, "duplicates_removed": int, "details": [...]}
    """
    import re as _re3
    from src.core.database import get_connection
    settings = load_settings()
    global_url = settings.get("global_spreadsheet_url", "")
    duplicates_removed = 0  # di-fill setelah sync selesai

    # Opsi A: Global URL always wins. Per-dataset URL cuma fallback legacy.
    all_datasets = DatasetRepo.get_all()
    datasets = []
    for ds in all_datasets:
        url = global_url or ds.get("spreadsheet_url", "")
        if url:
            ds["_resolved_url"] = url
            datasets.append(ds)

    # ── Phase 1: Fetch sheet secara parallel (max 3 concurrent) ──
    MAX_CONCURRENT = 3
    sem = asyncio.Semaphore(MAX_CONCURRENT)
    valid_datasets = []
    skip_details = []

    async def _limited_fetch(sheet_id, sheet_name, ss_url):
        MAX_RETRY = 2
        for attempt in range(MAX_RETRY + 1):
            try:
                async with sem:
                    return await asyncio.to_thread(
                        _fetch_sheet_rows, sheet_id, sheet_name=sheet_name, spreadsheet_url=ss_url
                    )
            except Exception as e:
                if attempt < MAX_RETRY:
                    await asyncio.sleep(2)
                    continue
                raise e

    fetch_tasks = []
    for ds in datasets:
        ss_url = ds.get("_resolved_url", "")
        ds_name = ds.get("name", f"Dataset {ds['id']}")
        if not ss_url:
            continue
        m3 = _re3.search(r'/spreadsheets/d/([^/#?]+)', ss_url)
        if not m3:
            skip_details.append({"dataset": ds_name, "new": 0, "error": "URL tidak valid"})
            continue
        sheet_id = m3.group(1)
        # Opsi A: kalau pakai global URL, tab name = nama dataset. Kalau per-dataset URL, pakai sheet_name tersimpan.
        if global_url:
            sheet_name = ds.get("name", "") or None
        else:
            sheet_name = ds.get("sheet_name", "") or ds.get("name", "") or None
        valid_datasets.append(ds)
        fetch_tasks.append(_limited_fetch(sheet_id, sheet_name, ss_url))

    # Fetch max 3 bersamaan
    fetch_results = await asyncio.gather(*fetch_tasks, return_exceptions=True)

    # ── Phase 2: Process & insert sequential (SQLite safe) ──
    total_new = 0
    total_updated = 0
    details = list(skip_details)

    for ds, result in zip(valid_datasets, fetch_results):
        dataset_id = ds["id"]
        ds_name = ds.get("name", f"Dataset {dataset_id}")

        if isinstance(result, Exception):
            details.append({"dataset": ds_name, "new": 0, "error": str(result)})
            continue

        rows = result
        if len(rows) < 2:
            details.append({"dataset": ds_name, "new": 0, "error": "Sheet kosong"})
            continue

        try:
            hdr = [h.strip().lower() if h else "" for h in rows[0]]
            def _hc(name, fb=None):
                try: return hdr.index(name.lower())
                except ValueError: return _col_index(fb) if fb else -1
            vi  = _hc("video_result",     "G")
            pi  = _hc("product_shopee",   "C")
            ci  = _hc("caption_shopee",   "B")
            cti = _hc("caption_tiktok")
            lti = _hc("link_tiktok")
            kti = _hc("keranjang_tiktok")
            def g(row, i): return row[i].strip() if i >= 0 and i < len(row) else ""

            # Dedup by link_tiktok (stabil), fallback video_result
            # Build map untuk auto-update video_result kalau URL berubah (CDN → Gdrive)
            conn = get_connection()
            try:
                existing = {}  # {dedup_key: {"id": int, "video_result": str}}
                for r in conn.execute(
                    "SELECT id, link_tiktok, video_result FROM video_items WHERE dataset_id=?",
                    (dataset_id,)).fetchall():
                    k = (r[1] or '').strip() or (r[2] or '').strip()
                    if k:
                        existing[k] = {"id": r[0], "video_result": (r[2] or '').strip()}
                max_no = conn.execute(
                    "SELECT COALESCE(MAX(CAST(no AS INTEGER)),0) FROM video_items WHERE dataset_id=?",
                    (dataset_id,)).fetchone()[0]
            finally:
                conn.close()
            next_no = int(max_no) + 1

            to_insert = []
            to_update = []  # [(video_id, new_url), ...]
            row_numbers_new = []
            row_numbers_existing = []
            for ri, row in enumerate(rows[1:], start=2):
                video_url = g(row, vi)
                if not video_url or not _validate_video_url(video_url):
                    continue
                link_tt = g(row, lti)
                dedup_key = link_tt or video_url
                if dedup_key in existing:
                    ex = existing[dedup_key]
                    if ex.get("id") and ex.get("video_result") != video_url:
                        to_update.append((ex["id"], video_url))
                    row_numbers_existing.append(ri)
                    continue
                to_insert.append((dataset_id, next_no, g(row, ci), g(row, pi),
                                   g(row, cti), link_tt, g(row, kti), video_url))
                row_numbers_new.append(ri)
                existing[dedup_key] = {"id": -1, "video_result": video_url}
                next_no += 1

            # Apply UPDATEs (URL change CDN → Gdrive)
            if to_update:
                conn_u = get_connection()
                try:
                    for vid, new_url in to_update:
                        conn_u.execute(
                            "UPDATE video_items SET video_result=? WHERE id=?",
                            (new_url, vid)
                        )
                    conn_u.commit()
                finally:
                    conn_u.close()

            if to_insert:
                conn2 = get_connection()
                try:
                    conn2.executemany("""
                        INSERT OR IGNORE INTO video_items
                        (dataset_id,no,caption_shopee,product_shopee,
                         caption_tiktok,link_tiktok,keranjang_tiktok,video_result)
                        VALUES (?,?,?,?,?,?,?,?)
                    """, to_insert)
                    conn2.commit()
                finally:
                    conn2.close()
                _sync_project_videos_for_dataset(dataset_id)

            # Update kolom H di Google Sheet → "Shopee Sync" (baru + existing)
            all_rows = row_numbers_new + row_numbers_existing
            if all_rows:
                import re as _re_sh
                m_sh = _re_sh.search(r'/spreadsheets/d/([^/#?]+)', ds.get("spreadsheet_url", ""))
                if m_sh:
                    try:
                        _update_sheet_column_h(m_sh.group(1), ds.get("sheet_name", "") or "", all_rows)
                    except Exception:
                        pass

            total_new += len(to_insert)
            total_updated += len(to_update)
            details.append({"dataset": ds_name, "new": len(to_insert), "updated": len(to_update)})
        except Exception as e:
            details.append({"dataset": ds_name, "new": 0, "error": str(e)})

    # ── Auto-dedup (AFTER sync): hapus baris duplikat link_tiktok global ──
    dedup_conn = get_connection()
    try:
        cur = dedup_conn.execute("""
            DELETE FROM video_items
            WHERE id IN (
              SELECT v.id FROM video_items v
              WHERE COALESCE(v.link_tiktok,'') != ''
                AND EXISTS (
                  SELECT 1 FROM video_items v2
                  WHERE v2.dataset_id = v.dataset_id
                    AND COALESCE(v2.link_tiktok,'') = COALESCE(v.link_tiktok,'')
                    AND v2.id < v.id
                )
            )
        """)
        duplicates_removed = cur.rowcount or 0
        dedup_conn.commit()
    finally:
        dedup_conn.close()

    return {
        "datasets_synced":     len(details),
        "new_videos":          total_new,
        "updated_videos":      total_updated,
        "duplicates_removed":  duplicates_removed,
        "details":             details,
    }


async def _scheduler_job(trigger_type: str = "auto"):
    """Jalankan semua project yang sched_enabled='on'."""
    from zoneinfo import ZoneInfo
    now_jkt = datetime.now(ZoneInfo("Asia/Jakarta"))

    # Prevent duplicate: skip auto-run jika sudah jalan hari ini
    if trigger_type == "auto":
        last = SchedHistoryRepo.get_last_run_today()
        if last:
            await manager.broadcast_event({
                "type": "scheduler_skipped",
                "reason": "already_ran_today",
                "last_run": last.get("triggered_at"),
                "ts": now_jkt.strftime("%H:%M:%S"),
            })
            return

    projects = ProjectRepo.get_sched_enabled()
    cfg = load_settings()
    started_ids = []

    # Jangan lanjut kalau tidak ada project terdaftar
    if not projects:
        return

    # Sync spreadsheet dulu sebelum start project
    await _sync_all_spreadsheets()

    for p in projects:
        project_id = p["id"]
        # Skip jika sudah berjalan
        if project_id in _active_procs and _active_procs[project_id].poll() is None:
            continue
        stop_file = stop_file_path(project_id)
        log_file  = log_file_path(project_id)
        try:
            if os.path.exists(stop_file):
                os.remove(stop_file)
        except Exception:
            pass
        target = int(p.get("sched_target") or cfg.get("target_per_hp", 10))
        worker_script = os.path.join(ROOT, "src", "core", "worker_process.py")
        cmd = [
            sys.executable, worker_script,
            f"--project_id={project_id}",
            f"--log_file={log_file}",
            f"--stop_file={stop_file}",
            f"--device_serial={p.get('device_serial', '')}",
            f"--target={target}",
            f"--watch_min={cfg.get('watch_min', 600)}",
            f"--watch_max={cfg.get('watch_max', 1800)}",
            f"--jeda_tiktok_shopee={cfg.get('jeda_tiktok_shopee', 30)}",
            f"--delay_start_antar_hp={cfg.get('delay_start_antar_hp', 20)}",
            "--folder_sound=" + str(cfg.get("folder_sound", "")),
            "--folder_frame_border=" + str(cfg.get("folder_frame_border", "")),
            f"--mode={p.get('mode', 'generate_ai')}",
            f"--hashtag_tambahan={cfg.get('hashtag_tambahan', '')}",
            f"--max_retry={cfg.get('max_retry', 10)}",
            f"--shopee_clone={cfg.get('shopee_clone', False)}",
            f"--use_mix_sound={p.get('use_mix_sound', 'on')}",
        ]
        proc = subprocess.Popen(cmd, cwd=ROOT,
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
        _active_procs[project_id] = proc
        started_ids.append(project_id)
        ProjectRepo.update_status(project_id, "berjalan")
        await manager.broadcast_status(project_id, "berjalan")
        task = asyncio.create_task(_poll_log(project_id, log_file, stop_file))
        _pollers[project_id] = task
        # Delay antar HP
        await asyncio.sleep(cfg.get("delay_start_antar_hp", 20))

    # Broadcast ulang dengan jumlah yang benar-benar di-spawn
    await manager.broadcast_event({
        "type": "scheduler_triggered",
        "trigger_type": trigger_type,
        "project_count": len(started_ids),
        "ts": now_jkt.strftime("%H:%M:%S"),
    })

    # Simpan history hanya jika ada yang dimulai
    if started_ids:
        SchedHistoryRepo.record(trigger_type, started_ids)


def _scheduler_reschedule():
    """Baca settings dan terapkan ulang jadwal di _scheduler."""
    if not _APSCHEDULER_OK or _scheduler is None:
        return
    cfg = load_settings()
    enabled = cfg.get("sched_global_enabled", False)
    time_str = cfg.get("sched_time", "08:00")
    try:
        hour, minute = [int(x) for x in time_str.split(":")]
    except Exception:
        hour, minute = 8, 0

    _scheduler.remove_job(_SCHED_JOB_ID) if _scheduler.get_job(_SCHED_JOB_ID) else None

    if enabled:
        from zoneinfo import ZoneInfo
        _scheduler.add_job(
            _scheduler_job,
            CronTrigger(hour=hour, minute=minute, timezone=ZoneInfo("Asia/Jakarta")),
            id=_SCHED_JOB_ID,
            replace_existing=True,
        )


class SchedConfigBody(BaseModel):
    sched_global_enabled: bool = False
    sched_time: str = "08:00"


@app.get("/api/scheduler")
def get_scheduler():
    cfg = load_settings()
    next_run = None
    if _APSCHEDULER_OK and _scheduler is not None:
        job = _scheduler.get_job(_SCHED_JOB_ID)
        if job and job.next_run_time:
            from zoneinfo import ZoneInfo
            jkt = ZoneInfo("Asia/Jakarta")
            next_run = job.next_run_time.astimezone(jkt).strftime("%Y-%m-%d %H:%M:%S WIB")
    last = SchedHistoryRepo.get_last_run_today()
    return {
        "available": _APSCHEDULER_OK,
        "enabled": cfg.get("sched_global_enabled", False),
        "time": cfg.get("sched_time", "08:00"),
        "next_run": next_run,
        "ran_today": last is not None,
        "last_run": last,
    }


@app.get("/api/scheduler/history")
def get_scheduler_history(limit: int = 20):
    return {"history": SchedHistoryRepo.get_recent(limit)}


@app.post("/api/scheduler")
def set_scheduler(body: SchedConfigBody):
    cfg = load_settings()
    cfg["sched_global_enabled"] = body.sched_global_enabled
    cfg["sched_time"] = body.sched_time
    save_settings(cfg)
    _scheduler_reschedule()
    return {"message": "Jadwal disimpan"}


@app.post("/api/scheduler/trigger")
async def trigger_scheduler_now():
    """Manual trigger — jalankan semua project terjadwal sekarang."""
    asyncio.create_task(_scheduler_job(trigger_type="manual"))
    return {"message": "Scheduler dipicu manual"}


@app.patch("/api/projects/{project_id}/sched")
async def patch_project_sched(project_id: int, request: Request):
    """Update sched_enabled / sched_target project tanpa full update."""
    data = await request.json()
    sched_enabled = data.get("sched_enabled", "off")
    sched_target  = int(data.get("sched_target", 10))
    ProjectRepo.update_sched(project_id, sched_enabled, sched_target)
    return {"message": "ok"}


def backup_database_on_startup():
    """Backup database sebelum server start — simpan max 20 backup terakhir."""
    import shutil
    db_path = os.path.join(ROOT, "data", "seedapp.db")
    if not os.path.exists(db_path):
        return
    backup_dir = os.path.join(ROOT, "data", "backups")
    os.makedirs(backup_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(backup_dir, f"seedapp_{ts}.db")
    try:
        shutil.copy2(db_path, backup_path)
        print(f"  💾 Database backup: {backup_path}")
    except Exception as e:
        print(f"  ⚠️  Backup gagal: {e}")
    # Hapus backup lama, simpan hanya 20 terakhir
    try:
        backups = sorted([
            f for f in os.listdir(backup_dir)
            if f.startswith("seedapp_") and f.endswith(".db")
        ])
        while len(backups) > 20:
            oldest = backups.pop(0)
            os.remove(os.path.join(backup_dir, oldest))
            print(f"  🗑  Hapus backup lama: {oldest}")
    except Exception:
        pass


def clear_logs_on_startup():
    """Hapus semua log file saat server start agar Monitor selalu fresh."""
    logs_dir = os.path.join(ROOT, "logs")  # sama dengan log_manager.py LOGS_DIR
    if not os.path.isdir(logs_dir):
        return
    count = 0
    for fname in os.listdir(logs_dir):
        if fname.startswith("log_") and fname.endswith(".txt"):
            try:
                os.remove(os.path.join(logs_dir, fname))
                count += 1
            except Exception:
                pass
    if count:
        print(f"  🗑  Cleared {count} log file(s)")


# ══════════════════════════════════════════════════════
#  REMOTE CONTROL API
#  Auth: header X-API-Key (set di Settings → remote_api_key)
# ══════════════════════════════════════════════════════

# Whitelist perintah shell yang diizinkan (prefix match)
_SHELL_WHITELIST = [
    "input ", "am start", "am force-stop", "am broadcast",
    "dumpsys", "getprop", "settings get", "settings put",
    "pm list", "wm size", "wm density",
    "screencap", "screenrecord",
    "mkdir", "ls ", "cat ", "echo ",
    "monkey ", "cmd ",
]

def _require_api_key(request: Request):
    key = request.headers.get("X-API-Key", "")
    cfg = load_settings().get("remote_api_key", "")
    if not cfg:
        raise HTTPException(403, "Remote API belum diaktifkan. Set remote_api_key di Settings.")
    if key != cfg:
        raise HTTPException(401, "X-API-Key tidak valid.")

def _check_shell_whitelist(cmd: str) -> bool:
    cmd_lower = cmd.strip().lower()
    return any(cmd_lower.startswith(w.lower()) for w in _SHELL_WHITELIST)

def _get_devices_raw() -> list:
    """Return list of (serial, status) dari adb devices."""
    out = adb_helper._run(["devices", "-l"])
    result = []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2 or parts[0].startswith("*"):
            continue
        result.append((parts[0], parts[1]))
    return result

def _device_online(serial: str) -> bool:
    return any(s == serial and st == "device" for s, st in _get_devices_raw())

def _ok(data: dict = None, message: str = "ok") -> dict:
    return {"success": True, "message": message, **(data or {})}

def _err(message: str, status: int = 400):
    raise HTTPException(status, {"success": False, "message": message})


# ── 1. List devices ───────────────────────────────────
@app.get("/api/remote/devices")
def remote_list_devices(request: Request):
    _require_api_key(request)
    raw     = adb_helper._run(["devices", "-l"])
    aliases = load_settings().get("device_aliases", {})
    devices = []
    for line in raw.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2 or parts[0].startswith("*"):
            continue
        serial = parts[0]
        status = parts[1]
        model  = next((p.replace("model:", "").replace("_", " ")
                       for p in parts if p.startswith("model:")), serial)
        alias  = aliases.get(serial, model)
        devices.append({
            "serial": serial,
            "alias":  alias,
            "model":  model,
            "online": status == "device",
            "status": status,
        })
    return _ok({"devices": devices, "count": len(devices)})


# ── 2. Open app ───────────────────────────────────────
class OpenAppBody(BaseModel):
    package: str

@app.post("/api/remote/devices/{serial}/open-app")
def remote_open_app(serial: str, body: OpenAppBody, request: Request):
    _require_api_key(request)
    if not _device_online(serial):
        _err(f"Device {serial} offline", 503)
    out = adb_helper._run(["shell", "monkey", "-p", body.package,
                            "-c", "android.intent.category.LAUNCHER", "1"], serial)
    if "monkey aborted" in out.lower() or "does not exist" in out.lower():
        _err(f"Gagal buka app: {out}")
    return _ok({"output": out}, f"App {body.package} dibuka")


# ── 3. Shell command (whitelisted) ────────────────────
class ShellBody(BaseModel):
    command: str

@app.post("/api/remote/devices/{serial}/shell")
def remote_shell(serial: str, body: ShellBody, request: Request):
    _require_api_key(request)
    if not _check_shell_whitelist(body.command):
        _err(f"Perintah tidak diizinkan: '{body.command}'. Gunakan perintah yang ada di whitelist.")
    if not _device_online(serial):
        _err(f"Device {serial} offline", 503)
    out = adb_helper.shell(body.command, serial, timeout=15)
    return _ok({"output": out})


# ── 4. Input text ─────────────────────────────────────
class InputTextBody(BaseModel):
    text: str

@app.post("/api/remote/devices/{serial}/input/text")
def remote_input_text(serial: str, body: InputTextBody, request: Request):
    _require_api_key(request)
    if not _device_online(serial):
        _err(f"Device {serial} offline", 503)
    safe = body.text.replace(" ", "%s").replace("'", "\\'")
    adb_helper._run(["shell", "input", "text", safe], serial)
    return _ok(message=f"Teks '{body.text}' dikirim")


# ── 5. Tap koordinat ──────────────────────────────────
class TapBody(BaseModel):
    x: float
    y: float

@app.post("/api/remote/devices/{serial}/input/tap")
def remote_tap(serial: str, body: TapBody, request: Request):
    _require_api_key(request)
    if not _device_online(serial):
        _err(f"Device {serial} offline", 503)
    adb_helper._run(["shell", "input", "tap", str(int(body.x)), str(int(body.y))], serial)
    return _ok(message=f"Tap ({int(body.x)}, {int(body.y)}) berhasil")


# ── 6. Screenshot ─────────────────────────────────────
@app.get("/api/remote/devices/{serial}/screenshot")
def remote_screenshot(serial: str, request: Request):
    _require_api_key(request)
    if not _device_online(serial):
        _err(f"Device {serial} offline", 503)
    import base64
    out = subprocess.run(
        [adb_helper.ADB_PATH, "-s", serial, "exec-out", "screencap", "-p"],
        capture_output=True, timeout=15
    )
    if not out.stdout:
        _err("Screenshot gagal — device mungkin terkunci")
    img_b64 = base64.b64encode(out.stdout).decode()
    return _ok({"image_base64": img_b64, "format": "png"})




# ══════════════════════════════════════════════════════
# ── Shopee Scraper (Chrome Extension backend) ────────
# ══════════════════════════════════════════════════════

from src.scraper.shopee_scraper import ShopeeScraper

_scraper = ShopeeScraper()
_scraper_csv: str = ""
_scraper_count: int = 0


class ScraperCollectBody(BaseModel):
    results: List[dict]


@app.post("/scraper/collect")
def scraper_collect(body: ScraperCollectBody):
    """Terima hasil scraping dari Chrome Extension, generate CSV."""
    global _scraper_csv, _scraper_count
    if not body.results:
        raise HTTPException(400, "Data kosong")
    _scraper_csv = _scraper.generate_csv(body.results)
    _scraper_count = len(body.results)
    return {"ok": True, "count": _scraper_count}


@app.get("/scraper/download")
def scraper_download():
    """Download hasil scraping sebagai CSV."""
    if not _scraper_csv:
        raise HTTPException(404, "Belum ada data. Jalankan scraper dulu.")
    return PlainTextResponse(
        content=_scraper_csv,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=shopee_scraper_result.csv"},
    )


@app.get("/scraper/open-extension-folder")
def scraper_open_extension_folder():
    """Buka folder extension di explorer."""
    ext_dir = os.path.join(ROOT, "extension")
    if not os.path.isdir(ext_dir):
        raise HTTPException(404, "Folder extension tidak ditemukan")
    import subprocess as _sp
    try:
        _sp.Popen(["explorer", ext_dir])
    except Exception:
        pass
    return {"ok": True, "path": ext_dir}


if __name__ == "__main__":
    import uvicorn
    # Tulis PID ke file agar run.bat bisa kill proses ini saat dibuka lagi
    _pid_file = os.path.join(ROOT, "seedapp.pid")
    try:
        with open(_pid_file, "w") as _pf:
            _pf.write(str(os.getpid()))
    except Exception:
        pass
    backup_database_on_startup()
    clear_logs_on_startup()
    try:
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="warning")
    finally:
        try: os.remove(_pid_file)
        except Exception: pass
