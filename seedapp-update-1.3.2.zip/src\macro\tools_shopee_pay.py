"""
Tools — Cek Saldo ShopeePay
Scrape username + saldo ShopeePay dari akun yang sedang login.
"""

import time
import uiautomator2 as u2

SHOPEE_PACKAGE = "com.shopee.id"

# Timeout default
WAIT_TIMEOUT = 10


def _force_close_foreground(d):
    try:
        current = d.app_current()
        pkg = current.get("package", "")
        if pkg:
            d.app_stop(pkg)
    except Exception:
        pass


def _start_shopee(d, clone: bool):
    d.shell("settings put system accelerometer_rotation 0")
    d.shell("settings put system user_rotation 0")
    if clone:
        d.shell(f"am start --user 999 -n {SHOPEE_PACKAGE}/com.shopee.app.ui.home.HomeActivity_")
    else:
        d.app_start(SHOPEE_PACKAGE)
    time.sleep(3)


def _stop_shopee(d, clone: bool):
    if clone:
        d.shell(f"am force-stop --user 999 {SHOPEE_PACKAGE}")
    else:
        d.app_stop(SHOPEE_PACKAGE)


def _dismiss_popup(d):
    """Tutup popup/dialog yang mungkin muncul saat buka Shopee."""
    for _ in range(3):
        if d(description="Close").exists(timeout=1):
            d(description="Close").click()
            time.sleep(0.5)
        elif d(text="Nanti Saja").exists(timeout=1):
            d(text="Nanti Saja").click()
            time.sleep(0.5)
        elif d(text="Lewati").exists(timeout=1):
            d(text="Lewati").click()
            time.sleep(0.5)
        else:
            break


def scrape_shopee_pay(serial: str, clone: bool, log=None) -> dict:
    """
    Scrape username + saldo ShopeePay dari 1 device.
    Return: {"username": str, "saldo": str, "error": str|None}
    """
    def _log(msg):
        if log:
            log(msg)

    result = {"username": "—", "saldo": "—", "error": None}

    try:
        d = u2.connect(serial)
        _log(f"📱 Terhubung ke {serial}")

        # Kalau Shopee belum di foreground → launch (tanpa force-close app lain).
        # Kalau sudah kebuka, skip langsung lanjut (tidak ganggu state user).
        current_pkg = ""
        try:
            current_pkg = (d.app_current() or {}).get("package", "")
        except Exception:
            pass

        if current_pkg != SHOPEE_PACKAGE:
            _log("🚀 Shopee belum terbuka, launching...")
            _start_shopee(d, clone)
            time.sleep(1)
            _dismiss_popup(d)
        else:
            _log("✅ Shopee sudah terbuka, skip launch")

        # Cek apakah sudah di tab Saya (labelUserName visible = sudah di Saya)
        if d(resourceId="labelUserName").exists(timeout=1):
            _log("✅ Sudah di tab Saya, skip navigasi")
        else:
            _log("👤 Navigasi ke tab Saya...")
            tab_saya = d(description="tab_bar_button_me")
            if not tab_saya.exists(timeout=WAIT_TIMEOUT):
                tab_saya = d(text="Saya")
            if not tab_saya.exists(timeout=3):
                result["error"] = "Tab Saya tidak ditemukan"
                _log(f"❌ {result['error']}")
                return result
            tab_saya.click()
            time.sleep(2)
            _dismiss_popup(d)

        # Scrape username
        _log("🔍 Scrape username...")
        el_username = d(resourceId="labelUserName")
        if el_username.exists(timeout=WAIT_TIMEOUT):
            result["username"] = el_username.get_text() or "—"
            _log(f"✅ Username: {result['username']}")
        else:
            result["error"] = "Elemen username tidak ditemukan"
            _log(f"⚠ {result['error']}")

        # Scrape saldo ShopeePay
        _log("💰 Scrape saldo ShopeePay...")
        els = d.xpath('//*[@resource-id="meCircleSubtitleView"]//android.widget.TextView')
        saldo_list = els.all()
        if saldo_list:
            result["saldo"] = saldo_list[0].attrib.get("text", "Rp0") or "Rp0"
            _log(f"✅ Saldo: {result['saldo']}")
        else:
            result["error"] = (result.get("error") or "") + " | Elemen saldo tidak ditemukan"
            _log(f"⚠ Elemen saldo tidak ditemukan")

    except Exception as e:
        result["error"] = str(e)
        _log(f"❌ Error: {e}")

    return result
