"""
Database Layer - SeedApp
Schema tambahan:
  - projects.mode          : 'generate_ai' | 'reupload_shopee'
  - projects.upload_target : 'shopee_tiktok' | 'shopee' | 'tiktok_only'
  - project_videos.status_shopee  : antrian|proses|selesai|error
  - project_videos.status_tiktok  : antrian|proses|selesai|error|skip
  - project_videos.status (computed/overall) : antrian|proses|selesai|error
"""

import sqlite3
import os
from typing import List, Optional, Dict

DB_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'seedapp.db')


def get_connection() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")  # Write-Ahead Logging — aman untuk multi-thread
    return conn


def init_db():
    conn = get_connection()
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS datasets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL,
            description TEXT DEFAULT '',
            format      TEXT DEFAULT 'generate_ai',
            created_at  TEXT DEFAULT (datetime('now','localtime')),
            updated_at  TEXT DEFAULT (datetime('now','localtime'))
        );

        CREATE TABLE IF NOT EXISTS video_items (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            dataset_id       INTEGER NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
            no               INTEGER,
            caption_shopee   TEXT DEFAULT '',
            product_shopee   TEXT DEFAULT '',
            caption_tiktok   TEXT DEFAULT '',
            link_tiktok      TEXT DEFAULT '',
            keranjang_tiktok TEXT DEFAULT '',
            video_result     TEXT DEFAULT '',
            -- Kolom khusus Reupload Shopee (prefix rs_)
            rs_judul            TEXT DEFAULT '',
            rs_url              TEXT DEFAULT '',
            rs_deskripsi        TEXT DEFAULT '',
            rs_gambar           TEXT DEFAULT '',
            rs_sumber           TEXT DEFAULT '',
            rs_file_lokal       TEXT DEFAULT '',
            rs_produk           TEXT DEFAULT '',
            rs_keranjang_kuning TEXT DEFAULT '',
            rs_link_affiliate   TEXT DEFAULT '',
            downloaded       INTEGER DEFAULT 0,
            created_at       TEXT DEFAULT (datetime('now','localtime'))
        );

        CREATE TABLE IF NOT EXISTS projects (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            name           TEXT NOT NULL,
            description    TEXT DEFAULT '',
            dataset_id     INTEGER REFERENCES datasets(id) ON DELETE SET NULL,
            device_serial  TEXT DEFAULT '',
            mode           TEXT DEFAULT 'generate_ai',
            upload_target  TEXT DEFAULT 'shopee_tiktok',
            status         TEXT DEFAULT 'antrian',
            created_at     TEXT DEFAULT (datetime('now','localtime')),
            updated_at     TEXT DEFAULT (datetime('now','localtime'))
        );

        CREATE TABLE IF NOT EXISTS project_videos (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id     INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
            video_id       INTEGER NOT NULL REFERENCES video_items(id) ON DELETE CASCADE,
            status         TEXT DEFAULT 'antrian',
            status_shopee  TEXT DEFAULT 'antrian',
            status_tiktok  TEXT DEFAULT 'antrian',
            updated_at     TEXT DEFAULT (datetime('now','localtime')),
            UNIQUE(project_id, video_id)
        );
        """)
        _run_migrations(conn)
        _migrate_old_db(conn)
        conn.commit()
    finally:
        conn.close()


def _run_migrations(conn):
    """Tambah kolom baru jika belum ada (safe ALTER TABLE)."""
    existing_proj = [r[1] for r in conn.execute("PRAGMA table_info(projects)").fetchall()]
    existing_vi = [r[1] for r in conn.execute("PRAGMA table_info(video_items)").fetchall()]
    for col_def in [
        ("rs_judul",            "TEXT DEFAULT ''"),
        ("rs_url",              "TEXT DEFAULT ''"),
        ("rs_deskripsi",        "TEXT DEFAULT ''"),
        ("rs_gambar",           "TEXT DEFAULT ''"),
        ("rs_sumber",           "TEXT DEFAULT ''"),
        ("rs_file_lokal",       "TEXT DEFAULT ''"),
        ("rs_produk",           "TEXT DEFAULT ''"),
        ("rs_keranjang_kuning", "TEXT DEFAULT ''"),
        ("rs_link_affiliate",   "TEXT DEFAULT ''"),
        ("deleted",             "INTEGER DEFAULT 0"),  # Soft delete flag (user menghapus dari SeedApp)
    ]:
        if col_def[0] not in existing_vi:
            conn.execute(f"ALTER TABLE video_items ADD COLUMN {col_def[0]} {col_def[1]}")

    existing_ds = [r[1] for r in conn.execute("PRAGMA table_info(datasets)").fetchall()]
    if 'format' not in existing_ds:
        conn.execute("ALTER TABLE datasets ADD COLUMN format TEXT DEFAULT 'generate_ai'")
    if 'spreadsheet_url' not in existing_ds:
        conn.execute("ALTER TABLE datasets ADD COLUMN spreadsheet_url TEXT DEFAULT ''")
    if 'sheet_name' not in existing_ds:
        conn.execute("ALTER TABLE datasets ADD COLUMN sheet_name TEXT DEFAULT ''")

    if 'mode' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN mode TEXT DEFAULT 'generate_ai'")
    if 'upload_target' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN upload_target TEXT DEFAULT 'shopee_tiktok'")
    if 'rs_use_frame' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN rs_use_frame TEXT DEFAULT 'on'")
    if 'rs_use_song' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN rs_use_song TEXT DEFAULT 'on'")
    if 'use_mix_sound' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN use_mix_sound TEXT DEFAULT 'on'")
    if 'sched_enabled' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN sched_enabled TEXT DEFAULT 'off'")
    if 'sched_target' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN sched_target INTEGER DEFAULT 10")
    if 'shopee_username' not in existing_proj:
        conn.execute("ALTER TABLE projects ADD COLUMN shopee_username TEXT DEFAULT ''")

    existing_pv = [r[1] for r in conn.execute("PRAGMA table_info(project_videos)").fetchall()]
    if 'status_shopee' not in existing_pv:
        conn.execute("ALTER TABLE project_videos ADD COLUMN status_shopee TEXT DEFAULT 'antrian'")
    if 'status_tiktok' not in existing_pv:
        conn.execute("ALTER TABLE project_videos ADD COLUMN status_tiktok TEXT DEFAULT 'antrian'")
    if 'error_shopee' not in existing_pv:
        conn.execute("ALTER TABLE project_videos ADD COLUMN error_shopee TEXT DEFAULT ''")
    if 'error_tiktok' not in existing_pv:
        conn.execute("ALTER TABLE project_videos ADD COLUMN error_tiktok TEXT DEFAULT ''")

    # ── UNIQUE INDEXes untuk mencegah duplikat video_items (DB-level guarantee) ──
    # Primary: dedup by link_tiktok (stabil, tidak berubah meski URL video change)
    conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_vi_unique_link_tt
        ON video_items(dataset_id, link_tiktok)
        WHERE link_tiktok != ''
    """)
    # Fallback: row tanpa link_tiktok → dedup by video_result (legacy data)
    conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_vi_unique_url
        ON video_items(dataset_id, video_result)
        WHERE link_tiktok = '' AND video_result != ''
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS upload_stats (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            device      TEXT DEFAULT '',
            platform    TEXT DEFAULT '',
            uploaded_at TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sched_history (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            triggered_at TEXT DEFAULT (datetime('now','localtime')),
            trigger_type TEXT DEFAULT 'auto',
            projects_started INTEGER DEFAULT 0,
            project_ids  TEXT DEFAULT ''
        )
    """)
    conn.commit()


def _migrate_old_db(conn):
    """Migrasi dari envidi.db (schema lama) ke seedapp.db — hanya sekali."""
    old_path = os.path.join(os.path.dirname(DB_PATH), 'envidi.db')
    if not os.path.exists(old_path):
        return
    existing = conn.execute("SELECT COUNT(*) FROM datasets").fetchone()[0]
    if existing > 0:
        return
    try:
        conn.execute(f"ATTACH DATABASE '{old_path}' AS old")
        conn.execute("INSERT OR IGNORE INTO datasets SELECT id,name,description,created_at,updated_at FROM old.datasets")
        conn.execute("""
            INSERT OR IGNORE INTO video_items
                (id,dataset_id,no,caption_shopee,product_shopee,
                 caption_tiktok,link_tiktok,keranjang_tiktok,video_result,downloaded,created_at)
            SELECT id,dataset_id,no,caption_shopee,product_shopee,
                   caption_tiktok,link_tiktok,keranjang_tiktok,video_result,
                   COALESCE(downloaded,0),created_at
            FROM old.video_items
        """)
        conn.execute("""
            INSERT OR IGNORE INTO projects
                (id,name,description,dataset_id,device_serial,status,created_at,updated_at)
            SELECT id,name,description,dataset_id,
                   COALESCE(device_serial,''),status,created_at,updated_at
            FROM old.projects
        """)
        conn.execute("""
            INSERT OR IGNORE INTO project_videos (project_id, video_id, status)
            SELECT p.id, v.id, COALESCE(v.status,'antrian')
            FROM old.projects p
            JOIN old.video_items v ON v.dataset_id = p.dataset_id
        """)
        conn.execute("DETACH DATABASE old")
        conn.commit()
        print("✅ Migrasi envidi.db → seedapp.db selesai")
    except Exception as e:
        print(f"⚠️  Migrasi skip: {e}")
        try: conn.execute("DETACH DATABASE old")
        except: pass


# ═══════════════════════════════════════════════════
#  DATASET REPO
# ═══════════════════════════════════════════════════
class DatasetRepo:

    @staticmethod
    def get_all() -> List[Dict]:
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT d.*, COUNT(v.id) as total_video
                FROM datasets d
                LEFT JOIN video_items v ON v.dataset_id = d.id
                GROUP BY d.id ORDER BY d.created_at DESC
            """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_by_id(dataset_id: int) -> Optional[Dict]:
        conn = get_connection()
        try:
            row = conn.execute("SELECT * FROM datasets WHERE id=?", (dataset_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def create(name: str, description: str = '', format: str = 'generate_ai') -> int:
        conn = get_connection()
        try:
            cur = conn.execute("INSERT INTO datasets (name,description,format) VALUES (?,?,?)", (name, description, format))
            conn.commit()
            return cur.lastrowid
        finally:
            conn.close()

    @staticmethod
    def update(dataset_id: int, name: str, description: str = ''):
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE datasets SET name=?,description=?,updated_at=datetime('now','localtime') WHERE id=?",
                (name, description, dataset_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def update_format(dataset_id: int, format: str):
        conn = get_connection()
        try:
            conn.execute("UPDATE datasets SET format=?,updated_at=datetime('now','localtime') WHERE id=?", (format, dataset_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def update_spreadsheet(dataset_id: int, spreadsheet_url: str, sheet_name: str):
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE datasets SET spreadsheet_url=?,sheet_name=?,updated_at=datetime('now','localtime') WHERE id=?",
                (spreadsheet_url, sheet_name, dataset_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_all_with_spreadsheet() -> List[Dict]:
        """Return semua dataset yang punya spreadsheet_url terdaftar."""
        conn = get_connection()
        try:
            rows = conn.execute(
                "SELECT * FROM datasets WHERE spreadsheet_url != '' AND spreadsheet_url IS NOT NULL"
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def delete(dataset_id: int):
        conn = get_connection()
        try:
            conn.execute("DELETE FROM datasets WHERE id=?", (dataset_id,))
            conn.commit()
        finally:
            conn.close()


# ═══════════════════════════════════════════════════
#  VIDEO REPO
# ═══════════════════════════════════════════════════
class VideoRepo:

    @staticmethod
    def delete_by_id(video_id: int, project_id: int = None):
        """Hapus satu video dari project_videos. Jika project_id diberikan, hapus by video_id+project_id. Jika tidak, hapus by pv.id."""
        conn = get_connection()
        try:
            if project_id:
                conn.execute("DELETE FROM project_videos WHERE video_id=? AND project_id=?", (video_id, project_id))
            else:
                conn.execute("DELETE FROM project_videos WHERE id=?", (video_id,))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def delete_bulk_by_ids(pv_ids: list):
        """Soft-delete: set status='skip' agar tidak muncul di project tapi tidak balik saat sync."""
        if not pv_ids:
            return
        conn = get_connection()
        try:
            placeholders = ",".join("?" * len(pv_ids))
            conn.execute(f"UPDATE project_videos SET status='skip' WHERE id IN ({placeholders})", list(pv_ids))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def set_file_lokal(video_id: int, path: str):
        """Set rs_file_lokal setelah convert selesai."""
        conn = get_connection()
        try:
            conn.execute("UPDATE video_items SET rs_file_lokal=? WHERE id=?", (path, video_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def clear_file_lokal(video_id: int):
        """Hapus rs_file_lokal (file setengah jadi saat stop)."""
        conn = get_connection()
        try:
            conn.execute("UPDATE video_items SET rs_file_lokal='' WHERE id=?", (video_id,))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_convert_summary(project_id: int) -> dict:
        """Hitung total dan converted per project."""
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT v.rs_file_lokal
                FROM video_items v
                JOIN project_videos pv ON pv.video_id = v.id AND pv.project_id = ?
            """, (project_id,)).fetchall()
            total     = len(rows)
            converted = sum(1 for r in rows if r[0] and r[0].strip())
            return {"total": total, "converted": converted, "belum": total - converted}
        finally:
            conn.close()

    @staticmethod
    def get_by_dataset(dataset_id: int, status_filter: str = 'semua') -> List[Dict]:
        """Ambil video by dataset (untuk dataset_page — tanpa project context)."""
        conn = get_connection()
        try:
            rows = conn.execute(
                "SELECT * FROM video_items WHERE dataset_id=? AND COALESCE(deleted,0)=0 ORDER BY no ASC",
                (dataset_id,)
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_by_project(project_id: int, status_filter: str = 'semua') -> List[Dict]:
        """Ambil video dengan status PER PROJECT."""
        conn = get_connection()
        try:
            query = """
                SELECT v.*,
                    pv.id                                as pv_id,
                    COALESCE(pv.status,'antrian')        as status,
                    COALESCE(pv.status_shopee,'antrian') as status_shopee,
                    COALESCE(pv.status_tiktok,'antrian') as status_tiktok,
                    COALESCE(pv.error_shopee,'')         as error_shopee,
                    COALESCE(pv.error_tiktok,'')         as error_tiktok
                FROM video_items v
                JOIN projects p ON p.dataset_id = v.dataset_id
                JOIN project_videos pv ON pv.video_id = v.id AND pv.project_id = p.id
                WHERE p.id = ? AND COALESCE(pv.status,'antrian') != 'skip'
            """
            params = [project_id]
            if status_filter == 'selesai':
                # selesai = minimal 1 platform sukses
                query += """ AND (
                    COALESCE(pv.status_shopee,'antrian')='selesai'
                    OR COALESCE(pv.status_tiktok,'antrian')='selesai'
                )"""
            elif status_filter == 'error':
                # error = keduanya gagal (atau shopee-only gagal)
                query += " AND COALESCE(pv.status,'antrian')='error'"
            elif status_filter not in ('semua', ''):
                query += " AND COALESCE(pv.status,'antrian') = ?"
                params.append(status_filter)
            if status_filter == 'selesai':
                query += " ORDER BY pv.updated_at ASC, v.no ASC"
            else:
                query += " ORDER BY v.no ASC"
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def update_status_by_project(project_id: int, video_id: int,
                                  status: str,
                                  status_shopee: str = None,
                                  status_tiktok: str = None):
        """Update status per project. status_shopee/tiktok opsional."""
        conn = get_connection()
        try:
            # video_id = video_items.id = kolom video_id di project_videos
            row = conn.execute(
                "SELECT status_shopee, status_tiktok FROM project_videos WHERE project_id=? AND video_id=?",
                (project_id, video_id)
            ).fetchone()

            old_shopee = row['status_shopee'] if row else 'antrian'
            old_tiktok = row['status_tiktok'] if row else 'antrian'

            new_shopee = status_shopee if status_shopee is not None else old_shopee
            new_tiktok = status_tiktok if status_tiktok is not None else old_tiktok

            conn.execute("""
                UPDATE project_videos SET
                    status        = ?,
                    status_shopee = ?,
                    status_tiktok = ?,
                    updated_at    = datetime('now','localtime')
                WHERE project_id = ? AND video_id = ?
            """, (status, new_shopee, new_tiktok, project_id, video_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def save_error_message(project_id: int, video_id: int,
                           error_shopee: str = None, error_tiktok: str = None):
        """Simpan pesan error per platform."""
        conn = get_connection()
        try:
            if error_shopee is not None:
                conn.execute("""
                    UPDATE project_videos SET error_shopee=?, updated_at=datetime('now','localtime')
                    WHERE project_id=? AND video_id=?
                """, (error_shopee, project_id, video_id))
            if error_tiktok is not None:
                conn.execute("""
                    UPDATE project_videos SET error_tiktok=?, updated_at=datetime('now','localtime')
                    WHERE project_id=? AND video_id=?
                """, (error_tiktok, project_id, video_id))
            conn.commit()
        finally:
            conn.close()


    @staticmethod
    def update_fields(video_id: int, fields: dict, project_id: int = None):
        """Update field di video_items dan/atau project_videos."""
        if not fields:
            return
        VIDEO_FIELDS   = {'product_shopee','caption_shopee','caption_tiktok',
                          'link_tiktok','keranjang_tiktok','video_result',
                          'rs_judul','rs_url','rs_deskripsi','rs_gambar','rs_sumber',
                          'rs_file_lokal','rs_produk','rs_keranjang_kuning','rs_link_affiliate'}
        PROJECT_FIELDS = {'status_shopee','status_tiktok','status'}

        video_upd   = {k: v for k, v in fields.items() if k in VIDEO_FIELDS}
        project_upd = {k: v for k, v in fields.items() if k in PROJECT_FIELDS}

        conn = get_connection()
        try:
            if video_upd:
                set_clause = ', '.join(f"{k} = ?" for k in video_upd)
                conn.execute(
                    f"UPDATE video_items SET {set_clause} WHERE id = ?",
                    list(video_upd.values()) + [video_id]
                )
            if project_upd and project_id:
                set_clause = ', '.join(f"{k} = ?" for k in project_upd)
                conn.execute(
                    f"UPDATE project_videos SET {set_clause} WHERE video_id = ? AND project_id = ?",
                    list(project_upd.values()) + [video_id, project_id]
                )
            conn.commit()
        finally:
            conn.close()


    @staticmethod
    def reset_failed_to_antrian(project_id: int):
        """
        Ulangi Gagal logic:
        - proses → error (stabilize dulu)
        - error & error → antrian & antrian (keduanya gagal, ulangi dari awal)
        - selesai & error / error & selesai → status_shopee & status_tiktok TIDAK BERUBAH,
          hanya overall status di-set ke 'selesai' supaya keluar dari Tab Error
        """
        conn = get_connection()
        try:
            # Step 1: stabilize proses → error
            # (status='skip' = item yang DIHAPUS user → jangan disentuh, biar tak balik)
            conn.execute("""
                UPDATE project_videos SET
                    status_shopee = CASE WHEN status_shopee = 'proses' THEN 'error' ELSE status_shopee END,
                    status_tiktok = CASE WHEN status_tiktok = 'proses' THEN 'error' ELSE status_tiktok END,
                    updated_at    = datetime('now','localtime')
                WHERE project_id = ?
                  AND COALESCE(status,'antrian') != 'skip'
                  AND (status_shopee = 'proses' OR status_tiktok = 'proses')
            """, (project_id,))

            # Step 2: error & error → reset KEDUANYA ke antrian (kecuali yang dihapus/skip)
            conn.execute("""
                UPDATE project_videos SET
                    status_shopee = 'antrian',
                    status_tiktok = 'antrian',
                    updated_at    = datetime('now','localtime')
                WHERE project_id = ?
                  AND COALESCE(status,'antrian') != 'skip'
                  AND status_shopee = 'error'
                  AND status_tiktok = 'error'
            """, (project_id,))

            # Step 3: recalculate overall status (status_shopee/tiktok TIDAK disentuh)
            # - antrian|antrian → antrian
            # - selesai|* atau *|selesai → selesai (termasuk selesai|error yang tidak ikut step 2)
            # - proses di salah satu → proses
            # - else → antrian
            conn.execute("""
                UPDATE project_videos SET
                    status = CASE
                        WHEN status_shopee = 'selesai' OR status_tiktok = 'selesai' THEN 'selesai'
                        WHEN status_shopee = 'proses'  OR status_tiktok = 'proses'  THEN 'proses'
                        WHEN status_shopee = 'antrian' AND status_tiktok = 'antrian' THEN 'antrian'
                        ELSE 'antrian'
                    END,
                    updated_at = datetime('now','localtime')
                WHERE project_id = ?
                  AND COALESCE(status,'antrian') != 'skip'
            """, (project_id,))

            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def reset_error_to_antrian(project_id: int):
        """Alias for backward compat."""
        VideoRepo.reset_failed_to_antrian(project_id)

    @staticmethod
    def init_project_videos(project_id: int, dataset_id: int):
        conn = get_connection()
        try:
            conn.execute("""
                INSERT OR IGNORE INTO project_videos (project_id, video_id, status)
                SELECT ?, id, 'antrian' FROM video_items WHERE dataset_id=? AND COALESCE(deleted,0)=0
            """, (project_id, dataset_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_stats_by_project(project_id: int) -> Dict:
        """Statistik per project — selesai = minimal 1 platform sukses."""
        conn = get_connection()
        try:
            row = conn.execute("""
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN COALESCE(pv.status,'antrian')='antrian' THEN 1 ELSE 0 END) as antrian,
                    SUM(CASE WHEN COALESCE(pv.status,'antrian')='proses'  THEN 1 ELSE 0 END) as proses,
                    SUM(CASE WHEN
                        COALESCE(pv.status_shopee,'antrian')='selesai'
                        OR COALESCE(pv.status_tiktok,'antrian')='selesai'
                        THEN 1 ELSE 0 END) as selesai,
                    SUM(CASE WHEN COALESCE(pv.status,'antrian')='error' THEN 1 ELSE 0 END) as error
                FROM video_items v
                JOIN projects p ON p.dataset_id = v.dataset_id
                JOIN project_videos pv ON pv.video_id = v.id AND pv.project_id = p.id
                WHERE p.id = ? AND COALESCE(pv.status,'antrian') != 'skip'
            """, (project_id,)).fetchone()
            return dict(row) if row else {}
        finally:
            conn.close()

    @staticmethod
    def bulk_insert(dataset_id: int, items: List[Dict]):
        conn = get_connection()
        try:
            conn.execute("DELETE FROM video_items WHERE dataset_id=?", (dataset_id,))
            for item in items:
                conn.execute("""
                    INSERT OR IGNORE INTO video_items
                    (dataset_id,no,caption_shopee,product_shopee,caption_tiktok,
                     link_tiktok,keranjang_tiktok,video_result,
                     rs_judul,rs_url,rs_deskripsi,rs_gambar,rs_sumber,
                     rs_file_lokal,rs_produk,rs_keranjang_kuning,rs_link_affiliate)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    dataset_id, item.get('no', 0),
                    item.get('caption_shopee', ''), item.get('product_shopee', ''),
                    item.get('caption_tiktok', ''), item.get('link_tiktok', ''),
                    item.get('keranjang_tiktok', ''), item.get('video_result', ''),
                    item.get('rs_judul', ''), item.get('rs_url', ''),
                    item.get('rs_deskripsi', ''), item.get('rs_gambar', ''),
                    item.get('rs_sumber', ''), item.get('rs_file_lokal', ''),
                    item.get('rs_produk', ''), item.get('rs_keranjang_kuning', ''),
                    item.get('rs_link_affiliate', ''),
                ))
            conn.commit()
        finally:
            conn.close()


# ═══════════════════════════════════════════════════
#  PROJECT REPO
# ═══════════════════════════════════════════════════
class ProjectRepo:

    @staticmethod
    def get_all() -> List[Dict]:
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT p.*, d.name as dataset_name,
                    (SELECT COUNT(*) FROM project_videos pv WHERE pv.project_id=p.id AND COALESCE(pv.status,'antrian')!='skip') as total,
                    (SELECT COUNT(*) FROM project_videos pv
                        WHERE pv.project_id=p.id AND COALESCE(pv.status,'antrian')!='skip'
                        AND (COALESCE(pv.status_shopee,'antrian')='selesai'
                             OR COALESCE(pv.status_tiktok,'antrian')='selesai')) as selesai,
                    (SELECT COUNT(*) FROM project_videos pv
                        WHERE pv.project_id=p.id AND COALESCE(pv.status,'antrian')!='skip'
                        AND COALESCE(pv.status,'antrian')='error') as error,
                    (SELECT COUNT(*) FROM project_videos pv
                        WHERE pv.project_id=p.id AND COALESCE(pv.status,'antrian')!='skip'
                        AND COALESCE(pv.status,'antrian')='antrian') as antrian
                FROM projects p
                LEFT JOIN datasets d ON d.id=p.dataset_id
                ORDER BY p.created_at DESC
            """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_by_id(project_id: int) -> Optional[Dict]:
        conn = get_connection()
        try:
            row = conn.execute("""
                SELECT p.*, d.name as dataset_name
                FROM projects p LEFT JOIN datasets d ON d.id=p.dataset_id
                WHERE p.id=?
            """, (project_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def create(name: str, description: str = '', dataset_id: int = None,
               device_serial: str = None, upload_target: str = 'shopee_tiktok',
               mode: str = 'generate_ai', rs_use_frame: str = 'on',
               rs_use_song: str = 'on', use_mix_sound: str = 'on',
               sched_enabled: str = 'off', sched_target: int = 10,
               shopee_username: str = '') -> int:
        conn = get_connection()
        try:
            cur = conn.execute(
                "INSERT INTO projects (name,description,dataset_id,device_serial,upload_target,mode,rs_use_frame,rs_use_song,use_mix_sound,sched_enabled,sched_target,shopee_username) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (name, description, dataset_id, device_serial or '', upload_target, mode, rs_use_frame, rs_use_song, use_mix_sound, sched_enabled, sched_target, shopee_username))
            project_id = cur.lastrowid
            conn.commit()
        finally:
            conn.close()
        if dataset_id:
            VideoRepo.init_project_videos(project_id, dataset_id)
        return project_id

    @staticmethod
    def update(project_id: int, name: str, description: str, dataset_id: int,
               status: str, device_serial: str = None, upload_target: str = 'shopee_tiktok',
               mode: str = 'generate_ai', rs_use_frame: str = 'on',
               rs_use_song: str = 'on', use_mix_sound: str = 'on',
               sched_enabled: str = 'off', sched_target: int = 10,
               shopee_username: str = ''):
        old = ProjectRepo.get_by_id(project_id)
        old_dataset = old.get('dataset_id') if old else None
        conn = get_connection()
        try:
            conn.execute("""
                UPDATE projects SET name=?,description=?,dataset_id=?,status=?,
                device_serial=?,upload_target=?,mode=?,rs_use_frame=?,rs_use_song=?,use_mix_sound=?,
                sched_enabled=?,sched_target=?,shopee_username=?,
                updated_at=datetime('now','localtime') WHERE id=?
            """, (name, description, dataset_id, status, device_serial or '', upload_target, mode, rs_use_frame, rs_use_song, use_mix_sound, sched_enabled, sched_target, shopee_username, project_id))
            conn.commit()
        finally:
            conn.close()
        if dataset_id and dataset_id != old_dataset:
            conn2 = get_connection()
            try:
                conn2.execute("DELETE FROM project_videos WHERE project_id=?", (project_id,))
                conn2.commit()
            finally:
                conn2.close()
            VideoRepo.init_project_videos(project_id, dataset_id)

    @staticmethod
    def update_sched(project_id: int, sched_enabled: str, sched_target: int):
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE projects SET sched_enabled=?,sched_target=?,updated_at=datetime('now','localtime') WHERE id=?",
                (sched_enabled, sched_target, project_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_sched_enabled() -> List[Dict]:
        """Return semua project dengan sched_enabled='on'."""
        conn = get_connection()
        try:
            rows = conn.execute(
                "SELECT * FROM projects WHERE sched_enabled='on'"
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def update_status(project_id: int, status: str):
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE projects SET status=?,updated_at=datetime('now','localtime') WHERE id=?",
                (status, project_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def delete(project_id: int):
        conn = get_connection()
        try:
            conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
            conn.commit()
        finally:
            conn.close()


# ═══════════════════════════════════════════════════
#  UPLOAD STATS REPO
# ═══════════════════════════════════════════════════
class UploadStatsRepo:

    @staticmethod
    def record(device: str, platform: str):
        """Catat 1 upload sukses."""
        conn = get_connection()
        try:
            conn.execute(
                "INSERT INTO upload_stats (device, platform) VALUES (?,?)",
                (device or "unknown", platform)
            )
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_daily(days: int = 30) -> List[Dict]:
        """
        Ambil ringkasan upload per hari per device.
        Return: [{date, device, shopee, tiktok, reupload, total}]
        """
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT
                    date(uploaded_at) as date,
                    device,
                    SUM(CASE WHEN platform='shopee'   THEN 1 ELSE 0 END) as shopee,
                    SUM(CASE WHEN platform='tiktok'   THEN 1 ELSE 0 END) as tiktok,
                    SUM(CASE WHEN platform='reupload' THEN 1 ELSE 0 END) as reupload,
                    COUNT(*) as total
                FROM upload_stats
                WHERE uploaded_at >= datetime('now','localtime', ? || ' days')
                GROUP BY date(uploaded_at), device
                ORDER BY date DESC, device ASC
            """, (f"-{days}",)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()


class SchedHistoryRepo:

    @staticmethod
    def record(trigger_type: str, project_ids: list) -> int:
        """Catat satu run scheduler. Return id."""
        conn = get_connection()
        try:
            cur = conn.execute(
                "INSERT INTO sched_history (trigger_type, projects_started, project_ids) VALUES (?,?,?)",
                (trigger_type, len(project_ids), ",".join(str(i) for i in project_ids))
            )
            row_id = cur.lastrowid
            conn.commit()
            return row_id
        finally:
            conn.close()

    @staticmethod
    def get_last_run_today() -> Optional[Dict]:
        """Cek apakah sudah ada auto-run hari ini."""
        conn = get_connection()
        try:
            row = conn.execute("""
                SELECT * FROM sched_history
                WHERE trigger_type='auto'
                  AND date(triggered_at)=date('now','localtime')
                ORDER BY id DESC LIMIT 1
            """).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def get_recent(limit: int = 20) -> List[Dict]:
        conn = get_connection()
        try:
            rows = conn.execute(
                "SELECT * FROM sched_history ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
