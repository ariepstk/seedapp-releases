"""
media_helper.py
Fungsi terpusat untuk: download, upscale, copy, push, cleanup HP.
Dipakai oleh runner.py — shopee_only dan tiktok_only tidak perlu download/push sendiri.
"""

import os
import time
import shutil
import random
import requests

DOWNLOAD_DIR_PC = "temp"
DOWNLOAD_DIR_HP = "/sdcard/DCIM/"


def ensure_dir():
    if not os.path.exists(DOWNLOAD_DIR_PC):
        os.makedirs(DOWNLOAD_DIR_PC)


def _download_gdrive(video_url: str, local_path: str, timeout: int = 120):
    """Download dari Google Drive via requests langsung — bypass gdown library
    yg suka error 'Cannot retrieve public link'. Handle confirm token utk file >100MB.
    """
    import re as _re
    match = _re.search(r"(?:id=|/d/)([a-zA-Z0-9_-]{25,})", video_url)
    if not match:
        raise Exception(f"Tidak bisa extract file ID dari URL: {video_url}")
    file_id = match.group(1)

    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    })

    base_url = "https://drive.usercontent.google.com/download"
    params = {"id": file_id, "export": "download", "confirm": "t"}

    response = session.get(base_url, params=params, stream=True, timeout=timeout, allow_redirects=True)

    # Confirm page handling (file besar)
    content_type = response.headers.get("content-type", "")
    if "text/html" in content_type.lower():
        html = response.text[:50000]
        m = _re.search(r'name="confirm"\s+value="([^"]+)"', html)
        if not m:
            m = _re.search(r'confirm=([0-9A-Za-z_-]+)', html)
        if m:
            params["confirm"] = m.group(1)
        else:
            for key, value in session.cookies.items():
                if key.startswith("download_warning"):
                    params["confirm"] = value
                    break
        m_uuid = _re.search(r'name="uuid"\s+value="([^"]+)"', html)
        if m_uuid:
            params["uuid"] = m_uuid.group(1)
        response = session.get(base_url, params=params, stream=True, timeout=timeout, allow_redirects=True)

    if response.status_code == 404:
        raise Exception(f"__EXPIRED__ 404 Client Error: Not Found for url: {video_url}")
    response.raise_for_status()

    # Cek lagi kalau masih HTML (private / quota)
    content_type = response.headers.get("content-type", "")
    if "text/html" in content_type.lower():
        snippet = response.text[:500]
        if "quota" in snippet.lower() or "exceeded" in snippet.lower():
            raise Exception("Google Drive quota exceeded — coba lagi 24 jam")
        if "permission" in snippet.lower() or "sign in" in snippet.lower():
            raise Exception("File belum public — set permission ke 'Anyone with the link'")
        raise Exception(f"Drive return HTML (bukan file). Snippet: {snippet[:200]}")

    with open(local_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=32768):
            if chunk:
                f.write(chunk)


def _download_from_url(video_url, local_path, log=None, max_attempt=10):
    """Download file dari GDrive atau URL biasa dengan retry."""
    for attempt in range(1, max_attempt + 1):
        try:
            if "drive.google.com" in video_url or "drive.usercontent.google.com" in video_url:
                _download_gdrive(video_url, local_path)
            else:
                r = requests.get(video_url, stream=True, timeout=60)
                if r.status_code == 404:
                    raise Exception(f"__EXPIRED__ 404 Client Error: Not Found for url: {video_url}")
                r.raise_for_status()
                with open(local_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk: f.write(chunk)

            size_mb = os.path.getsize(local_path) / (1024 * 1024)
            if size_mb < 0.5:
                raise Exception("File terlalu kecil, kemungkinan corrupt")
            return  # sukses

        except Exception as e:
            if attempt >= max_attempt:
                raise Exception(f"Download gagal setelah {max_attempt}x percobaan: {e}")
            delay_sec = random.randint(10, 15)
            if log: log(f"⚠ Download gagal (percobaan {attempt}/{max_attempt}), retry dalam {delay_sec}s... ({e})")
            time.sleep(delay_sec)


def prepare_files(video_url, item_id, log=None):
    """
    Siapkan {item_id}_shopee.mp4 dan {item_id}_tiktok.mp4 di PC.
    - Download sekali dari GDrive → {item_id}_shopee.mp4
    - Upscale (ganti file asli)
    - Copy → {item_id}_tiktok.mp4
    Jika file sudah ada dan valid (>0.5MB), skip step tersebut.
    Returns: (shopee_path, tiktok_path, shopee_filename, tiktok_filename)
    """
    ensure_dir()
    tiktok_filename = f"{item_id}_tiktok.mp4"
    shopee_filename = f"{item_id}_shopee.mp4"
    tiktok_path = os.path.join(DOWNLOAD_DIR_PC, tiktok_filename)
    shopee_path = os.path.join(DOWNLOAD_DIR_PC, shopee_filename)

    # Step 1: Download & proses tiktok jika belum ada atau invalid
    need_download = True
    if os.path.exists(tiktok_path):
        size_mb = os.path.getsize(tiktok_path) / (1024 * 1024)
        if size_mb >= 0.5:
            if log: log(f"📋 [{item_id}] Cache tiktok ada ({size_mb:.2f} MB), skip download")
            need_download = False

    if need_download:
        if log: log(f"⬇ [{item_id}] Download video dari GDrive...")
        _download_from_url(video_url, tiktok_path, log)
        size_mb = os.path.getsize(tiktok_path) / (1024 * 1024)
        if log: log(f"✅ Download selesai ({size_mb:.2f} MB)")

        # Upscale setelah download baru
        if log: log(f"⬆ [{item_id}] Upscale video...")
        from src.macro.shopee_only import upscale_if_needed
        upscale_if_needed(tiktok_path, log)
        size_mb = os.path.getsize(tiktok_path) / (1024 * 1024)
        if log: log(f"✅ Upscale selesai ({size_mb:.2f} MB)")

    # Step 2: Copy tiktok → shopee jika belum ada atau invalid
    need_copy = True
    if os.path.exists(shopee_path):
        size_mb = os.path.getsize(shopee_path) / (1024 * 1024)
        if size_mb >= 0.5:
            if log: log(f"📋 [{item_id}] Cache shopee ada ({size_mb:.2f} MB), skip copy")
            need_copy = False

    if need_copy:
        if log: log(f"📋 [{item_id}] Copy tiktok → shopee...")
        shutil.copy2(tiktok_path, shopee_path)

    return shopee_path, tiktok_path, shopee_filename, tiktok_filename


def push_and_wait(d, local_path, filename, log=None, timeout=20):
    """
    Push file ke HP lalu tunggu sampai media scanner confirm file muncul di gallery.
    timeout: max detik tunggu scanner (default 20s)
    """
    device_path = DOWNLOAD_DIR_HP + filename

    # Hapus file lama di HP dulu
    d.shell(f"rm -f {device_path}")
    time.sleep(0.5)

    # Push file
    d.push(local_path, device_path)

    # Verifikasi file ada di HP
    resp = d.shell(f"test -f {device_path} && echo OK || echo FAIL")
    if (resp.output or "").strip() != "OK":
        raise Exception(f"File tidak ditemukan di HP setelah push: {device_path}")

    # Broadcast media scanner + tunggu scan selesai
    d.shell(f'am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://{device_path}')
    time.sleep(3)
    if log: log(f"✅ Push selesai, media scanner done")


def cleanup_hp(d, item_id, upload_target, log=None):
    """Hapus file di HP sesuai upload_target. PC tidak dihapus."""
    try:
        if upload_target in ("shopee_tiktok", "shopee"):
            d.shell(f"rm -f {DOWNLOAD_DIR_HP}{item_id}_shopee.mp4")
            d.shell(f"rm -f {DOWNLOAD_DIR_HP}{item_id}_tiktok.mp4")
        elif upload_target == "tiktok_retry":
            d.shell(f"rm -f {DOWNLOAD_DIR_HP}{item_id}_tiktok.mp4")
        if log: log(f"🗑 Hapus HP: file [{item_id}] selesai")
    except Exception as e:
        if log: log(f"⚠ Gagal hapus HP: {e}")
