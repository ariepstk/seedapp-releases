"""
debug_logger.py
Log debug per hari ke file debug_YYYY-MM-DD.txt
Format: [HH:MM:SS] [HP XX] step | RAM: XMB | Threads: X
"""

import os
import threading
from datetime import datetime

_lock = threading.Lock()
LOG_DIR = os.path.join(os.path.dirname(__file__), '..', '..', '..')


def _get_log_path():
    os.makedirs(LOG_DIR, exist_ok=True)
    date_str = datetime.now().strftime('%Y-%m-%d')
    return os.path.join(LOG_DIR, f'debug_{date_str}.txt')


def _sys_info():
    # RAM — coba psutil dulu, fallback ke resource (unix) atau tasklist (windows)
    ram_mb = -1
    try:
        import psutil, os as _os
        proc = psutil.Process(_os.getpid())
        ram_mb = proc.memory_info().rss / (1024 * 1024)
    except:
        try:
            import os, subprocess, re
            pid = os.getpid()
            # Windows: tasklist CSV format
            # "python.exe","1234","Console","1","45,123 K"
            out = subprocess.check_output(
                f'tasklist /FI "PID eq {pid}" /FO CSV /NH',
                shell=True, timeout=2
            ).decode(errors='ignore')
            # Cari angka KB di kolom terakhir — misal: "45,123 K" atau "123,456 K"
            match = re.search(r'"([\d,]+)\s*K"', out)
            if match:
                kb = int(match.group(1).replace(',', ''))
                ram_mb = kb / 1024
        except:
            ram_mb = -1
    try:
        threads = threading.active_count()
    except:
        threads = -1
    return ram_mb, threads


def dlog(serial: str, step: str, extra: str = ""):
    """
    Tulis 1 baris ke debug log.
    serial: device serial (misal a0f34e8e) atau nama HP
    step  : nama step (misal 'TikTok — click_gallery')
    extra : info tambahan opsional
    """
    try:
        ram_mb, threads = _sys_info()
        ts = datetime.now().strftime('%H:%M:%S')
        hp = serial[:8] if serial else 'unknown'
        ram_str = f"{ram_mb:.0f}MB" if ram_mb >= 0 else "?MB"
        thr_str = str(threads) if threads >= 0 else "?"
        line = f"[{ts}] [{hp}] {step}"
        if extra:
            line += f" | {extra}"
        line += f" | RAM:{ram_str} | T:{thr_str}\n"
        with _lock:
            with open(_get_log_path(), 'a', encoding='utf-8') as f:
                f.write(line)
    except:
        pass  # debug logger tidak boleh crash app
