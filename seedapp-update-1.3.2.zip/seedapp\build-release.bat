@echo off
chcp 65001 >nul 2>&1
title SeedApp Build Release

:: Resolve path absolut
set SEEDAPPDIR=%~dp0
if "%SEEDAPPDIR:~-1%"=="\" set SEEDAPPDIR=%SEEDAPPDIR:~0,-1%

pushd "%SEEDAPPDIR%\.."
set UPDATEDIR=%CD%
popd

pushd "%SEEDAPPDIR%\..\.."
set INTERNALDIR=%CD%
popd

set OUTDIR=%INTERNALDIR%\releases

echo.
echo  ====================================
echo   SeedApp Build Release Tool
echo  ====================================
echo.
echo  Update dir : %UPDATEDIR%
echo  Output dir : %OUTDIR%
echo.
set /p VERSION=  Masukkan nomor versi (contoh: 1.0.3): 

if "%VERSION%"=="" (
    echo  [ERROR] Versi tidak boleh kosong.
    pause
    exit
)

set ZIPNAME=seedapp-update-%VERSION%.zip
if not exist "%OUTDIR%" mkdir "%OUTDIR%"
set OUTFILE=%OUTDIR%\%ZIPNAME%
if exist "%OUTFILE%" del "%OUTFILE%"

echo.
echo  [..] Membuat %ZIPNAME%...

powershell -NoProfile -Command ^
  "Compress-Archive -Path '%UPDATEDIR%\server.py','%UPDATEDIR%\src','%UPDATEDIR%\static','%UPDATEDIR%\seedapp' -DestinationPath '%OUTFILE%' -Force"

if not exist "%OUTFILE%" (
    echo  [ERROR] Gagal membuat zip. Cek path berikut:
    echo          %UPDATEDIR%
    pause
    exit
)

echo  [OK] %ZIPNAME% selesai!
echo.

(
echo {
echo   "version": "%VERSION%",
echo   "notes": "Update v%VERSION%",
echo   "zip_url": "https://github.com/ariepstk/seedapp-releases/releases/download/v%VERSION%/%ZIPNAME%"
echo }
) > "%OUTDIR%\version.json"

echo  [OK] version.json dibuat!
echo.
echo  File ada di:
echo  %OUTDIR%
echo.
echo  ====================================
echo   1. Upload %ZIPNAME% ke GitHub Release baru (tag: v%VERSION%)
echo   2. Upload version.json ke root repo (replace yg lama)
echo   3. Admin double-click update.bat
echo  ====================================
echo.
start "" "%OUTDIR%"
pause
