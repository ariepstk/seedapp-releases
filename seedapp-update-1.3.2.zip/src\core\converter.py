"""
converter.py
Pre-process semua video di dataset project:
  Download → Trim → Upscale → Mute → Frame → Mix song → Simpan lokal → Update DB

Dipanggil dari server.py via subprocess (mirip worker_process.py).
"""

import os
import sys
import json
import time
import random
import signal
import atexit
import platform

# Fix Windows encoding — stdout default cp1252 tidak support emoji
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Tambah ROOT ke path
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

from src.core.database import VideoRepo, ProjectRepo
from src.macro.reupload_shopee import (
    download_video, process_video, DOWNLOAD_DIR_PC
)


_stop_flag = False
_current_temp_files = []  # track file setengah jadi untuk cleanup saat stop


def _register_cleanup():
    """Hapus file setengah jadi saat proses di-terminate."""
    def _cleanup():
        for p in _current_temp_files:
            if p and os.path.exists(p):
                try: os.remove(p)
                except Exception: pass

    # atexit jalan di Windows maupun Linux saat proses berakhir normal/terminate
    atexit.register(_cleanup)

    # SIGTERM/SIGINT handler — efektif di Linux, di Windows proc.terminate() langsung kill
    if platform.system() != "Windows":
        def _handler(signum, frame):
            _cleanup()
            sys.exit(0)
        try:
            signal.signal(signal.SIGTERM, _handler)
            signal.signal(signal.SIGINT,  _handler)
        except Exception:
            pass


def _log(msg: str):
    entry = {"ts": __import__("datetime").datetime.now().strftime("%H:%M:%S"), "msg": msg}
    print(json.dumps(entry, ensure_ascii=False), flush=True)


def _is_valid_file(path: str) -> bool:
    """Cek file ada dan ukurannya >= 0.5MB."""
    if not path or not os.path.exists(path):
        return False
    return os.path.getsize(path) / (1024 * 1024) >= 0.5


def run_convert(project_id: int, folder_frame: str, folder_sound: str,
                use_frame: bool, use_song: bool, output_dir: str):
    global _stop_flag
    _stop_flag = False

    project = ProjectRepo.get_by_id(project_id)
    if not project:
        _log("❌ Project tidak ditemukan")
        return

    dataset_id = project.get("dataset_id")
    # Pakai get_by_project agar dapat status per item
    items = VideoRepo.get_by_project(project_id)
    if not items:
        _log("⚠ Tidak ada video di dataset")
        return

    total     = len(items)
    converted = sum(1 for i in items if _is_valid_file(i.get("rs_file_lokal", "")))
    belum     = total - converted

    _log(f"🎬 Convert dimulai — Total: {total} | ✅ Sudah: {converted} | ⏳ Belum: {belum}")

    done = 0
    skipped = 0
    failed = 0
    expired = 0

    # Hitung dulu berapa yang akan diconvert (exclude skip)
    to_convert = sum(
        1 for i in items
        if i.get("status_shopee", i.get("status", "antrian")) != "selesai"
        and not _is_valid_file(i.get("rs_file_lokal", ""))
        and i.get("rs_url", "").strip().startswith("http")
    )
    conv_idx = 0  # urutan item yang diconvert

    os.makedirs(output_dir, exist_ok=True)

    for item in items:
        if _stop_flag:
            _log("🛑 Convert dihentikan")
            break

        item_id   = item["id"]
        video_url = item.get("rs_url", "").strip()
        status    = item.get("status_shopee", item.get("status", "antrian"))

        # Skip jika status selesai
        if status == "selesai":
            skipped += 1
            continue

        # Skip jika sudah converted (rs_file_lokal valid)
        existing = item.get("rs_file_lokal", "")
        if _is_valid_file(existing):
            skipped += 1
            continue

        if not video_url or not video_url.startswith("http"):
            skipped += 1
            continue

        conv_idx += 1

        rand_id  = str(random.randint(10000, 99999))
        src_path = None

        # Track temp files untuk cleanup saat SIGTERM
        _current_temp_files.clear()
        _current_temp_files.append(os.path.join(DOWNLOAD_DIR_PC, f"rs_{rand_id}_src.mp4"))
        _current_temp_files.append(os.path.join(DOWNLOAD_DIR_PC, f"rs_{rand_id}.mp4"))

        try:
            # Step 1: Download
            src_path, size_mb = download_video(video_url, rand_id, _log)

            # Step 2: Process (trim, upscale, mute, frame, song)
            final_path, final_mb = process_video(
                src_path     = src_path,
                rand_id      = rand_id,
                folder_frame = folder_frame,
                folder_sound = folder_sound,
                use_frame    = use_frame,
                use_song     = use_song,
                log          = _log,
            )

            # Step 3: Pindah ke output_dir
            dest_filename = f"converted_{item_id}_{rand_id}.mp4"
            dest_path     = os.path.join(output_dir, dest_filename)
            import shutil
            shutil.move(final_path, dest_path)
            _current_temp_files.clear()  # sudah dipindah, tidak perlu cleanup

            # Step 4: Update DB
            VideoRepo.set_file_lokal(item_id, dest_path)
            done += 1
            _log(f"[{conv_idx}/{to_convert}] ✅ Convert selesai")

        except Exception as e:
            err_msg = str(e)

            # Hapus file setengah jadi
            for p in [src_path, os.path.join(DOWNLOAD_DIR_PC, f"rs_{rand_id}.mp4")]:
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            _current_temp_files.clear()

            if "__EXPIRED__" in err_msg:
                VideoRepo.delete_by_id(item_id, project_id)
                expired += 1
                _log(f"[{conv_idx}/{to_convert}] 🗑 Link expired — item dihapus")
            else:
                failed += 1
                _log(f"[{conv_idx}/{to_convert}] ❌ Gagal — {err_msg}")

    _log(f"━━━━━━━━━━ Ringkasan Convert ━━━━━━━━━━")
    parts = [f"✅ Berhasil: {done}"]
    if expired > 0:
        parts.append(f"🗑 Expired: {expired}")
    if failed > 0:
        parts.append(f"❌ Gagal: {failed}")
    _log(" | ".join(parts))
    _log("__CONVERT_DONE__")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--project_id",   type=int, required=True)
    parser.add_argument("--folder_frame", type=str, default="")
    parser.add_argument("--folder_sound", type=str, default="")
    parser.add_argument("--use_frame",    type=str, default="on")
    parser.add_argument("--use_song",     type=str, default="on")
    parser.add_argument("--output_dir",   type=str, default="converted")
    args = parser.parse_args()

    _register_cleanup()
    run_convert(
        project_id   = args.project_id,
        folder_frame = args.folder_frame,
        folder_sound = args.folder_sound,
        use_frame    = args.use_frame == "on",
        use_song     = args.use_song  == "on",
        output_dir   = args.output_dir,
    )
