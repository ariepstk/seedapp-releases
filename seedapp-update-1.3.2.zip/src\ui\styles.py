"""
Styles - SeedApp
Themes: Dark Navy + Purple | Light Warm Cream + Amber
"""

DARK = """
QMainWindow, QWidget { background-color: #1a1b2e; color: #e0e1f0; font-family: 'Segoe UI', Arial, sans-serif; font-size: 16px; }
#sidebar { background-color: #0f1022; border-right: none; }
#navBtn { background: transparent; color: #5a5c8a; border: none; text-align: left; padding: 0px 20px; font-size: 15px; border-radius: 0px; min-height: 44px; }
#navBtn:hover { background-color: #1e1f3a; color: #c0c1e0; }
#navBtn[active="true"] { background-color: #1e1f3a; color: #ffffff; font-weight: 600; border-left: 3px solid #00c48c; padding-left: 17px; min-height: 44px; }
#contentArea { background-color: #1a1b2e; }
#pageTitle { font-size: 22px; font-weight: bold; color: #ffffff; }
#pageHeader { background: #1a1b2e; border: none; }
#headerDivider { background: #252640; }
#pageSubtitle { font-size: 13px; color: #5a5c8a; }
#sectionTitle { font-size: 15px; font-weight: 700; color: #ffffff; background: transparent; }
#statStrip { background: #242538; border: 1px solid #2e2f50; border-radius: 10px; padding: 10px 16px; }
#statStripItem { background: transparent; }
#statStripLbl { font-size: 10px; color: #5a5c8a; letter-spacing: 0.8px; background: transparent; }
#statDivider { color: #2e2f50; background: transparent; }
#statCard { background: #242538; border: 1px solid #2e2f50; border-radius: 10px; padding: 14px 16px; min-width: 90px; }
#statValue { font-size: 26px; font-weight: bold; color: #ffffff; }
#statLabel { font-size: 11px; color: #5a5c8a; text-transform: uppercase; letter-spacing: 0.8px; }
#listItem { background: #1e1f36; border: 1px solid #2a2b48; border-radius: 10px; margin-bottom: 4px; }
#listItem:hover { border-color: #00c48c; background: #1e2040; }
#itemTitle { font-size: 15px; font-weight: 600; color: #ffffff; }
#itemDesc { font-size: 13px; color: #5a5c8a; }
#itemMeta { font-size: 12px; color: #5a5c8a; }
#statNum { font-size: 16px; font-weight: bold; color: #e0e1f0; }
#statNumError { font-size: 16px; font-weight: bold; color: #ff5555; }
#statNumSuccess { font-size: 16px; font-weight: bold; color: #00c48c; }
#btnPrimary { background: #00c48c; color: #ffffff; border: none; border-radius: 8px; padding: 9px 20px; font-weight: 700; font-size: 15px; }
#btnPrimary:hover { background: #00a876; }
#btnSuccess { background: #00c48c; color: #ffffff; border: none; border-radius: 8px; padding: 9px 20px; font-weight: 700; font-size: 15px; }
#btnSuccess:hover { background: #00a876; }
#btnDanger { background: #cc3344; color: #ffffff; border: none; border-radius: 8px; padding: 9px 20px; font-weight: 700; font-size: 15px; }
#btnDanger:hover { background: #aa2233; }
#btnSecondary { background-color: #242538; color: #8a8cb0; border: 1px solid #2e2f50; border-radius: 8px; padding: 5px 14px; font-size: 13px; }
#btnSecondary:hover { background-color: #2e2f50; color: #e0e1f0; }
#btnIcon { background: transparent; border: 1px solid #2e2f50; border-radius: 6px; padding: 4px 8px; color: #5a5c8a; font-size: 13px; }
#btnIcon:hover { background: #242538; color: #e0e1f0; }
#btnIconDanger { background: transparent; border: 1px solid #442030; border-radius: 6px; padding: 4px 8px; color: #ff5555; font-size: 13px; }
#btnIconDanger:hover { background: #331020; }
#badgeAntrian { background:#2a2510; color:#d4a020; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #4a3a10; }
#badgeBerjalan { background:#101a35; color:#4a9eff; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #1a3060; }
#badgeBerhenti { background:#2a1a10; color:#ff8844; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #4a2a10; }
#badgeSelesai { background:#0a2018; color:#00c48c; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #0f3025; }
#badgeError { background:#2a0f15; color:#ff5555; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #4a1520; }
#badgeProses { background:#1a1030; color:#9b7aff; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #2a1a50; }
QTableWidget { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; gridline-color: transparent; selection-background-color: #1e2040; selection-color: #e0e1f0; outline: none; color: #e0e1f0; font-size: 14px; alternate-background-color: #1e1f38; }
QTableWidget::item { padding: 8px 6px; border-bottom: 1px solid #2a2b44; color: #a0a1c0; }
QTableWidget::item:hover { background: #1e2040; color: #e0e1f0; }
QTableWidget::item:selected { background: #1e2040; color: #e0e1f0; }
QHeaderView::section { background: #1e1f38; color: #5a5c8a; padding: 10px 8px; border: none; border-bottom: 1px solid #2e2f50; font-weight: 700; font-size: 11px; letter-spacing: 0.8px; }
QTableWidget QTableCornerButton::section { background: #1e1f38; border: none; }
#searchInput { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 9px 14px; font-size: 15px; color: #e0e1f0; }
#searchInput:focus { border-color: #00c48c; }
QLineEdit, QSpinBox { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 8px 12px; color: #e0e1f0; font-size: 15px; } QSpinBox::up-button, QSpinBox::down-button { width: 0; border: none; }
QLineEdit:focus, QSpinBox:focus { border-color: #00c48c; }
QTextEdit { background: #0f1022; border: 1px solid #2e2f50; border-radius: 8px; padding: 8px; color: #e0e1f0; font-size: 14px; }
QComboBox { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 8px 14px; color: #e0e1f0; font-size: 15px; }
QComboBox:focus { border-color: #00c48c; }
QComboBox::drop-down { border: none; padding-right: 8px; }
QComboBox QAbstractItemView { background: #242538; border: 1px solid #2e2f50; selection-background-color: #1e2040; color: #e0e1f0; outline: none; font-size: 14px; }
QRadioButton { color: #c0c1e0; font-size: 14px; background: transparent; spacing: 8px; }
QRadioButton::indicator { width: 16px; height: 16px; border-radius: 8px; border: 2px solid #3a3b6a; background: #1a1b2e; }
QRadioButton::indicator:hover { border-color: #00c48c; }
QRadioButton::indicator:checked { border: 2px solid #00c48c; background: qradialgradient(cx:0.5,cy:0.5,radius:0.5,fx:0.5,fy:0.5, stop:0 #00c48c, stop:0.5 #00c48c, stop:0.6 #1a1b2e, stop:1 #1a1b2e); }
#filterTab { background: transparent; color: #5a5c8a; border: 1px solid #2e2f50; border-radius: 8px; padding: 6px 16px; font-size: 13px; }
#filterTab:hover { border-color: #00c48c; color: #00c48c; }
#filterTab[active="true"] { background: #0a2018; color: #00c48c; border-color: #00c48c; font-weight: 700; }
QScrollBar:vertical { background: #1a1b2e; width: 5px; border: none; }
QScrollBar::handle:vertical { background: #2e2f50; border-radius: 3px; min-height: 20px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #1a1b2e; height: 5px; border: none; }
QScrollBar::handle:horizontal { background: #2e2f50; border-radius: 3px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QDialog { background: #1a1b2e; color: #e0e1f0; }
QMessageBox { background: #1a1b2e; color: #e0e1f0; }
QMessageBox QLabel { color: #e0e1f0; }
QMenu { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 4px; color: #e0e1f0; font-size: 15px; }
QMenu::item { padding: 9px 18px; border-radius: 4px; color: #a0a1c0; }
QMenu::item:selected { background: #1e2040; color: #00c48c; }
QMenu::separator { height: 1px; background: #2e2f50; margin: 4px 8px; }
#logPanel { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; }
#dashCard { background: #242538; border: 1px solid #2e2f50; border-radius: 12px; }
#logText { background: #0f1022; border: none; color: #4cde7a; font-family: Consolas, 'Courier New', monospace; font-size: 13px; padding: 8px; }
#logTitle { font-size: 13px; font-weight: 700; color: #5a5c8a; padding: 6px 12px; background: #1a1b2e; border-bottom: 1px solid #2e2f50; border-top-left-radius: 8px; border-top-right-radius: 8px; letter-spacing: 0.5px; }
QProgressBar { background: #2e2f50; border: none; border-radius: 4px; height: 5px; }
QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #00c48c, stop:1 #00a876); border-radius: 4px; }
QSplitter::handle { background: #2e2f50; }
QSplitter::handle:vertical { height: 4px; }
QFrame[frameShape="4"], QFrame[frameShape="5"] { color: #2e2f50; }
QCheckBox { color: #c0c1e0; background: transparent; spacing: 6px; }
QCheckBox::indicator { width: 18px; height: 18px; border-radius: 4px; border: 2px solid #3a3b6a; background: #1a1b2e; }
QCheckBox::indicator:hover { border-color: #00c48c; }
QCheckBox::indicator:checked { background: #00c48c; border-color: #00c48c; }
"""

LIGHT = """
QMainWindow, QWidget { background-color: #f7f8fa; color: #1a2332; font-family: 'Segoe UI', Arial, sans-serif; font-size: 16px; }
#sidebar { background-color: #00c48c; border-right: none; }
#navBtn { background: transparent; color: rgba(255,255,255,0.75); border: none; text-align: left; padding: 0px 20px; font-size: 15px; border-radius: 0px; min-height: 44px; }
#navBtn:hover { background-color: #00b87d; color: #ffffff; }
#navBtn:hover { background-color: #1f4a33; color: #a0c8a8; }
#navBtn[active="true"] { background-color: #00a876; color: #ffffff; font-weight: 600; border-left: 3px solid #ffffff; padding-left: 17px; min-height: 44px; }
#contentArea { background-color: #f7f8fa; }
#pageTitle { font-size: 20px; font-weight: bold; color: #1a2332; }
#pageHeader { background: #ffffff; border: none; }
#headerDivider { background: #e0e6ed; }
#pageSubtitle { font-size: 13px; color: #8a9bb0; }
#sectionTitle { font-size: 15px; font-weight: 700; color: #1a2332; background: transparent; }
#statStrip { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 10px; padding: 10px 16px; }
#statStripItem { background: transparent; }
#statStripLbl { font-size: 11px; color: #8a9bb0; letter-spacing: 0.8px; background: transparent; }
#statDivider { color: #e0e6ed; background: transparent; }
#statCard { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 10px; padding: 14px 16px; min-width: 90px; }
#statValue { font-size: 26px; font-weight: bold; color: #1a2332; }
#statLabel { font-size: 11px; color: #8a9bb0; text-transform: uppercase; letter-spacing: 0.8px; }
#listItem { background: #ffffff; border: 1px solid #d0d7e2; border-radius: 10px; margin-bottom: 4px; }
#listItem:hover { border-color: #00c48c; background: #f7fffe; }
#itemTitle { font-size: 15px; font-weight: 600; color: #1a2332; }
#itemDesc { font-size: 13px; color: #8a9bb0; }
#itemMeta { font-size: 12px; color: #a0aab8; }
#statNum { font-size: 16px; font-weight: bold; color: #1a2332; }
#statNumError { font-size: 16px; font-weight: bold; color: #e53935; }
#statNumSuccess { font-size: 16px; font-weight: bold; color: #00c48c; }
#btnPrimary { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #00c48c, stop:1 #00a876); color: #ffffff; border: none; border-radius: 7px; padding: 9px 20px; font-weight: 700; font-size: 15px; }
#btnPrimary:hover { background: #00a876; }
#btnSuccess { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #00c48c, stop:1 #00a876); color: #ffffff; border: none; border-radius: 7px; padding: 9px 20px; font-weight: 700; font-size: 15px; }
#btnSuccess:hover { background: #00a876; }
#btnDanger { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #e53935, stop:1 #c62828); color: #ffffff; border: none; border-radius: 7px; padding: 9px 20px; font-weight: 700; font-size: 15px; }
#btnDanger:hover { background: #c62828; }
#btnSecondary { background-color: #f0f4f8; color: #4a6080; border: 1px solid #e0e6ed; border-radius: 7px; padding: 5px 14px; font-size: 13px; }
#btnSecondary:hover { background-color: #e4edf5; color: #1a2332; }
#btnIcon { background: transparent; border: 1px solid #e0e6ed; border-radius: 5px; padding: 4px 8px; color: #8a9bb0; font-size: 13px; }
#btnIcon:hover { background: #f0f4f8; color: #1a2332; }
#btnIconDanger { background: transparent; border: 1px solid #fde0e0; border-radius: 5px; padding: 4px 8px; color: #e53935; font-size: 13px; }
#btnIconDanger:hover { background: #fff0f0; }
#badgeAntrian { background:#fffbeb; color:#d97706; border-radius:5px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #fcd34d; }
#badgeBerjalan { background:#eff6ff; color:#2563eb; border-radius:5px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #93c5fd; }
#badgeBerhenti { background:#fff7ed; color:#ea580c; border-radius:5px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #fdba74; }
#badgeSelesai { background:#f0fdf4; color:#16a34a; border-radius:5px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #86efac; }
#badgeError { background:#fef2f2; color:#dc2626; border-radius:5px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #fca5a5; }
#badgeProses { background:#f5f3ff; color:#7c3aed; border-radius:5px; padding:3px 10px; font-size:12px; font-weight:700; border:1px solid #c4b5fd; }
QTableWidget { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 8px; gridline-color: transparent; selection-background-color: #f0fdf8; selection-color: #1a2332; outline: none; color: #1a2332; font-size: 14px; alternate-background-color: #f7f8fa; }
QTableWidget::item { padding: 8px 6px; border-bottom: 1px solid #f0f4f8; color: #4a6080; }
QTableWidget::item:hover { background: #f0f9f7; color: #1a2332; }
QTableWidget::item:selected { background: #e6f7f4; color: #1a2332; }
QHeaderView::section { background: #f7f8fa; color: #8a9bb0; padding: 10px 8px; border: none; border-bottom: 1px solid #e0e6ed; font-weight: 700; font-size: 11px; letter-spacing: 0.8px; text-transform: uppercase; }
QTableWidget QTableCornerButton::section { background: #f7f8fa; border: none; }
#searchInput { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 7px; padding: 9px 14px; font-size: 15px; color: #1a2332; }
#searchInput:focus { border-color: #00c48c; }
QLineEdit, QSpinBox { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 7px; padding: 8px 12px; color: #1a2332; font-size: 15px; } QSpinBox::up-button, QSpinBox::down-button { width: 0; border: none; }
QLineEdit:focus, QSpinBox:focus { border-color: #00c48c; }
QTextEdit { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 7px; padding: 8px; color: #1a2332; font-size: 14px; }
QComboBox { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 7px; padding: 8px 14px; color: #1a2332; font-size: 15px; }
QComboBox:focus { border-color: #00c48c; }
QComboBox::drop-down { border: none; padding-right: 8px; }
QComboBox QAbstractItemView { background: #ffffff; border: 1px solid #e0e6ed; selection-background-color: #f0fdf8; color: #1a2332; outline: none; font-size: 14px; }
QRadioButton { color: #1a2332; font-size: 14px; background: transparent; spacing: 8px; }
QRadioButton::indicator { width: 16px; height: 16px; border-radius: 8px; border: 2px solid #e0e6ed; background: #ffffff; }
QRadioButton::indicator:hover { border-color: #00c48c; }
QRadioButton::indicator:checked { border: 2px solid #00c48c; background: qradialgradient(cx:0.5,cy:0.5,radius:0.5,fx:0.5,fy:0.5, stop:0 #00c48c, stop:0.5 #00c48c, stop:0.6 #ffffff, stop:1 #ffffff); }
#filterTab { background: #ffffff; color: #8a9bb0; border: 1px solid #e0e6ed; border-radius: 7px; padding: 6px 14px; font-size: 13px; }
#filterTab:hover { border-color: #00c48c; color: #00a876; }
#filterTab[active="true"] { background: #f0fdf8; color: #00a876; border-color: #00c48c; font-weight: 700; }
QScrollBar:vertical { background: #f7f8fa; width: 6px; border: none; }
QScrollBar::handle:vertical { background: #e0e6ed; border-radius: 3px; min-height: 20px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #f7f8fa; height: 6px; border: none; }
QScrollBar::handle:horizontal { background: #e0e6ed; border-radius: 3px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QDialog { background: #f7f8fa; color: #1a2332; }
QMessageBox { background: #f7f8fa; color: #1a2332; }
QMessageBox QLabel { color: #1a2332; }
QMenu { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 8px; padding: 4px; color: #1a2332; font-size: 15px; }
QMenu::item { padding: 9px 18px; border-radius: 4px; color: #4a6080; }
QMenu::item:selected { background: #f0fdf8; color: #00a876; }
QMenu::separator { height: 1px; background: #e0e6ed; margin: 4px 8px; }
#logPanel { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 8px; }
#dashCard { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 12px; }
#logText { background: #ffffff; border: none; color: #1a4020; font-family: Consolas, 'Courier New', monospace; font-size: 13px; padding: 8px; }
#logTitle { font-size: 13px; font-weight: 700; color: #8a9bb0; padding: 6px 12px; background: #f7f8fa; border-bottom: 1px solid #e0e6ed; border-top-left-radius: 8px; border-top-right-radius: 8px; letter-spacing: 0.5px; }
QProgressBar { background: #f0f4f8; border: none; border-radius: 4px; height: 5px; }
QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #00c48c, stop:1 #00a876); border-radius: 4px; }
QSplitter::handle { background: #e0e6ed; }
QSplitter::handle:vertical { height: 4px; }
QFrame[frameShape="4"], QFrame[frameShape="5"] { color: #e0e6ed; }
QCheckBox { color: #1a2332; background: transparent; spacing: 6px; }
QCheckBox::indicator { width: 18px; height: 18px; border-radius: 4px; border: 2px solid #e0e6ed; background: #ffffff; }
QCheckBox::indicator:hover { border-color: #00c48c; }
QCheckBox::indicator:checked { background: #00c48c; border-color: #00c48c; }
"""

DIALOG_DARK = """
QDialog, QWidget { background: #1a1b2e; color: #e0e1f0; font-family: 'Segoe UI', Arial, sans-serif; font-size: 15px; }
QLabel { color: #8a8cb0; font-size: 13px; background: transparent; }
QLineEdit, QComboBox { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 9px 14px; color: #e0e1f0; font-size: 15px; }
QLineEdit:focus, QComboBox:focus { border-color: #00c48c; }
QComboBox QAbstractItemView { background: #242538; border: 1px solid #2e2f50; selection-background-color: #1e2040; color: #e0e1f0; font-size: 14px; }
QRadioButton { color: #c0c1e0; font-size: 14px; background: transparent; spacing: 8px; }
QFrame#radioFrame { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 4px; }
QRadioButton::indicator { width: 16px; height: 16px; border-radius: 8px; border: 2px solid #3a3b60; background: #1a1b2e; }
QRadioButton::indicator:hover { border-color: #00c48c; }
QRadioButton::indicator:checked { border: 2px solid #00c48c; background: qradialgradient(cx:0.5,cy:0.5,radius:0.5,fx:0.5,fy:0.5, stop:0 #00c48c, stop:0.5 #00c48c, stop:0.6 #1a1b2e, stop:1 #1a1b2e); }
QPushButton#btnPrimary { background: #00c48c; color: #fff; border: none; border-radius: 8px; padding: 9px 22px; font-weight: 700; font-size: 14px; }
QPushButton#btnPrimary:hover { background: #00a876; }
QPushButton#btnSecondary { background: #242538; color: #8a8cb0; border: 1px solid #2e2f50; border-radius: 8px; padding: 9px 22px; font-size: 14px; }
QPushButton#btnSecondary:hover { background: #2e2f50; color: #e0e1f0; }
QPushButton#btnDanger { background: #cc3344; color: #fff; border: none; border-radius: 8px; padding: 9px 22px; font-weight: 700; font-size: 14px; }
QPushButton#btnDanger:hover { background: #aa2233; }
QPushButton#btnSuccess { background: #00c48c; color: #fff; border: none; border-radius: 8px; padding: 9px 22px; font-weight: 700; font-size: 14px; }
QPushButton#btnSuccess:hover { background: #00a876; }
QPushButton#btnIcon { background: transparent; border: 1px solid #2e2f50; border-radius: 6px; padding: 4px 10px; color: #5a5c8a; font-size: 14px; }
QPushButton#btnIcon:hover { background: #242538; color: #e0e1f0; }
QSpinBox { background: #242538; border: 1px solid #2e2f50; border-radius: 8px; padding: 8px 12px; color: #e0e1f0; font-size: 15px; }
QSpinBox::up-button, QSpinBox::down-button { width: 0; border: none; }
QTextEdit { background: #0f1022; border: 1px solid #2e2f50; border-radius: 6px; color: #4cde7a; font-family: Consolas, monospace; font-size: 13px; padding: 8px; }
QProgressBar { background: #2e2f50; border: none; border-radius: 4px; height: 6px; }
QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #00c48c, stop:1 #00a876); border-radius: 4px; }
QScrollBar:vertical { background: #1a1b2e; width: 6px; border: none; }
QScrollBar::handle:vertical { background: #2e2f50; border-radius: 3px; min-height: 20px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
"""

DIALOG_LIGHT = """
QDialog, QWidget { background: #f7f8fa; color: #1a2332; font-family: 'Segoe UI', Arial, sans-serif; font-size: 15px; }
QLabel { color: #4a6080; font-size: 13px; background: transparent; }
QLineEdit, QComboBox { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 7px; padding: 9px 14px; color: #1a2332; font-size: 15px; }
QLineEdit:focus, QComboBox:focus { border-color: #00c48c; }
QComboBox QAbstractItemView { background: #ffffff; border: 1px solid #e0e6ed; selection-background-color: #f0fdf8; color: #1a2332; font-size: 14px; }
QRadioButton { color: #1a2332; font-size: 14px; background: transparent; spacing: 8px; }
QFrame#radioFrame { background: #f0f4f8; border: 1px solid #e0e6ed; border-radius: 7px; }
QRadioButton::indicator { width: 16px; height: 16px; border-radius: 8px; border: 2px solid #e0e6ed; background: #ffffff; }
QRadioButton::indicator:hover { border-color: #00c48c; }
QRadioButton::indicator:checked { border: 2px solid #00c48c; background: qradialgradient(cx:0.5,cy:0.5,radius:0.5,fx:0.5,fy:0.5, stop:0 #00c48c, stop:0.5 #00c48c, stop:0.6 #ffffff, stop:1 #ffffff); }
QPushButton#btnPrimary { background: #00c48c; color: #fff; border: none; border-radius: 7px; padding: 9px 22px; font-weight: 700; font-size: 14px; }
QPushButton#btnPrimary:hover { background: #00a876; }
QPushButton#btnSecondary { background: #f0f4f8; color: #4a6080; border: 1px solid #e0e6ed; border-radius: 7px; padding: 9px 22px; font-size: 14px; }
QPushButton#btnSecondary:hover { background: #e4edf5; color: #1a2332; }
QPushButton#btnDanger { background: #e53935; color: #fff; border: none; border-radius: 7px; padding: 9px 22px; font-weight: 700; font-size: 14px; }
QPushButton#btnDanger:hover { background: #c62828; }
QPushButton#btnSuccess { background: #00c48c; color: #fff; border: none; border-radius: 7px; padding: 9px 22px; font-weight: 700; font-size: 14px; }
QPushButton#btnSuccess:hover { background: #00a876; }
QPushButton#btnIcon { background: transparent; border: 1px solid #e0e6ed; border-radius: 5px; padding: 4px 10px; color: #8a9bb0; font-size: 14px; }
QPushButton#btnIcon:hover { background: #f0f4f8; color: #1a2332; }
QSpinBox { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 7px; padding: 8px 12px; color: #1a2332; font-size: 15px; }
QSpinBox::up-button, QSpinBox::down-button { width: 0; border: none; }
QTextEdit { background: #ffffff; border: 1px solid #e0e6ed; border-radius: 6px; color: #1a4020; font-family: Consolas, monospace; font-size: 13px; padding: 8px; }
QProgressBar { background: #f0f4f8; border: none; border-radius: 4px; height: 6px; }
QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #00c48c, stop:1 #00a876); border-radius: 4px; }
QScrollBar:vertical { background: #f7f8fa; width: 6px; border: none; }
QScrollBar::handle:vertical { background: #e0e6ed; border-radius: 3px; min-height: 20px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
"""

def get_stylesheet(theme: str = "dark") -> str:
    return DARK if theme == "dark" else LIGHT

def get_dialog_style(theme: str = "dark") -> str:
    return DIALOG_DARK if theme == "dark" else DIALOG_LIGHT

# Alias untuk backward compat
DIALOG_STYLE = DIALOG_DARK
