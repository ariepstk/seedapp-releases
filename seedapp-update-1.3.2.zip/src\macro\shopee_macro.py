"""
Shopee Macro - FULL FLOW + COVER + WA + CAPTION + PRODUCT + TAMBAH + SELESAI + POSTING
Dengan indikator sukses: "Berhasil diunggah!"
+ DOWNLOAD VIDEO sebelum buka Shopee
"""

import time
import random
import os
import requests
import uiautomator2 as u2
import numpy as np
import cv2

def type_text(d, text: str, chunk: int = 5):
    """Ketik teks per 5 karakter seperti manusia mengetik."""
    import random as _r
    text = str(text)
    for i in range(0, len(text), chunk):
        d.send_keys(text[i:i+chunk])
        time.sleep(_r.uniform(0.01, 0.03))



SHOPEE_PACKAGE = "com.shopee.id"
DOWNLOAD_DIR_PC = "temp"
DOWNLOAD_DIR_HP = "/sdcard/DCIM/"


# ===============================
# UTIL DELAY
# ===============================
def delay(log, seconds, label):
    if seconds <= 0:
        return
    for i in range(seconds, 0, -1):
        log(f"⏳ {label} {i}s...")
        time.sleep(1)


# ===============================
# DOWNLOAD VIDEO KE PC
# ===============================
def download_video(video_url, item_no, log):

    if not os.path.exists(DOWNLOAD_DIR_PC):
        os.makedirs(DOWNLOAD_DIR_PC)

    filename = f"{item_no}.mp4"
    local_path = os.path.join(DOWNLOAD_DIR_PC, filename)

    log(f"⬇ Download video_result → {filename}")

    r = requests.get(video_url, stream=True, timeout=60)
    r.raise_for_status()

    with open(local_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)

    size_mb = os.path.getsize(local_path) / (1024 * 1024)
    log(f"✅ Download selesai ({size_mb:.2f} MB)")

    if size_mb < 0.5:
        raise Exception("File terlalu kecil, kemungkinan corrupt")

    return local_path, filename


# ===============================
# PUSH VIDEO KE HP
# ===============================
def push_to_device(d, local_path, filename, log):

    device_path = DOWNLOAD_DIR_HP + filename

    log("📲 Push video ke HP (DCIM)...")

    d.push(local_path, device_path)

    resp = d.shell(
        f"test -f {device_path} && echo OK || echo FAIL"
    )
    check = (resp.output or "").strip()

    if check != "OK":
        raise Exception("File tidak ditemukan setelah push")

    log(f"✅ Video berhasil dikirim ke HP: {filename}")

    d.shell(
        f'am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://{device_path}'
    )

    time.sleep(2)
    log("✅ Video berhasil masuk Gallery")


# ===============================
# BASIC NAVIGATION
# ===============================
def click_live(d):
    if d(text="Live & Video").wait(timeout=5):
        d(text="Live & Video").click()
        return
    if d(textContains="Live").wait(timeout=5):
        d(textContains="Live").click()
        return
    raise Exception("Live & Video tidak ditemukan")


def click_upload(d):
    if d(descriptionContains="Upload").exists:
        d(descriptionContains="Upload").click()
        return
    w, h = d.window_size()
    d.click(int(w * 0.92), int(h * 0.08))


def click_gallery(d):
    if d(text="Galeri").wait(timeout=5):
        d(text="Galeri").click()
        return
    w, h = d.window_size()
    d.click(int(w * 0.85), int(h * 0.85))


def click_video_tab(d):
    if d(text="Video").wait(timeout=5):
        d(text="Video").click()
        return
    raise Exception("Tab Video tidak ditemukan")


def select_first_video(d):
    nodes = d.xpath("//*[contains(@text,'00:') or contains(@text,'01:') or contains(@text,'02:')]").all()
    if not nodes:
        raise Exception("Video tidak ditemukan")

    bounds = nodes[0].info.get("bounds")
    x = (bounds["left"] + bounds["right"]) // 2
    y = (bounds["top"] + bounds["bottom"]) // 2
    d.click(x, y)


def click_lanjutkan(d):
    if d(textContains="Lanjutkan").wait(timeout=5):
        d(textContains="Lanjutkan").click()
        return
    raise Exception("Lanjutkan tidak ditemukan")


# ===============================
# COVER
# ===============================
def click_pilih_cover(d):
    if d(text="Pilih Cover").wait(timeout=5):
        d(text="Pilih Cover").click()
        return
    raise Exception("Pilih Cover tidak ditemukan")


def click_random_frame(d):
    w, h = d.window_size()
    x = random.randint(int(w * 0.2), int(w * 0.8))
    y = int(h * 0.80)
    d.click(x, y)


def click_check(d):
    w, h = d.window_size()
    d.click(int(w * 0.92), int(h * 0.06))


# ===============================
# DISABLE WA (COLOR DETECTION)
# ===============================
def disable_share_whatsapp(d, log):

    log("🟢 Cek Share WhatsApp...")

    img = d.screenshot(format="opencv")
    h, w, _ = img.shape

    crop_top = int(h * 0.55)
    crop = img[crop_top:h, 0:w]

    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)

    lower_green = np.array([35, 80, 80])
    upper_green = np.array([85, 255, 255])

    mask = cv2.inRange(hsv, lower_green, upper_green)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if not contours:
        log("⚠ WA sudah nonaktif / tidak ditemukan")
        return

    largest = max(contours, key=cv2.contourArea)
    x, y, w_box, h_box = cv2.boundingRect(largest)

    cx = x + w_box // 2
    cy = crop_top + y + h_box // 2

    log(f"📍 Klik WA di {cx},{cy}")
    d.click(cx, cy)

    log("✅ WA dimatikan")


# ===============================
# CAPTION
# ===============================
def click_caption_field(d):
    if d(textContains="Tambah keterangan").wait(timeout=5):
        d(textContains="Tambah keterangan").click()
        return
    raise Exception("Field Tambah keterangan tidak ditemukan")


def input_caption_shopee(d, caption):
    try:
        d.clear_text()
    except:
        pass
    type_text(d, caption)


def click_ok(d):
    if d(text="OK").wait(timeout=5):
        d(text="OK").click()
        return
    raise Exception("Tombol OK tidak ditemukan")


# ===============================
# TAMBAH PRODUK
# ===============================
def click_tambah_produk(d):
    if d(textContains="tambah produk").wait(timeout=5):
        d(textContains="tambah produk").click()
        return
    raise Exception("Klik untuk tambah produk tidak ditemukan")


def click_semua_tab(d):
    if d(text="Semua").wait(timeout=5):
        d(text="Semua").click()
        return
    raise Exception("Tab Semua tidak ditemukan")


def click_cari_produk(d):
    if d(textContains="Cari Produk").wait(timeout=5):
        d(textContains="Cari Produk").click()
        return
    raise Exception("Field Cari Produk tidak ditemukan")


def input_product_shopee(d, product):
    try:
        d.clear_text()
    except:
        pass
    type_text(d, product)
    time.sleep(0.5)
    d.press("enter")


def click_tambah_pertama(d, log):
    w, h = d.window_size()
    buttons = d.xpath("//*[contains(@text,'Tambah')]").all()

    kandidat = []
    for btn in buttons:
        bounds = btn.info.get("bounds")
        if not bounds:
            continue
        cx = (bounds["left"] + bounds["right"]) // 2
        cy = (bounds["top"] + bounds["bottom"]) // 2
        if cx > w * 0.5:
            kandidat.append((cx, cy))

    if not kandidat:
        raise Exception("Tombol Tambah tidak ditemukan")

    kandidat.sort(key=lambda x: x[1])
    x, y = kandidat[0]
    log(f"📍 Klik Tambah di {x},{y}")
    d.click(x, y)


def click_selesai(d, log):
    w, h = d.window_size()
    buttons = d.xpath("//*[contains(@text,'Selesai')]").all()

    kandidat = []
    for btn in buttons:
        bounds = btn.info.get("bounds")
        if not bounds:
            continue
        cx = (bounds["left"] + bounds["right"]) // 2
        cy = (bounds["top"] + bounds["bottom"]) // 2
        if cy > h * 0.5:
            kandidat.append((cx, cy))

    if not kandidat:
        raise Exception("Tombol Selesai tidak ditemukan")

    kandidat.sort(key=lambda x: x[1], reverse=True)
    x, y = kandidat[0]
    log(f"📍 Klik Selesai di {x},{y}")
    d.click(x, y)


def click_posting(d):
    if d(text="Posting").wait(timeout=5):
        d(text="Posting").click()
    else:
        raise Exception("Tombol Posting tidak ditemukan")
    # Handle popup "Tetap posting" jika muncul
    time.sleep(2)
    if d(text="Tetap posting").exists:
        d(text="Tetap posting").click()


def wait_upload_success(d, log, timeout=60):
    log("⏳ Menunggu 'Berhasil diunggah!'...")
    start = time.time()
    while time.time() - start < timeout:
        if d(textContains="Berhasil diunggah").exists:
            log("✅ Upload berhasil terdeteksi")
            return True
        time.sleep(1)
    raise Exception("Upload gagal / indikator tidak muncul")


# ===============================
# STEP 1 - Klik Profil (Icon kiri atas)
# ===============================
def click_profile_icon(d):

    # biasanya icon profile berupa image button tanpa text
    if d(className="android.widget.ImageView").exists:
        # ambil image paling kiri atas
        w, h = d.window_size()
        d.click(int(w * 0.08), int(h * 0.08))
        return

    raise Exception("Icon Profil tidak ditemukan")


# ===============================
# STEP 2 - Klik Video Paling Atas
# ===============================
def click_top_video(d, log):

    log("🔎 Scan video paling atas...")

    # cari container grid video
    videos = d.xpath("//*[contains(@content-desc,'video')]").all()

    if videos:
        videos[0].click()
        return

    # fallback: klik area grid kiri atas
    w, h = d.window_size()
    x = int(w * 0.25)
    y = int(h * 0.35)

    d.click(x, y)


# ===============================
# MAIN FLOW
# ===============================
def run_upload_flow(
    serial,
    caption,
    product,
    video_url,
    item_id,
    log_fn=None
):

    def log(msg):
        if log_fn:
            log_fn(msg)

    try:
        log("🔌 Connect device...")
        d = u2.connect(serial) if serial else u2.connect()

        log(f"🆔 No Excel diterima: {item_id}")

        # DOWNLOAD SEBELUM BUKA SHOPEE
        local_path, filename = download_video(video_url, item_id, log)
        push_to_device(d, local_path, filename, log)

        d.app_stop(SHOPEE_PACKAGE)
        time.sleep(1)

        log("📱 Membuka Shopee...")
        d.app_start(SHOPEE_PACKAGE)
        delay(log, 10, "Load App")

        # === seluruh flow upload kamu tetap utuh di bawah ===
        click_live(d)
        delay(log, 5, "Load Live")

        click_upload(d)
        delay(log, 6, "Load Upload")

        click_gallery(d)
        delay(log, 3, "Load Galeri")

        click_video_tab(d)
        delay(log, 3, "Load Tab Video")

        select_first_video(d)
        delay(log, 3, "Select Video")

        click_lanjutkan(d)
        delay(log, 3, "Editor Page")

        click_lanjutkan(d)
        delay(log, 7, "Keterangan Page")

        click_pilih_cover(d)
        delay(log, 5, "Load Cover")

        click_random_frame(d)
        delay(log, 2, "Adjust Frame")

        click_check(d)
        delay(log, 3, "Return To Keterangan")

        disable_share_whatsapp(d, log)
        delay(log, 3, "After Disable WA")

        click_caption_field(d)
        delay(log, 2, "Focus Caption")

        input_caption_shopee(d, caption)
        delay(log, 2, "After Caption")

        click_ok(d)
        delay(log, 3, "After OK")

        click_tambah_produk(d)
        delay(log, 7, "Load Tambah Produk")

        click_semua_tab(d)
        delay(log, 3, "Load Semua Tab")

        click_cari_produk(d)
        delay(log, 3, "Focus Search")

        input_product_shopee(d, product)
        delay(log, 5, "After Enter")

        click_tambah_pertama(d, log)
        delay(log, 3, "After Tambah")

        click_selesai(d, log)
        delay(log, 5, "After Selesai")

        click_posting(d)

        wait_upload_success(d, log, timeout=60)

        click_profile_icon(d)
        delay(log, 7, "Load Profile")

        click_top_video(d, log)

        random_delay = random.randint(10, 20)
        delay(log, random_delay, "Watching Video")

        d.app_stop(SHOPEE_PACKAGE)
        delay(log, 3, "After Force Stop")

        log("🎉 Upload Shopee Selesai")
        return True

    except Exception as e:
        log(f"❌ Error: {e}")
        return False