"""
shopee_browser_resolver.py
Resolve URL video Shopee dgn HEADLESS BROWSER (Chrome via Playwright).

Kenapa: sejak Shopee pindah ke client-side rendering (web ver. 2026.06.v3),
HTML mentah halaman produk TIDAK lagi memuat video (video_info_list hilang) dan
API get_pc balas error anti-bot (90309999). Satu-satunya cara andal = buka
halaman pakai browser yang menjalankan JS, tunggu elemen <video> muncul, lalu
ambil .src-nya (link .mp4 down-*-id.vod.susercontent.com).

ROTASI MERATA (wajib): 1 profil Chrome per akun/cookie-set, dipilih bergiliran
LRU (pakai pick_cookie_set + cooldown dari shopee_resolver). Tidak ada 1 akun
yang dihajar terus → kurangi risiko block.

Thread-safety: Playwright SYNC harus jalan di 1 thread. Semua request resolve
(dari thread device manapun) dikirim ke 1 WORKER THREAD via antrian; worker
yang memegang Playwright + semua context. Aman dari ThreadPool runner.
"""
import os
import sys
import time
import queue
import tempfile
import subprocess
import threading

from src.macro import shopee_resolver as R

# ── Konfigurasi ──────────────────────────────────────────────────────
_HERE = os.path.dirname(__file__)
# PENTING: profil Chrome (user-data-dir) punya path super-dalam (Service Worker/
# CacheStorage) yg gampang lewat batas 260 char Windows. Kalau ditaruh di
# _internal/update/data, updater (copytree update→update_backup) GAGAL "filename too
# long". Maka simpan profil di LUAR folder app (LOCALAPPDATA) → updater tak menyentuhnya.
_APPDATA = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or tempfile.gettempdir()
PROFILES_DIR = os.path.join(_APPDATA, "SeedApp", "resolver_profiles")
_CONFIG_PATH = os.path.join(_HERE, "..", "..", "data", "resolver_config.json")
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_STEALTH = """
Object.defineProperty(navigator,'webdriver',{get:()=>undefined});
window.chrome = window.chrome || {runtime:{}};
Object.defineProperty(navigator,'languages',{get:()=>['id-ID','id','en-US','en']});
Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3,4,5]});
"""

_CHROME_CANDIDATES = [
    os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Google\Chrome\Application\chrome.exe"),
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]


def _chrome_path():
    for p in _CHROME_CANDIDATES:
        if p and os.path.isfile(p):
            return p
    return None


def _cfg(key, default):
    """Baca override dari data/resolver_config.json. Contoh isi:
    {"headless": false, "video_timeout": 2}
    - headless=false   → browser tampak (lebih lolos anti-bot, tapi muncul window)
    - video_timeout=N  → berapa detik nunggu <video> muncul utk produk tanpa video
                         (makin kecil makin cepat skip, tapi video yg lambat muat bisa ke-skip)"""
    try:
        import json
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            v = json.load(f).get(key)
            return v if v is not None else default
    except Exception:
        return default


def _headless():
    return bool(_cfg("headless", True))


def _video_timeout():
    try:
        return max(1.0, float(_cfg("video_timeout", 5)))
    except Exception:
        return 5.0


_pw_checked = False
_pw_ok = False


def ensure_playwright(log=None):
    """Pastikan modul playwright ada. Kalau belum → AUTO-INSTALL sekali (pip) supaya
    cukup copy kode ke PC manapun tanpa pip manual. Butuh internet. Return True/False."""
    global _pw_checked, _pw_ok
    if _pw_checked:
        return _pw_ok
    _pw_checked = True
    try:
        import playwright  # noqa: F401
        _pw_ok = True
        return True
    except Exception:
        pass
    if log:
        log("⚙ Playwright belum ada → install otomatis (sekali jalan, butuh internet)...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "playwright"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
        import importlib
        importlib.invalidate_caches()
        import playwright  # noqa: F401
        _pw_ok = True
        if log:
            log("✅ Playwright terpasang.")
    except Exception as e:
        _pw_ok = False
        if log:
            log(f"⚠ gagal auto-install Playwright: {e} — pakai metode HTML lama")
    return _pw_ok


def browser_available():
    """True kalau Chrome ada (Playwright di-auto-install oleh worker bila perlu)."""
    return _chrome_path() is not None


def _safe(s):
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in str(s))[:60] or "set"


# ── Worker thread (pemilik tunggal Playwright) ───────────────────────
_REQ_Q = queue.Queue()
_worker_started = False
_worker_lock = threading.Lock()


def _ensure_worker():
    global _worker_started
    with _worker_lock:
        if not _worker_started:
            threading.Thread(target=_worker_loop, daemon=True, name="ss-browser-resolver").start()
            _worker_started = True


def _worker_loop():
    pending = _REQ_Q.get()          # tunggu request pertama (dapat 'log' untuk auto-install)
    if pending is None:
        return
    if not ensure_playwright(pending[1]):
        # Playwright tak tersedia → balikan kosong untuk semua request (caller tak menggantung).
        item = pending
        while item is not None:
            item[2][0] = ""
            item[3].set()
            item = _REQ_Q.get()
        return
    from playwright.sync_api import sync_playwright
    contexts = {}   # account_key -> persistent context (dibuat sekali, dipakai ulang)
    with sync_playwright() as pw:
        item = pending
        while item is not None:
            product_url, log, box, done = item
            try:
                box[0] = _do_resolve(pw, contexts, product_url, log)
            except Exception as e:
                if log:
                    log(f"⚠ resolver browser error: {e}")
                box[0] = ""
            finally:
                done.set()
            item = _REQ_Q.get()


def _launch_ctx(pw, cookie_set):
    """Buka persistent context (1 profil per akun), seed cookies set ini."""
    key = R._set_key(cookie_set)
    profdir = os.path.join(PROFILES_DIR, _safe(key))
    os.makedirs(profdir, exist_ok=True)
    ctx = pw.chromium.launch_persistent_context(
        profdir,
        headless=_headless(),
        executable_path=_chrome_path(),
        user_agent=_UA,
        viewport={"width": 1280, "height": 900},
        args=["--disable-blink-features=AutomationControlled", "--no-first-run",
              "--no-default-browser-check"],
    )
    try:
        ctx.add_init_script(_STEALTH)
    except Exception:
        pass
    # Pakai cookies atribut LENGKAP (domain/secure/httpOnly/sameSite) kalau tersedia →
    # sesi login Shopee valid. Fallback ke jar {name:value} (domain .shopee.co.id) utk
    # set lama yg belum punya atribut lengkap.
    full = cookie_set.get("cookies")
    if isinstance(full, list) and full:
        cookies = full
    else:
        jar = cookie_set.get("jar", {}) or {}
        cookies = [{"name": k, "value": v, "domain": ".shopee.co.id", "path": "/"}
                   for k, v in jar.items()]
    try:
        ctx.add_cookies(cookies)
    except Exception:
        # kalau batch ditolak (atribut bentrok), coba satu-satu (lewati yg invalid)
        for ck in cookies:
            try:
                ctx.add_cookies([ck])
            except Exception:
                pass
    return ctx


def _do_resolve(pw, contexts, product_url, log, nav_timeout=20):
    ids = R.extract_ids(product_url)
    if not ids:
        return ""
    shop_id, item_id = ids
    url = f"https://shopee.co.id/product/{shop_id}/{item_id}"

    # Coba sampai SEMUA akun (rotasi merata). Kalau 1 akun ke-flag/belum-login → langsung
    # coba akun lain di produk yang SAMA (jangan skip produknya). Produk yang memang TANPA
    # video → langsung berhenti (tak perlu coba akun lain, hasilnya sama).
    n_acc = max(1, len(R.load_cookie_sets()))
    for _ in range(n_acc):
        cookie_set, key = R.pick_cookie_set()   # rotasi MERATA (skip akun cooldown)
        if not cookie_set:
            if log:
                log("⚠ resolver browser: belum ada cookies Shopee")
            return ""
        label = cookie_set.get("label", "akun")

        ctx = contexts.get(key)
        if ctx is None:
            ctx = _launch_ctx(pw, cookie_set)
            contexts[key] = ctx
        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        try:
            page.goto(url, wait_until="domcontentloaded", timeout=nav_timeout * 1000)
        except Exception as e:
            if log:
                log(f"🎬 resolver {item_id}: '{label}' gagal buka halaman ({e}) → coba akun lain")
            continue

        # Poll: berhenti SECEPATNYA begitu ketemu (a) <video> src → OK, atau
        # (b) halaman error/belum-login → blokir akun. Kalau tak keduanya sampai
        # video_timeout → produk memang tanpa video (gagal-login tak nunggu full).
        src = ""
        blocked = False
        deadline = time.time() + _video_timeout()
        while time.time() < deadline:
            try:
                st = page.evaluate("""()=>{
                    const v=document.querySelector('video');
                    return {src:(v?(v.src||v.currentSrc||''):''),
                            t:(document.body?document.body.innerText.slice(0,500):'')};
                }""")
            except Exception:
                st = {"src": "", "t": ""}
            src = st.get("src") or ""
            body = st.get("t") or ""
            if src.startswith("http"):
                break
            if ("Halaman Tidak Tersedia" in body or "telah terjadi kesalahan" in body
                    or "Silakan log" in body or "silakan login" in body.lower()):
                blocked = True
                break
            page.wait_for_timeout(300)

        if src.startswith("http"):
            if log:
                log(f"🎬 resolver {item_id}: OK (browser)")
            return src

        cur = page.url or ""
        if blocked or ("/verify/" in cur or "traffic/error" in cur
                       or "is_logged_in=false" in cur or "/buyer/login" in cur):
            R.mark_blocked(key)   # akun ini istirahat 15mnt
            if log:
                log(f"🎬 resolver {item_id}: '{label}' BELUM LOGIN / diblok (cookies basi/di-flag?) "
                    f"→ coba akun lain")
            continue              # coba akun berikutnya untuk produk yang sama

        # Login OK tapi produk memang tak ada video → tak perlu coba akun lain.
        if log:
            log(f"🎬 resolver {item_id}: tidak ada video di halaman")
        return ""

    # Semua akun gagal/ke-flag
    if log:
        log(f"🎬 resolver {item_id}: semua akun belum login/diblok → REFRESH cookies. Skip.")
    return ""


def resolve_via_browser(product_url, log=None, timeout=30):
    """API publik (thread-safe): kirim request ke worker, tunggu hasil. Return '' kalau gagal."""
    _ensure_worker()
    box = [""]
    done = threading.Event()
    _REQ_Q.put((product_url, log, box, done))
    # beri kelonggaran di atas timeout internal (launch context bisa makan waktu)
    done.wait(timeout + 40)
    return box[0]
