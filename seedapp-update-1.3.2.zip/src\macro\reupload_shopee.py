"""
reupload_shopee.py
Runner khusus Reupload Shopee — TERPISAH dari Generate AI runner.

Flow per video:
  1. Download video dari rs_url
  2. Proses: mute + frame border overlay + upscale 1080p + mix song (1 pipeline)
  3. Push ke HP
  4. Upload ke Shopee
     - Deskripsi : rs_judul
     - Import produk via link : rs_produk
  5. Tonton video (watch_min ~ watch_max detik)
  6. Cleanup HP

Nama file: rs_XXXXX.mp4 (5 digit random, 1 file final saja)
"""

import os
import time
import random
import subprocess
import requests

def type_text(d, text: str, chunk: int = 5):
    """Ketik teks per 5 karakter seperti manusia mengetik."""
    text = str(text)
    for i in range(0, len(text), chunk):
        d.send_keys(text[i:i+chunk])
        time.sleep(random.uniform(0.01, 0.03))



SHOPEE_PACKAGE  = "com.shopee.id"
DOWNLOAD_DIR_PC = "temp"
DOWNLOAD_DIR_HP = "/sdcard/DCIM/"

def _shopee_stop(d, clone=False):
    if clone:
        d.shell("am force-stop --user 999 com.shopee.id")
    else:
        d.app_stop(SHOPEE_PACKAGE)

def _shopee_start(d, clone=False):
    if clone:
        d.shell("am start --user 999 -n com.shopee.id/com.shopee.app.ui.home.HomeActivity_")
    else:
        d.app_start(SHOPEE_PACKAGE)


# ═══════════════════════════════════════════════════
#  UTIL
# ═══════════════════════════════════════════════════

def _rand_id() -> str:
    """5 digit random untuk nama file."""
    return str(random.randint(10000, 99999))


def delay(log, seconds, label=""):
    """Silent delay — tidak print countdown."""
    time.sleep(int(seconds))


def _ffmpeg(args: list, log, fast_mode: bool = False) -> bool:
    _threads = "2" if fast_mode else "1"
    cmd = ["ffmpeg", "-threads", _threads, "-y"] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            stderr = result.stderr
            if "No packets" in stderr or "Nothing was written" in stderr or "Generic error in an external library" in stderr:
                log(f"⚠ ffmpeg gagal: URL video expired atau tidak dapat diakses")
            else:
                err_lines = [l.strip() for l in stderr.splitlines() if any(k in l for k in ["Error", "error", "Invalid", "failed", "No such", "Conversion failed"])]
                err_short = err_lines[-1] if err_lines else "Unknown ffmpeg error"
                log(f"⚠ ffmpeg gagal: {err_short}")
            return False
        return True
    except subprocess.TimeoutExpired:
        log("❌ ffmpeg timeout!")
        return False
    except FileNotFoundError:
        log("❌ ffmpeg tidak ditemukan! Pastikan ffmpeg ada di PATH.")
        return False


def _pick_random_file(folder: str, ext: str) -> str:
    if not folder or not os.path.isdir(folder):
        return ""
    files = [f for f in os.listdir(folder) if f.lower().endswith(ext)]
    if not files:
        return ""
    return os.path.join(folder, random.choice(files))


# ═══════════════════════════════════════════════════
#  STEP 1: DOWNLOAD VIDEO
# ═══════════════════════════════════════════════════

def download_video(video_url: str, rand_id: str, log) -> tuple:
    os.makedirs(DOWNLOAD_DIR_PC, exist_ok=True)
    src_path = os.path.join(DOWNLOAD_DIR_PC, f"rs_{rand_id}_src.mp4")

    r = requests.get(video_url, stream=True, timeout=120)
    if r.status_code == 404:
        raise Exception(f"__EXPIRED__ 404 Client Error: Not Found for url: {video_url}")
    r.raise_for_status()
    with open(src_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)

    size_mb = os.path.getsize(src_path) / (1024 * 1024)
    if size_mb < 0.3:
        raise Exception("File terlalu kecil, kemungkinan corrupt atau URL salah")
    return src_path, size_mb


def _get_duration(path: str) -> float:
    """Ambil durasi video dalam detik via ffprobe. Return 0.0 jika gagal."""
    try:
        import json as _json
        result = subprocess.run([
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_entries", "format=duration", path
        ], capture_output=True, text=True, timeout=30)
        info = _json.loads(result.stdout)
        return float(info.get("format", {}).get("duration", 0))
    except Exception:
        return 0.0


def _random_trim(duration: float) -> tuple:
    """
    Hitung trim awal dan akhir (detik) secara random.
    Range: 0.0 – 0.5s per sisi, total max 1s.
    Return: (trim_start, trim_end) dalam float.
    """
    trim_start = round(random.uniform(0.0, 0.5), 2)
    trim_end   = round(random.uniform(0.0, 0.5), 2)
    return trim_start, trim_end


# ═══════════════════════════════════════════════════
#  STEP 2: PROSES VIDEO (1 pipeline → 1 file final)
# ═══════════════════════════════════════════════════

def process_video(src_path: str, rand_id: str, folder_frame: str,
                  folder_sound: str, use_frame: bool, use_song: bool, log,
                  fast_mode: bool = False) -> str:
    """
    Proses video dalam 1 pipeline ffmpeg:
      - Mute audio asli
      - Scale + pad ke 1080x1920
      - Overlay frame border PNG transparan (jika use_frame)
      - Mix lagu MP3 (jika use_song)
    Output: rs_XXXXX.mp4 (1 file final saja, src dihapus setelah selesai)
    """
    os.makedirs(DOWNLOAD_DIR_PC, exist_ok=True)
    final_path = os.path.join(DOWNLOAD_DIR_PC, f"rs_{rand_id}.mp4")

    frame_file = _pick_random_file(folder_frame, ".gif") if use_frame else ""
    song_file  = _pick_random_file(folder_sound, ".mp3") if use_song else ""

    if use_frame and not frame_file:
        pass
    if use_song and not song_file:
        pass

    # ── Trim random + strip metadata ──
    duration = _get_duration(src_path)
    trim_start, trim_end = _random_trim(duration) if duration > 5 else (0.0, 0.0)
    trim_duration = duration - trim_start - trim_end if duration > 0 else 0

    # Info trim + frame + song akan dilog ringkas dari luar

    # ── Build ffmpeg command dinamis ──
    # -ss trim_start SEBELUM -i agar fast seek
    inputs = []
    if trim_start > 0:
        inputs += ["-ss", str(trim_start)]
    inputs += ["-i", src_path]

    # Input tambahan
    frame_idx = None
    song_idx  = None

    if frame_file:
        pass  # frame info dilog dari caller
        # -stream_loop -1 agar GIF loop selamanya, -ignore_loop 0 override loop count di header GIF
        inputs += ["-stream_loop", "-1", "-ignore_loop", "0", "-i", frame_file]
        frame_idx = 1  # input index ke-1

    if song_file:
        pass  # song info dilog dari caller
        inputs += ["-i", song_file]
        song_idx = 2 if frame_file else 1  # index -i ke-N (GIF sudah pakai -i terpisah)

    # ── Filter complex ──
    filter_parts = []
    vid_stream   = "[0:v]"

    # Scale + pad
    filter_parts.append(
        f"{vid_stream}scale=1080:1920:force_original_aspect_ratio=decrease,"
        f"pad=1080:1920:(ow-iw)/2:(oh-ih)/2[scaled]"
    )
    vid_stream = "[scaled]"

    # Overlay frame GIF — loop GIF sesuai durasi video
    if frame_file and frame_idx is not None:
        filter_parts.append(
            f"[{frame_idx}:v]scale=1080:1920[frame];"
            f"{vid_stream}[frame]overlay=0:0:shortest=1[framed]"
        )
        vid_stream = "[framed]"

    # Audio mix
    audio_map  = []
    audio_args = []
    if song_file and song_idx is not None:
        filter_parts.append(
            f"[{song_idx}:a]aloop=loop=-1:size=2147483647,volume=1.0[song_out]"
        )
        audio_map  = ["-map", "[song_out]"]
        audio_args = ["-c:a", "aac", "-b:a", "128k", "-shortest"]
    # Tidak ada audio → -an

    filter_str = ";".join(filter_parts)

    maps = ["-map", vid_stream] + audio_map
    if not audio_map:
        maps += ["-an"]

    # Tambah -t (durasi output) jika ada trim
    duration_args = []
    if trim_duration > 0:
        duration_args = ["-t", str(round(trim_duration, 2))]

    cmd = (inputs +
           ["-filter_complex", filter_str] +
           maps +
           ["-c:v", "libx264", "-crf", "23", "-preset", "veryfast" if fast_mode else "fast",
            "-movflags", "+faststart",
            "-map_metadata", "-1"] +          # strip semua metadata lama
           audio_args +
           duration_args +
           [final_path])

    ok = _ffmpeg(cmd, log, fast_mode=fast_mode)

    # Cleanup src setelah proses
    try:
        os.remove(src_path)
    except Exception:
        pass

    if not ok:
        raise Exception("Gagal proses video (ffmpeg error)")

    size_mb = os.path.getsize(final_path) / (1024 * 1024)
    return final_path, size_mb


# ═══════════════════════════════════════════════════
#  STEP 3: PUSH KE HP
# ═══════════════════════════════════════════════════

def push_to_device(d, local_path: str, rand_id: str, log) -> str:
    filename    = f"rs_{rand_id}.mp4"
    device_path = DOWNLOAD_DIR_HP + filename

    d.push(local_path, device_path)

    resp  = d.shell(f"test -f {device_path} && echo OK || echo FAIL")
    check = (resp.output or "").strip()
    if check != "OK":
        raise Exception("File tidak ditemukan di HP setelah push")

    # Trigger media scanner agar video muncul di Gallery
    d.shell(
        f"am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE "
        f"-d file://{device_path}"
    )
    time.sleep(2)

    # Force scan ulang folder DCIM agar Gallery Shopee bisa detect
    d.shell("am broadcast -a android.intent.action.MEDIA_MOUNTED -d file:///sdcard")
    time.sleep(3)

    return device_path


# ═══════════════════════════════════════════════════
#  STEP 4: UPLOAD KE SHOPEE
# ═══════════════════════════════════════════════════

def _click_live(d):
    if d(text="Live & Video").wait(timeout=5):
        d(text="Live & Video").click(); return
    if d(textContains="Live").wait(timeout=5):
        d(textContains="Live").click(); return
    raise Exception("Live & Video tidak ditemukan")


def _click_upload(d):
    """Klik Upload 5x dengan jeda 0.1s untuk menyingkirkan popup yang mungkin muncul."""
    w, h = d.window_size()
    for _ in range(5):
        if d(descriptionContains="Upload").exists:
            d(descriptionContains="Upload").click()
        else:
            d.click(int(w * 0.92), int(h * 0.08))
        time.sleep(0.1)


def _click_gallery(d):
    if d(text="Galeri").wait(timeout=5):
        d(text="Galeri").click(); return
    w, h = d.window_size()
    d.click(int(w * 0.85), int(h * 0.85))


def _click_video_tab(d):
    if d(text="Video").wait(timeout=5):
        d(text="Video").click(); return
    raise Exception("Tab Video tidak ditemukan")


def _select_first_video(d):
    # Tunggu video muncul — coba beberapa XPath
    for attempt in range(3):
        # Coba cari thumbnail video (ada text durasi format MM:SS)
        nodes = d.xpath("//*[contains(@text,'00:') or contains(@text,'01:') or contains(@text,'02:')]").all()
        if nodes:
            bounds = nodes[0].info.get("bounds")
            x = (bounds["left"] + bounds["right"]) // 2
            y = (bounds["top"]  + bounds["bottom"]) // 2
            d.click(x, y)
            return
        time.sleep(2)

    # Fallback: klik area thumbnail video pertama (baris pertama, kolom pertama)
    w, h = d.window_size()
    # Grid gallery biasanya mulai ~15% dari atas, kolom pertama ~17% dari kiri
    d.click(int(w * 0.17), int(h * 0.20))


def _click_lanjutkan(d):
    if d(textContains="Lanjutkan").wait(timeout=5):
        d(textContains="Lanjutkan").click(); return
    raise Exception("Lanjutkan tidak ditemukan")


def _click_pilih_cover(d):
    if d(text="Pilih Cover").wait(timeout=5):
        d(text="Pilih Cover").click(); return
    raise Exception("Pilih Cover tidak ditemukan")


def _click_random_frame(d):
    w, h = d.window_size()
    x = random.randint(int(w * 0.2), int(w * 0.8))
    y = int(h * 0.80)
    d.click(x, y)


def _click_check(d):
    w, h = d.window_size()
    d.click(int(w * 0.92), int(h * 0.06))


def _disable_share_whatsapp(d, log):
    try:
        import numpy as np
        import cv2
        img = d.screenshot(format="opencv")
        if img is None:
            return
        h, w, _ = img.shape
        crop_top = int(h * 0.55)
        crop = img[crop_top:h, 0:w]
        hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array([35, 80, 80]), np.array([85, 255, 255]))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return  # WA share tidak ditemukan / sudah nonaktif, skip
        largest = max(contours, key=cv2.contourArea)
        x, y, w_box, h_box = cv2.boundingRect(largest)
        cx = x + w_box // 2
        cy = crop_top + y + h_box // 2
        d.click(cx, cy)
    except Exception:
        pass  # Optional step — skip jika gagal


def _input_caption(d, caption: str):
    if d(textContains="Tambah keterangan").wait(timeout=5):
        d(textContains="Tambah keterangan").click()
    else:
        raise Exception("Field Tambah keterangan tidak ditemukan")
    time.sleep(1)
    try:
        d.clear_text()
    except Exception:
        pass
    d.send_keys(caption)  # paste langsung, tidak pakai chunk


def click_tambah_pertama(d, log):
    w, h = d.window_size()
    buttons = d.xpath("//*[contains(@text,'Tambah')]").all()
    kandidat = [(  (b["left"]+b["right"])//2, (b["top"]+b["bottom"])//2  )
                for btn in buttons if (b := btn.info.get("bounds"))
                and (b["left"]+b["right"])//2 > w*0.5
                and (b["top"]+b["bottom"])//2 > h*0.2]
    if not kandidat:
        raise Exception("Tombol Tambah tidak ditemukan")
    x, y = sorted(kandidat, key=lambda c: c[1])[0]
    if log: log(f"📍 Klik Tambah di {x},{y}")
    d.click(x, y)


def _import_produk_via_link(d, product_link: str, log, step_fn=None, caption: str = "", raw_caption: str = ""):
    """
    Import produk via link URL Shopee.
    Flow:
      1. Klik icon tambah produk → delay 4s
      2. Klik tab Semua → delay 2s
      3. Klik icon Import Link → delay 4s
      4. Klik field input → paste link → Import → Pilih Semua → Tambah
         Jika Tambah tidak aktif, ulangi max 3x
      Fallback: Cari produk via nama jika icon tidak ada atau 3x gagal
    """

    # Matikan auto rotate sebelum import produk
    try:
        val = d.shell("settings get system accelerometer_rotation").output.strip()
        if val == '1':
            d.shell("settings put system accelerometer_rotation 0")
            d.shell("settings put system user_rotation 0")
    except Exception:
        pass

    # Step 1: Klik tambah produk
    if d(resourceId="com.shopee.id.dfpluginshopee16:id/iv_product_symbol").wait(timeout=7):
        d(resourceId="com.shopee.id.dfpluginshopee16:id/iv_product_symbol").click()
    elif d(textContains="tambah produk").wait(timeout=5):
        d(textContains="tambah produk").click()
    else:
        raise Exception("Klik untuk tambah produk tidak ditemukan")
    time.sleep(4)

    # Klik tab Semua — pastikan tidak di tab Favorit Saya
    if d(text="Semua").wait(timeout=5):
        d(text="Semua").click()
        time.sleep(2)

    # Step 2: Klik icon Import Link
    # description & resourceId kosong — klik via koordinat relatif (92.2%, 6.9%)
    # Verifikasi SETELAH klik: cek apakah halaman Import Link terbuka
    _icon_clicked = False
    try:
        _sw, _sh = d.window_size()
        d.click(int(_sw * 0.922), int(_sh * 0.069))
        time.sleep(2)
        # Halaman Import Link ditandai dengan teks "Hanya berlaku"
        if d(textContains="Hanya berlaku").wait(timeout=4):
            _icon_clicked = True
    except Exception:
        pass
    if _icon_clicked:
        time.sleep(2)

        # Step 3: Import link dengan retry max 3x
        def _try_import_link():
            # Klik field input
            if d(textContains="Hanya berlaku").wait(timeout=8):
                d(textContains="Hanya berlaku").click()
            elif d(className="android.widget.EditText").wait(timeout=5):
                d(className="android.widget.EditText").click()
            else:
                return False
            time.sleep(2)
            try: d.clear_text()
            except Exception: pass
            d.send_keys(product_link)
            time.sleep(2)
            # Klik Import
            if d(text="Import").wait(timeout=5):
                d(text="Import").click()
            else:
                return False
            time.sleep(3)
            # Klik Pilih Semua
            if d(text="Pilih Semua").wait(timeout=7):
                d(text="Pilih Semua").click()
            time.sleep(2)
            # Cek Tambah(N) aktif — ada angka berarti produk berhasil masuk
            try:
                for btn_text in [t for t in ["Tambah(1)","Tambah(2)","Tambah(3)"] if d(text=t).exists]:
                    if d(text=btn_text).info.get("enabled", False):
                        d(text=btn_text).click()
                        time.sleep(2)
                        return True
                if d(textContains="Tambah(").exists:
                    el = d(textContains="Tambah(")
                    if el.info.get("enabled", False):
                        el.click()
                        time.sleep(2)
                        return True
            except Exception:
                pass
            return False

        import_ok = False
        for attempt in range(3):
            if _try_import_link():
                import_ok = True
                break
            if attempt < 2:
                time.sleep(3)

        if import_ok:
            if step_fn: step_fn(4, f"🔗 Import link produk ✅ — {product_link[:50]}")
            return

        # Import link gagal 3x — back ke halaman Tambahkan Produk
        if log: log("⚠ Import link gagal 3x, fallback ke cari produk via nama...")
        if step_fn: step_fn(4, "🔍 Fallback — cari produk via nama...")
        if d(description="click to get back").wait(timeout=5):
            d(description="click to get back").click()
        else:
            d.press("back")
        time.sleep(2)
    else:
        # Icon tidak ada — langsung cari via nama
        if log: log("⚠ Icon Import Link tidak ada, cari produk via nama...")
        if step_fn: step_fn(4, "🔍 Cari produk via nama...")

    # Klik field Cari Produk
    if d(text="Cari Produk").wait(timeout=5):
        d(text="Cari Produk").click()
    elif d(className="android.widget.EditText", index=1).wait(timeout=3):
        d(className="android.widget.EditText", index=1).click()
    else:
        raise Exception("Field Cari Produk tidak ditemukan")
    time.sleep(2)

    # Paste nama produk + enter
    caption_short = (raw_caption[:50] if raw_caption else caption[:50] if caption else "produk")
    d.send_keys(caption_short)
    d.press("enter")
    time.sleep(5)

    # Klik tombol Tambah paling atas
    click_tambah_pertama(d, log)
    time.sleep(2)

    # Klik Selesai
    if d(text="Selesai").wait(timeout=5):
        d(text="Selesai").click()
    time.sleep(2)

    if step_fn: step_fn(4, "➕ Produk ditambah via cari...")


def _click_posting(d):
    if d(text="Posting").wait(timeout=5):
        d(text="Posting").click()
    else:
        raise Exception("Tombol Posting tidak ditemukan")
    # Loop cek popup "Tetap posting" ATAU notif upload selesai muncul duluan
    deadline = time.time() + 10
    while time.time() < deadline:
        if d(text="Tetap posting").exists:
            d(text="Tetap posting").click()
            break
        if d(text="Klik di sini untuk melihat videomu.").exists:
            break
        time.sleep(0.3)


def _wait_upload_success(d, log, timeout=600):
    """Tunggu popup upload (ViewGroup) muncul — max 10 menit."""
    _popup = d.xpath('//*[@resource-id="com.shopee.id:id/home_view"]//android.view.ViewGroup[@clickable="false"][@index="0"]')
    log("🔔 Menunggu popup upload muncul...")
    if not _popup.wait(timeout=timeout):
        raise Exception("Upload timeout — popup upload tidak muncul dalam 10 menit")
    log("✅ Popup upload muncul")
    return True


def _watch_and_close(d, watch_min: int, watch_max: int, log, shopee_clone: bool = False):
    w, h = d.window_size()
    d.click(int(w * 0.08), int(h * 0.08))
    time.sleep(5)
    videos = d.xpath("//*[contains(@content-desc,'video')]").all()
    if videos:
        videos[0].click()
    else:
        d.click(int(w * 0.25), int(h * 0.35))
    jeda = random.randint(watch_min, watch_max)
    log(f"👁 Menonton video {jeda}s...")
    time.sleep(jeda)
    _shopee_stop(d, shopee_clone)
    time.sleep(3)


# ═══════════════════════════════════════════════════
#  MAIN UPLOAD FLOW
# ═══════════════════════════════════════════════════

def run_upload_flow(d, caption: str, product_link: str, video_url: str,
                    item_id, log_fn=None, watch_min: int = 10,
                    watch_max: int = 20, serial: str = None,
                    folder_frame: str = "", folder_sound: str = "",
                    use_frame: bool = True, use_song: bool = True,
                    is_retry: bool = False, total_target: int = 1,
                    success_fn=None, raw_caption: str = "",
                    shopee_clone: bool = False,
                    fast_mode: bool = False) -> tuple:
    """
    Upload 1 video ke Shopee via Reupload flow.
    Return: (success: bool, error_msg: str, rand_id: str)
    """
    def log(msg):
        if log_fn: log_fn(msg)

    rand_id = _rand_id()
    _current_step = [0]  # list agar bisa dimodifikasi dari dalam closure

    def step(n, msg):
        _current_step[0] = n
        if n == 0:
            log(f"[0/10] {msg}")
        else:
            log(f"[{n}/10] {msg}")

    try:
        log(f"━━━━━━━━━━ Reupload Shopee ━━━━━━━━━━")

        # [0/10] Download → Proses → Push (1 baris log)
        if video_url.startswith("__LOCAL__"):
            # Sudah converted — pakai file lokal langsung
            final_path = video_url[len("__LOCAL__"):]
            push_to_device(d, final_path, rand_id, log)
            step(0, f"📦 Lokal → Push ✅ — {caption[:40]}")
            final_path = None  # jangan dihapus, file lokal milik user
        else:
            src_path, dl_mb = download_video(video_url, rand_id, log)
            final_path, proc_mb = process_video(
                src_path, rand_id,
                folder_frame=folder_frame,
                folder_sound=folder_sound,
                use_frame=use_frame,
                use_song=use_song,
                log=log,
                fast_mode=fast_mode,
            )
            push_to_device(d, final_path, rand_id, log)
            step(0, f"⬇ Download → Proses → Push ✅ — {caption[:40]}")

            # Cleanup PC setelah push
            try:
                if final_path: os.remove(final_path)
            except Exception:
                pass

        # [1/10] Buka Shopee
        step(1, "📱 Buka Shopee...")
        _shopee_stop(d, shopee_clone)
        time.sleep(1)
        _shopee_start(d, shopee_clone)
        d.set_orientation('natural')
        delay(log, 7, "Load App")

        _click_live(d)
        delay(log, 5, "Load Live")

        _click_upload(d)
        delay(log, 5, "Load Upload")

        # [2/10] Pilih video dari Gallery
        step(2, "🎞 Pilih video dari Gallery...")
        _click_gallery(d)
        delay(log, 2, "Load Galeri")
        _click_video_tab(d)
        delay(log, 2, "Load Tab Video")
        _select_first_video(d)
        delay(log, 2, "Select Video")

        # [3/10] Lanjutkan ke editor
        step(3, "✂ Lanjutkan ke editor...")
        _click_lanjutkan(d)
        delay(log, 2, "Editor Page")
        _click_lanjutkan(d)
        delay(log, 5, "Keterangan Page")

        # [4/10] Import produk
        if product_link and product_link.startswith("http"):
            step(4, "🛒 Import link produk...")
            _import_produk_via_link(d, product_link, log, step_fn=step, caption=caption, raw_caption=raw_caption)
        else:
            step(4, "⚠ rs_produk kosong / bukan URL, skip")

        # [5/10] Pilih cover
        step(5, "🖼 Pilih cover...")
        _click_pilih_cover(d)
        delay(log, 2, "Load Cover")
        _click_random_frame(d)
        delay(log, 2, "Adjust Frame")
        _click_check(d)
        delay(log, 2, "Return Keterangan")

        # [6/10] Nonaktifkan WA share (silent)
        step(6, "📵 Nonaktifkan WA share...")
        _disable_share_whatsapp(d, None)  # log=None agar tidak ada output
        delay(log, 1, "After Disable WA")

        # [7/10] Isi caption
        step(7, f"💬 Isi caption — {caption[:40]}")
        _input_caption(d, caption)
        time.sleep(2)  # tunggu teks ter-paste

        # Klik OK
        if d(resourceId="com.shopee.id.dfpluginshopee16:id/tv_right").wait(timeout=5):
            d(resourceId="com.shopee.id.dfpluginshopee16:id/tv_right").click()
        elif d(text="OK").wait(timeout=3):
            d(text="OK").click()
        time.sleep(2)  # tunggu halaman kembali ke keterangan

        # [8/10] Persiapan klik Posting
        step(8, "✅ Persiapan klik Posting...")
        _click_posting(d)

        # [9/10] Menunggu upload selesai
        step(9, "⏳ Menunggu upload selesai...")
        _wait_upload_success(d, log)

        # [10/10] Posting selesai
        step(10, "🚀 Posting Selesai ✅")

        # Callback sukses — dipanggil sebelum menonton
        if success_fn: success_fn()

        # Tonton & tutup (jembatan antar video)
        _actual_min = 60 if total_target <= 1 else watch_min
        _actual_max = 60 if total_target <= 1 else watch_max
        _watch_and_close(d, _actual_min, _actual_max, log, shopee_clone)

        return True, "", rand_id

    except Exception as e:
        log(f"❌ [{_current_step[0]}/10] Error: {e}")
        return False, str(e), rand_id


# ═══════════════════════════════════════════════════
#  CLEANUP HP
# ═══════════════════════════════════════════════════

def cleanup_hp_reupload(d, rand_id: str, log):
    """Hapus semua file rs_* dari HP setelah upload."""
    try:
        d.shell("find /sdcard/DCIM -maxdepth 2 -name 'rs_*.mp4' -delete")
        log(f"🗑 Cleanup HP: rs_{rand_id}.mp4")
    except Exception as e:
        log(f"⚠ Cleanup HP gagal: {e}")
