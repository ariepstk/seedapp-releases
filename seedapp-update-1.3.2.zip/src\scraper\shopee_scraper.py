"""
SeedApp Shopee Scraper
Scrape produk dari halaman kategori/search Shopee.
Menggunakan requests + BeautifulSoup.
Fallback ke window.__INITIAL_STATE__ jika DOM kosong.
"""

import re
import csv
import io
import json
import time
import random
import requests
from bs4 import BeautifulSoup
from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class ShopeeScraperState:
    status: str = "idle"       # idle | running | done | error
    progress: int = 0          # halaman ke-N
    total: int = 0             # total halaman
    results: List[Dict] = field(default_factory=list)
    error_msg: str = ""
    csv_data: str = ""


class ShopeeScraper:

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Referer": "https://shopee.co.id/",
    }

    # ── URL helpers ──────────────────────────────────────
    @staticmethod
    def _set_page_param(url: str, page: int) -> str:
        """Set/replace parameter page=X di URL."""
        if "page=" in url:
            return re.sub(r'page=\d+', f'page={page}', url)
        sep = "&" if "?" in url else "?"
        return f"{url}{sep}page={page}"

    # ── Extract dari HTML DOM ────────────────────────────
    def _extract_from_dom(self, soup: BeautifulSoup) -> List[Dict]:
        """Coba extract produk dari DOM elements."""
        results = []

        # Cari card produk — beberapa selector umum Shopee
        selectors = [
            'div[data-sqe="item"]',
            'li.shopee-search-item-result__item',
            'div.shop-search-result-view__item',
            'a[data-sqe="link"]',
        ]

        cards = []
        for sel in selectors:
            cards = soup.select(sel)
            if cards:
                break

        for card in cards:
            item = self._parse_card(card)
            if item:
                results.append(item)

        return results

    def _parse_card(self, card) -> Optional[Dict]:
        """Parse 1 card produk."""
        # Judul
        judul = ""
        for sel in ['div[data-sqe="name"]', '.line-clamp-2', '[class*="truncate"]']:
            el = card.select_one(sel)
            if el:
                judul = el.get_text(strip=True)
                break
        if not judul:
            # Fallback: cari elemen teks terpanjang dalam card
            texts = [(el.get_text(strip=True), el) for el in card.find_all(['div', 'span'])
                     if el.get_text(strip=True) and len(el.get_text(strip=True)) > 15]
            if texts:
                judul = max(texts, key=lambda x: len(x[0]))[0]

        # URL Produk
        url_produk = ""
        link = card.find('a', href=True)
        if not link and card.name == 'a':
            link = card
        if link:
            href = link.get('href', '')
            if href.startswith('/'):
                url_produk = f"https://shopee.co.id{href}"
            elif href.startswith('http'):
                url_produk = href

        # URL Video
        url_video = ""
        video_el = card.find('video')
        if video_el:
            url_video = video_el.get('src', '') or ''
            source = video_el.find('source')
            if source:
                url_video = source.get('src', '') or url_video
        if not url_video:
            # Cari di data attributes
            for el in card.find_all(attrs=True):
                for attr_val in el.attrs.values():
                    if isinstance(attr_val, str) and 'cvf.shopee.co.id' in attr_val:
                        url_video = attr_val
                        break
                if url_video:
                    break

        # URL Gambar
        url_gambar = ""
        img = card.find('img')
        if img:
            url_gambar = img.get('src', '') or img.get('data-src', '') or ''

        if not judul and not url_produk:
            return None

        return {
            "judul": judul,
            "url": url_video,
            "deskripsi": "",
            "gambar": url_gambar,
            "sumber": "shopee",
            "file_lokal": "",
            "produk": judul,
            "keranjang_kuning": url_produk,
            "link_affiliate": "",
        }

    # ── Extract dari __INITIAL_STATE__ ───────────────────
    def _extract_from_initial_state(self, html: str) -> List[Dict]:
        """Fallback: parse window.__INITIAL_STATE__ atau JSON embedded."""
        results = []

        # Cari pattern __INITIAL_STATE__
        patterns = [
            r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\})\s*;',
            r'window\.rawData\s*=\s*(\{.*?\})\s*;',
        ]

        for pat in patterns:
            m = re.search(pat, html, re.DOTALL)
            if m:
                try:
                    data = json.loads(m.group(1))
                    results = self._parse_initial_state(data)
                    if results:
                        return results
                except (json.JSONDecodeError, KeyError):
                    continue

        # Cari JSON array di script tags
        soup = BeautifulSoup(html, 'html.parser')
        for script in soup.find_all('script'):
            text = script.string or ''
            # Cari array items/products
            for key in ['items', 'products', 'item_cards', 'searchItems']:
                pat2 = rf'"{key}"\s*:\s*(\[.*?\])'
                m2 = re.search(pat2, text, re.DOTALL)
                if m2:
                    try:
                        items = json.loads(m2.group(1))
                        for item in items:
                            parsed = self._parse_json_item(item)
                            if parsed:
                                results.append(parsed)
                    except (json.JSONDecodeError, TypeError):
                        continue

        return results

    def _parse_initial_state(self, data: dict) -> List[Dict]:
        """Parse nested INITIAL_STATE object."""
        results = []

        # Cari nested items
        def _find_items(obj, depth=0):
            if depth > 5:
                return
            if isinstance(obj, list):
                for item in obj:
                    if isinstance(item, dict) and ('name' in item or 'title' in item):
                        parsed = self._parse_json_item(item)
                        if parsed:
                            results.append(parsed)
                    elif isinstance(item, (dict, list)):
                        _find_items(item, depth + 1)
            elif isinstance(obj, dict):
                for key, val in obj.items():
                    if key in ('items', 'products', 'item_cards', 'data', 'searchItems'):
                        _find_items(val, depth + 1)
                    elif isinstance(val, (dict, list)):
                        _find_items(val, depth + 1)

        _find_items(data)
        return results

    def _parse_json_item(self, item: dict) -> Optional[Dict]:
        """Parse 1 item dari JSON data."""
        if not isinstance(item, dict):
            return None

        judul = item.get('name') or item.get('title') or item.get('item_name') or ''
        if not judul:
            return None

        # Video URL
        url_video = ''
        video = item.get('video') or item.get('video_info') or {}
        if isinstance(video, dict):
            url_video = video.get('video_url') or video.get('url') or ''
        elif isinstance(video, str):
            url_video = video

        # Gambar
        url_gambar = ''
        images = item.get('images') or item.get('image') or []
        if isinstance(images, list) and images:
            img_id = images[0]
            if isinstance(img_id, str):
                if img_id.startswith('http'):
                    url_gambar = img_id
                else:
                    url_gambar = f"https://cf.shopee.co.id/file/{img_id}"
        elif isinstance(images, str):
            url_gambar = images if images.startswith('http') else f"https://cf.shopee.co.id/file/{images}"

        # URL Produk
        shop_id = item.get('shopid') or item.get('shop_id') or ''
        item_id = item.get('itemid') or item.get('item_id') or ''
        url_produk = ''
        if shop_id and item_id:
            slug = re.sub(r'[^a-zA-Z0-9]+', '-', judul[:80]).strip('-').lower()
            url_produk = f"https://shopee.co.id/{slug}-i.{shop_id}.{item_id}"

        return {
            "judul": judul,
            "url": url_video,
            "deskripsi": "",
            "gambar": url_gambar,
            "sumber": "shopee",
            "file_lokal": "",
            "produk": judul,
            "keranjang_kuning": url_produk,
            "link_affiliate": "",
        }

    # ── Main scrape ──────────────────────────────────────
    def scrape(self, url: str, total_pages: int, state: ShopeeScraperState) -> List[Dict]:
        """Scrape multi-page. Update state secara real-time."""
        state.status = "running"
        state.total = total_pages
        state.progress = 0
        state.results = []
        state.error_msg = ""
        state.csv_data = ""

        all_results = []
        seen_urls = set()

        for page_idx in range(total_pages):
            if state.status != "running":
                break  # stopped externally

            page_url = self._set_page_param(url, page_idx)
            state.progress = page_idx + 1

            try:
                resp = requests.get(page_url, headers=self.HEADERS, timeout=15)
                resp.raise_for_status()
                html = resp.text

                # Try DOM first
                soup = BeautifulSoup(html, 'html.parser')
                items = self._extract_from_dom(soup)

                # Fallback ke INITIAL_STATE jika DOM kosong
                if not items:
                    items = self._extract_from_initial_state(html)

                # Dedup by keranjang_kuning (URL produk)
                for item in items:
                    key = item.get('keranjang_kuning') or item.get('judul') or ''
                    if key and key not in seen_urls:
                        seen_urls.add(key)
                        all_results.append(item)

                state.results = all_results

            except Exception as e:
                # Skip page yang gagal, lanjut
                print(f"[scraper] Page {page_idx} error: {e}")
                continue

            # Delay random 1-2 detik antar page
            if page_idx < total_pages - 1:
                time.sleep(random.uniform(1.0, 2.0))

        state.results = all_results
        state.csv_data = self.generate_csv(all_results)
        state.status = "done"
        return all_results

    # ── CSV generator ────────────────────────────────────
    @staticmethod
    def generate_csv(results: List[Dict]) -> str:
        """Generate CSV string dari results."""
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "Judul", "Url", "Deskripsi", "Gambar", "Sumber",
            "File Lokal", "Produk", "Keranjang Kuning", "Link Affiliate"
        ])
        for r in results:
            writer.writerow([
                r.get("judul", ""),
                r.get("url", ""),
                r.get("deskripsi", ""),
                r.get("gambar", ""),
                r.get("sumber", "shopee"),
                r.get("file_lokal", ""),
                r.get("produk", ""),
                r.get("keranjang_kuning", ""),
                r.get("link_affiliate", ""),
            ])
        return output.getvalue()
