"""
Shopee Macro - shopee_only.py
Download video → Push ke HP → Upload Shopee
Cleanup dilakukan oleh runner setelah kedua flow selesai
"""

import time
import random
import os
import requests
import uiautomator2 as u2
import numpy as np
from src.core.debug_logger import dlog
import cv2

def type_text(d, text: str, chunk: int = 5):
    """Ketik teks per 5 karakter seperti manusia mengetik."""
    import random as _r
    text = str(text)
    for i in range(0, len(text), chunk):
        d.send_keys(text[i:i+chunk])
        time.sleep(_r.uniform(0.01, 0.03))



SHOPEE_PACKAGE  = "com.shopee.id"
DOWNLOAD_DIR_PC = "temp"
DOWNLOAD_DIR_HP = "/sdcard/DCIM/"


def delay(log, seconds, label):
    if seconds <= 0: return
    time.sleep(seconds)


def download_video(video_url, item_no, log=None, force_download=False):
    """
    Normal: pakai file yang sudah disiapkan tiktok_only.download_video().
    force_download=True (retry): download mandiri dari video_url.
    """
    if not os.path.exists(DOWNLOAD_DIR_PC):
        os.makedirs(DOWNLOAD_DIR_PC)
    filename   = f"{item_no}_shopee.mp4"
    local_path = os.path.join(DOWNLOAD_DIR_PC, filename)

    # Force download — hapus cache lama dulu
    if force_download:
        if os.path.exists(local_path):
            os.remove(local_path)
        tiktok_path = os.path.join(DOWNLOAD_DIR_PC, f"{item_no}_tiktok.mp4")
        if os.path.exists(tiktok_path):
            os.remove(tiktok_path)
    else:
        # Cek cache shopee
        if os.path.exists(local_path):
            size_mb = os.path.getsize(local_path) / (1024 * 1024)
            if size_mb >= 0.5:
                if log: log(f"📋 Cache shopee ada ({size_mb:.2f} MB), skip download")
                return local_path, filename
            else:
                if log: log(f"⚠ Cache shopee corrupt, hapus...")
                os.remove(local_path)

        # Fallback: copy dari tiktok kalau ada
        tiktok_path = os.path.join(DOWNLOAD_DIR_PC, f"{item_no}_tiktok.mp4")
        if os.path.exists(tiktok_path):
            size_mb = os.path.getsize(tiktok_path) / (1024 * 1024)
            if size_mb >= 0.5:
                import shutil
                if log: log(f"📋 Copy tiktok → shopee...")
                shutil.copy2(tiktok_path, local_path)
                return local_path, filename

        raise Exception(f"File shopee tidak ditemukan: {local_path}. Pastikan TikTok upload berjalan dulu.")

    # Download mandiri (force_download=True)
    max_attempt = 10
    for attempt in range(1, max_attempt + 1):
        try:
            if "drive.google.com" in video_url or "drive.usercontent.google.com" in video_url:
                from src.macro.media_helper import _download_gdrive
                _download_gdrive(video_url, local_path)
            else:
                r = requests.get(video_url, stream=True, timeout=60)
                r.raise_for_status()
                with open(local_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk: f.write(chunk)

            size_mb = os.path.getsize(local_path) / (1024 * 1024)
            if size_mb < 0.5:
                raise Exception("File terlalu kecil, kemungkinan corrupt")
            break
        except Exception as e:
            if attempt >= max_attempt:
                raise Exception(f"Download gagal setelah {max_attempt}x: {e}")
            delay_sec = 30
            if log: log(f"⚠ Download gagal, retry {delay_sec}s percobaan {attempt} ({e})")
            time.sleep(delay_sec)

    return local_path, filename


def upscale_if_needed(local_path, log=None, target_w=1080, target_h=1920, fast_mode=False):
    """
    Cek resolusi video. Jika lebih kecil dari target, upscale pakai ffmpeg.
    Ganti file asli dengan hasil upscale.
    fast_mode=True (Stealth): -threads 0, preset veryfast → 3-5x lebih cepat.
    """
    import subprocess
    import json as _json

    try:
        # Cek resolusi via ffprobe
        probe = subprocess.run([
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_streams", local_path
        ], capture_output=True, text=True, timeout=30)
        info = _json.loads(probe.stdout)
        video_stream = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), None)
        if not video_stream:
            return local_path

        w = int(video_stream.get("width", 0))
        h = int(video_stream.get("height", 0))

        # Skip jika sudah >= target
        if w >= target_w and h >= target_h:
            return local_path

        if log: log(f"⬆ Upscale {w}x{h} → {target_w}x{target_h}...")

        _threads = "2" if fast_mode else "1"
        _preset  = "veryfast" if fast_mode else "fast"
        out_path = local_path.replace(".mp4", "_up.mp4")
        cmd = [
            "ffmpeg", "-threads", _threads, "-i", local_path,
            "-vf", f"scale={target_w}:{target_h}:flags=lanczos,unsharp=5:5:1.0:5:5:0.0",
            "-c:v", "libx264", "-preset", _preset,
            "-b:v", "4500k", "-maxrate", "5000k", "-bufsize", "10000k",
            "-c:a", "copy", "-y", out_path
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=300)
        if result.returncode == 0 and os.path.exists(out_path):
            os.replace(out_path, local_path)  # Ganti file asli
        else:
            if log: log(f"⚠ Upscale gagal, pakai video asli")
    except Exception as e:
        if log: log(f"⚠ Upscale error: {e}")

    return local_path



def mix_sound(local_path, sounds_folder=None, log=None, fast_mode=False):
    """
    Mix lagu .mp3 random ke video. Audio asli di-mute, lagu di-loop/cut sesuai durasi video.
    fast_mode=True (Stealth): -threads 0 → lebih cepat.
    Returns: nama lagu yang dipakai, atau None jika skip.
    """
    import subprocess, json as _json, glob

    if not sounds_folder or not os.path.isdir(sounds_folder):
        return None

    mp3_files = glob.glob(os.path.join(sounds_folder, "*.mp3"))
    if not mp3_files:
        return None

    song_path = random.choice(mp3_files)
    song_name = os.path.basename(song_path)

    _threads = "2" if fast_mode else "1"
    try:
        out_path = local_path.replace(".mp4", "_sound.mp4")
        cmd = [
            "ffmpeg", "-threads", _threads, "-i", local_path, "-stream_loop", "-1", "-i", song_path,
            "-map", "0:v:0", "-map", "1:a:0",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
            "-shortest", "-y", out_path
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=300)
        if result.returncode == 0 and os.path.exists(out_path):
            os.replace(out_path, local_path)
            return song_name
        else:
            return None
    except Exception:
        return None

def push_to_device(d, local_path, filename, log=None):
    from src.macro.media_helper import push_and_wait
    # Hapus semua file mp4/mov di DCIM dulu — prevent video lama ikut ke gallery
    d.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mp4' -delete")
    d.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mov' -delete")
    time.sleep(1)
    push_and_wait(d, local_path, filename, log=log)


def click_live(d):
    if d(text="Live & Video").wait(timeout=5): d(text="Live & Video").click(); return
    if d(textContains="Live").wait(timeout=5): d(textContains="Live").click(); return
    raise Exception("Live & Video tidak ditemukan")

def click_upload(d):
    """Klik Upload 5x dengan jeda 0.1s untuk menyingkirkan popup yang mungkin muncul."""
    w, h = d.window_size()
    for _ in range(5):
        if d(descriptionContains="Upload").exists:
            d(descriptionContains="Upload").click()
        else:
            d.click(int(w * 0.92), int(h * 0.08))
        time.sleep(0.1)

def click_gallery(d, log=None):
    # Versi A — text "Galeri"
    if d(text="Galeri").wait(timeout=5):
        if log: log("📂 Klik Galeri (text)")
        d(text="Galeri").click(); return
    # Versi B — resource-id kpu (kanan bawah)
    el = d(resourceId="com.shopee.id:id/kpu")
    if el.exists:
        if log: log("📂 Klik Galeri (kpu)")
        el.click(); return
    # Versi C — resource-id ccp (kiri bawah)
    el = d(resourceId="com.shopee.id:id/ccp")
    if el.exists:
        if log: log("📂 Klik Galeri (ccp)")
        el.click(); return
    # Fallback koordinat
    w, h = d.window_size()
    if log: log(f"📂 Klik Galeri (koordinat fallback {int(w*0.85)},{int(h*0.85)})")
    d.click(int(w * 0.85), int(h * 0.85))

def click_video_tab(d):
    if d(text="Video").wait(timeout=5): d(text="Video").click(); return
    raise Exception("Tab Video tidak ditemukan")

def select_first_video(d):
    nodes = d.xpath("//*[contains(@text,'00:')]").all()
    if not nodes: raise Exception("Video tidak ditemukan")
    bounds = nodes[0].info.get("bounds")
    d.click((bounds["left"]+bounds["right"])//2, (bounds["top"]+bounds["bottom"])//2)

def click_lanjutkan(d):
    if d(textContains="Lanjutkan").wait(timeout=5): d(textContains="Lanjutkan").click(); return
    raise Exception("Lanjutkan tidak ditemukan")

def click_pilih_cover(d):
    if d(text="Pilih Cover").wait(timeout=5): d(text="Pilih Cover").click(); return
    raise Exception("Pilih Cover tidak ditemukan")

def click_random_frame(d):
    w, h = d.window_size()
    d.click(random.randint(int(w*0.2), int(w*0.8)), int(h*0.80))

def click_check(d):
    w, h = d.window_size(); d.click(int(w*0.92), int(h*0.06))

def disable_share_whatsapp(d, log=None):
    img = d.screenshot(format="opencv")
    h, w, _ = img.shape
    crop_top = int(h * 0.55)
    crop = img[crop_top:h, 0:w]
    hsv  = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, np.array([35,80,80]), np.array([85,255,255]))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours: return
    largest = max(contours, key=cv2.contourArea)
    x, y, w_box, h_box = cv2.boundingRect(largest)
    cx = x + w_box//2; cy = crop_top + y + h_box//2
    d.click(cx, cy)

def click_caption_field(d):
    if d(textContains="Tambah keterangan").wait(timeout=5): d(textContains="Tambah keterangan").click(); return
    raise Exception("Field Tambah keterangan tidak ditemukan")

def input_caption_shopee(d, caption):
    try: d.clear_text()
    except: pass
    type_text(d, caption)

def click_ok(d):
    if d(text="OK").wait(timeout=5): d(text="OK").click(); return
    raise Exception("Tombol OK tidak ditemukan")

def click_tambah_produk(d):
    if d(textContains="tambah produk").wait(timeout=5): d(textContains="tambah produk").click(); return
    raise Exception("Klik untuk tambah produk tidak ditemukan")

def click_semua_tab(d):
    if d(text="Semua").wait(timeout=5): d(text="Semua").click(); return
    raise Exception("Tab Semua tidak ditemukan")

def click_cari_produk(d):
    if d(textContains="Cari Produk").wait(timeout=5): d(textContains="Cari Produk").click(); return
    raise Exception("Field Cari Produk tidak ditemukan")

def input_product_shopee(d, product):
    try: d.clear_text()
    except: pass
    type_text(d, product); time.sleep(0.5); d.press("enter")

def click_tambah_pertama(d, log=None):
    w, h = d.window_size()
    buttons = d.xpath("//*[contains(@text,'Tambah')]").all()
    kandidat = [(  (b["left"]+b["right"])//2, (b["top"]+b["bottom"])//2  )
                for btn in buttons if (b := btn.info.get("bounds"))
                and (b["left"]+b["right"])//2 > w*0.5]
    if not kandidat: return False
    x, y = sorted(kandidat, key=lambda c: c[1])[0]
    d.click(x, y)
    return True

def _load_blacklist():
    """Baca blacklist_shopee.txt dari folder yang sama dengan file ini."""
    path = os.path.join(os.path.dirname(__file__), "blacklist_shopee.txt")
    if not os.path.exists(path):
        return []
    keywords = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                keywords.append(line.lower())
    return keywords


def strip_blacklist_prefix(product, log=None):
    """
    Strip prefix dalam kurung di awal nama produk jika isinya mengandung
    kata dari blacklist. Contoh:
      [GRATIS ONGKIR] Tas Wanita -> Tas Wanita
      [Layana] Gamis Anak        -> [Layana] Gamis Anak (tidak distrip)
    """
    import re
    blacklist = _load_blacklist()
    if not blacklist:
        return product

    pattern = re.compile(r'^[\[\{\【]([^\]\}\】]+)[\]\}\】]\s*')

    result = product
    while True:
        m = pattern.match(result)
        if not m:
            break
        inner = m.group(1).lower()
        if any(kw in inner for kw in blacklist):
            result = result[m.end():]
            if log: log(f"Strip prefix: \"{m.group(0).strip()}\"")
        else:
            break

    return result.strip()


def search_and_tambah_product(d, product, log=None):
    """
    Cari produk dan klik tombol Tambah dengan retry potong kata via backspace.
    - Ambil 8 kata pertama (buang simbol standalone seperti -, |, &)
    - Maksimal 8x percobaan
    - Minimal sisa 3 kata
    - Percobaan 1: ketik full → Enter
    - Percobaan 2+: backspace hapus kata terakhir → Enter (tanpa ketik ulang)
    - Jika semua percobaan gagal -> raise Exception
    """
    product = strip_blacklist_prefix(product, log)

    # Buang kata yang hanya simbol (-, |, &, --, dll) — pertahankan "7/8" dll
    words = [w for w in product.split() if any(c.isalnum() for c in w)]

    MAX_START  = 8   # ambil 8 kata pertama
    MAX_RETRY  = 8
    MIN_WORDS  = 3

    # Potong ke max 8 kata
    words = words[:MAX_START]

    percobaan  = 0

    for attempt in range(MAX_RETRY):
        current_count = len(words) - attempt
        if current_count < MIN_WORDS:
            break

        current_words = words[:current_count]
        current_query = " ".join(current_words)

        percobaan += 1

        if percobaan == 1:
            # Percobaan pertama: klik field + ketik full + Enter
            if log: log(f"Cari: \"{current_query}\"")
            d.xpath("//android.widget.EditText").get().click()
            time.sleep(0.5)
            input_product_shopee(d, current_query)
        else:
            # Percobaan 2+: klik ujung kanan field (dekat ✕) → cursor ke akhir → backspace → Enter
            kata_dihapus = words[current_count]  # kata yang mau dibuang
            hapus_len = len(kata_dihapus) + 1     # +1 untuk spasi sebelumnya
            if log: log(f"Cari ({percobaan}x): \"{current_query}\"")
            # Klik ujung kanan field search (dekat tombol ✕) — cursor otomatis ke akhir teks
            w, h = d.window_size()
            d.click(int(w * 0.865), int(h * 0.13))
            time.sleep(0.3)
            for _ in range(hapus_len):
                d.press("del")
                time.sleep(0.02)
            time.sleep(0.3)
            d.press("enter")

        time.sleep(5)  # tunggu live search loading

        if click_tambah_pertama(d, log):
            if log:
                if percobaan > 1:
                    log(f"Cari ({percobaan}x) → Tombol Tambah: \"{current_query}\" ✓")
                else:
                    log(f"Tombol Tambah: \"{current_query}\" ✓")
            return

    raise Exception(f"Tombol Tambah tidak ditemukan setelah {percobaan}x percobaan")

def click_selesai(d, log=None):
    w, h = d.window_size()
    buttons = d.xpath("//*[contains(@text,'Selesai')]").all()
    kandidat = [( (b["left"]+b["right"])//2, (b["top"]+b["bottom"])//2 )
                for btn in buttons if (b := btn.info.get("bounds"))
                and (b["top"]+b["bottom"])//2 > h*0.5]
    if not kandidat: raise Exception("Tombol Selesai tidak ditemukan")
    x, y = sorted(kandidat, key=lambda c: c[1], reverse=True)[0]
    d.click(x, y)

def click_posting(d):
    if d(text="Posting").wait(timeout=5): d(text="Posting").click()
    else: raise Exception("Tombol Posting tidak ditemukan")
    # Loop cek popup "Tetap posting" ATAU notif upload selesai muncul duluan
    import time as _t
    deadline = _t.time() + 10
    while _t.time() < deadline:
        if d(text="Tetap posting").exists:
            d(text="Tetap posting").click()
            break
        if d(text="Klik di sini untuk melihat videomu.").exists:
            break
        _t.sleep(0.3)

def wait_upload_success(d, log=None, timeout=600):
    """Tunggu popup upload (ViewGroup) muncul — max 10 menit."""
    _popup = d.xpath('//*[@resource-id="com.shopee.id:id/home_view"]//android.view.ViewGroup[@clickable="false"][@index="0"]')
    if log: log("🔔 Menunggu popup upload muncul...")
    if not _popup.wait(timeout=timeout):
        raise Exception("Upload timeout — popup upload tidak muncul dalam 10 menit")
    if log: log("✅ Popup upload muncul")
    return True

def click_profile_icon(d):
    w, h = d.window_size(); d.click(int(w*0.08), int(h*0.08))

def click_top_video(d, log=None):
    videos = d.xpath("//*[contains(@content-desc,'video')]").all()
    if videos: videos[0].click(); return
    w, h = d.window_size(); d.click(int(w*0.25), int(h*0.35))



def _shopee_stop(d, clone=False):
    if clone:
        d.shell("am force-stop --user 999 com.shopee.id")
    else:
        d.app_stop(SHOPEE_PACKAGE)

def _shopee_start(d, clone=False):
    if clone:
        d.shell("am start --user 999 -n com.shopee.id/com.shopee.app.ui.home.HomeActivity_")
    else:
        d.app_start(SHOPEE_PACKAGE)


def switch_shopee_account(d, target_username, log=None, shopee_clone=False):
    """
    Switch akun Shopee ke target_username.
    Flow: Buka Shopee → Saya → cek labelUserName
      - Cocok   → return True langsung (run_upload_flow handle force stop + reopen)
      - Beda    → Settings → Ganti Akun → switch → return True
    Returns True jika berhasil / sudah aktif, False jika gagal.
    """
    if not target_username:
        return False

    target_username = target_username.strip().lower()

    try:
        if log: log(f"🔄 Switch akun → {target_username}")

        # 1. Force stop & buka Shopee fresh
        _shopee_stop(d, shopee_clone)
        time.sleep(1)
        _shopee_start(d, shopee_clone)
        d.set_orientation('natural')
        time.sleep(5)

        # 2. Tap tab "Saya"
        saya = d(description="tab_bar_button_me")
        if saya.wait(timeout=5):
            saya.click()
        else:
            w, h = d.window_size()
            d.click(int(w * 0.875), int(h * 0.97))
        time.sleep(3)

        # 3. Cek username aktif via labelUserName — early exit jika sudah benar
        label_user = d(resourceId="labelUserName")
        if label_user.wait(timeout=3):
            current_user = (label_user.get_text() or "").strip().lower()
            if log: log(f"👤 Akun aktif: {current_user}")
            if current_user == target_username:
                if log: log(f"✅ Sudah di akun {target_username}, skip switch")
                return True  # Shopee tetap terbuka
        else:
            if log: log(f"⚠ labelUserName tidak ditemukan, lanjut switch...")

        # 4. Tap Settings (gear icon)
        settings_btn = d(resourceId="com.shopee.id:id/buttonAccountSettings")
        if settings_btn.wait(timeout=2):
            settings_btn.click()
        else:
            w, h = d.window_size()
            d.click(int(w * 0.67), int(h * 0.08))
        time.sleep(2)

        # 5. Scroll down
        w, h = d.window_size()
        d.swipe(int(w * 0.5), int(h * 0.8), int(w * 0.5), int(h * 0.3), duration=0.3)
        time.sleep(1)

        # 6. Tap "Ganti Akun / Keluar"
        btn_switch = d(resourceId="com.shopee.id:id/btnSwitchAccount")
        if btn_switch.wait(timeout=2):
            btn_switch.click()
        else:
            btn_text = d(textContains="Ganti Akun")
            if btn_text.wait(timeout=2):
                btn_text.click()
            else:
                if log: log(f"❌ Tombol Ganti Akun tidak ditemukan")
                return False
        time.sleep(2)

        # 7. Cari target di account list dan klik
        containers = d(resourceId="com.shopee.id:id/container_layout")
        found = False
        for i in range(containers.count):
            try:
                container = containers[i]
                name_el = container.child(resourceId="com.shopee.id:id/tv_name")
                if not name_el.exists:
                    continue
                name_text = (name_el.get_text() or "").strip().lower()
                if name_text == target_username:
                    # Sudah "Akun Saat Ini"?
                    current_el = container.child(resourceId="com.shopee.id:id/tv_current")
                    if current_el.exists:
                        if log: log(f"✅ Akun sudah aktif: {target_username}")
                        # Back ke Home
                        d.press("back"); time.sleep(1)
                        d.press("back"); time.sleep(1)
                        d.press("back"); time.sleep(1)
                        return True
                    container.click()
                    found = True
                    if log: log(f"🔄 Klik akun {target_username}...")
                    break
            except:
                continue

        if not found:
            if log: log(f"❌ Akun {target_username} tidak ditemukan di daftar")
            return False

        # 8. Tunggu switch selesai — Shopee auto redirect ke Home
        time.sleep(3)

        # 9. Verifikasi via labelUserName
        saya = d(description="tab_bar_button_me")
        if saya.wait(timeout=2):
            saya.click()
        else:
            w, h = d.window_size()
            d.click(int(w * 0.875), int(h * 0.97))
        time.sleep(2)

        label_user = d(resourceId="labelUserName")
        if label_user.wait(timeout=2):
            final_user = (label_user.get_text() or "").strip().lower()
            if final_user == target_username:
                if log: log(f"✅ Switch berhasil → {target_username}")
                return True  # Shopee tetap terbuka
            else:
                if log: log(f"❌ Switch gagal — masih di akun: {final_user}")
                return False

        if log: log(f"⚠ Switch mungkin berhasil tapi verifikasi gagal")
        return True  # Shopee tetap terbuka

    except Exception as e:
        if log: log(f"❌ Switch akun gagal: {e}")
        return False


def force_restart_shopee(d, log=None, shopee_clone=False):
    """Force-stop Shopee, tunggu 10s, buka ulang dari awal."""
    if log: log("🛍 Shopee — ⚠ Force close & restart...")
    _shopee_stop(d, shopee_clone)
    time.sleep(10)
    _shopee_start(d, shopee_clone)
    d.set_orientation('natural')
    time.sleep(7)
    if log: log("🛍 Shopee — ▶ Buka ulang selesai, lanjut flow...")


# ===============================
# MAIN ENTRY
# ===============================
def run_upload_flow(d, caption, product, video_url, item_id, log_fn=None, watch_min=10, watch_max=20, serial=None, is_retry=False, folder_sound=None, shopee_clone=False, use_mix_sound=True, pre_watch_fn=None, fast_mode=False):

    def log(msg):
        if log_fn: log_fn(msg)

    def slog(msg):
        """Sub-log: pakai prefix step aktif"""
        if log_fn: log_fn(f"[{_step:02d}/10] {msg}")

    _step = 0
    def step(n, msg):
        nonlocal _step
        _step = n
        log(f"[{n:02d}/10] {msg}")

    _error_msg = ""
    try:
        log(f"━━━━━━━━━━ Shopee ━━━━━━━━━━")
        dlog(serial or "", f"Shopee [{item_id}] — START {product[:30]}")
        log(f"[00/10] [{item_id}] {product}")

        # [01/10] Push video ke HP
        local_path, filename = download_video(video_url, item_id, slog, force_download=is_retry)

        if is_retry:
            # Retry: proses mandiri — upscale + mix sound
            _did_upscale = False
            try:
                import subprocess as _sp, json as _j
                _probe = _sp.run(["ffprobe","-v","quiet","-print_format","json","-show_streams",local_path],
                                  capture_output=True, text=True, timeout=30)
                _info = _j.loads(_probe.stdout)
                _vs = next((s for s in _info.get("streams",[]) if s.get("codec_type")=="video"), None)
                if _vs:
                    _w, _h = int(_vs.get("width",0)), int(_vs.get("height",0))
                    if _w < 1080 or _h < 1920:
                        _did_upscale = True
            except: pass
            upscale_if_needed(local_path, None, fast_mode=fast_mode)
            _song = None
            if use_mix_sound:
                _sounds_folder = folder_sound or "D:\\TikTok\\sounds"
                _song = mix_sound(local_path, _sounds_folder, fast_mode=fast_mode)
            if _did_upscale and _song:        slog(f"⬆ Upscale + 🎵 {_song}")
            elif _did_upscale and use_mix_sound: slog(f"⬆ Upscale (no sound)")
            elif _did_upscale:                slog(f"⬆ Upscale (Mix Sound OFF)")
            elif _song:                       slog(f"🎵 {_song}")
            elif use_mix_sound:               slog(f"⚠ No sound")
            else:                             slog(f"🔇 Mix Sound dimatikan")

        size_mb = os.path.getsize(local_path) / (1024*1024)
        push_to_device(d, local_path, filename)
        step(1, f"Push video ke HP... ({size_mb:.2f} MB)")

        # [02/10] Buka Shopee
        dlog(serial or "", f"Shopee [{item_id}] — Buka Shopee")
        step(2, "Buka Shopee...")
        _shopee_stop(d, shopee_clone); time.sleep(1)
        _shopee_start(d, shopee_clone)
        d.set_orientation('natural')
        delay(None, 7, "")

        # [03/10] Pilih video dari gallery
        dlog(serial or "", f"Shopee [{item_id}] — Pilih video gallery")
        step(3, "Pilih video dari gallery...")
        MAX_RESTART = 10
        for _restart_attempt in range(MAX_RESTART + 1):
            if _restart_attempt > 0:
                slog(f"⚠ Gallery tidak ditemukan, restart Shopee ({_restart_attempt}/{MAX_RESTART})...")
                force_restart_shopee(d, log, shopee_clone)

            # click_live — lanjut kalau gagal
            try: click_live(d); delay(None, 5, "")
            except: pass

            # click_upload — lanjut kalau gagal
            try: click_upload(d); delay(None, 6, "")
            except: pass

            # click_gallery — ini trigger restart kalau gagal
            try:
                click_gallery(d, slog); delay(None, 3, "")
            except Exception as _e:
                slog(f"❌ Gallery: {_e}")
                if _restart_attempt >= MAX_RESTART:
                    raise Exception(f"Gagal buka gallery Shopee setelah {MAX_RESTART} restart")
                continue

            # click_video_tab — lanjut kalau gagal
            try: click_video_tab(d); delay(None, 3, "")
            except: pass

            slog(f"Gallery ditemukan ✓")
            break

        select_first_video(d);  delay(None, 3,  "")
        click_lanjutkan(d);     delay(None, 3,  "")
        click_lanjutkan(d);     delay(None, 5,  "")

        # [04/10] Tambah produk
        dlog(serial or "", f"Shopee [{item_id}] — Tambah produk")
        step(4, "Tambah produk...")
        # Matikan auto rotate sebelum tambah produk — cek dulu sebelum matikan
        try:
            val = d.shell("settings get system accelerometer_rotation").output.strip()
            if val == '1':
                d.shell("settings put system accelerometer_rotation 0")
                d.shell("settings put system user_rotation 0")
        except Exception:
            pass
        click_tambah_produk(d); delay(None, 7,  "")
        click_semua_tab(d);     delay(None, 3,  "")
        click_cari_produk(d);   delay(None, 3,  "")

        # [05/10] Cari produk
        dlog(serial or "", f"Shopee [{item_id}] — Cari produk")
        step(5, "Cari produk...")
        search_and_tambah_product(d, product, slog); delay(None, 3, "")

        # [06/10] Konfirmasi & selesai
        dlog(serial or "", f"Shopee [{item_id}] — Konfirmasi")
        step(6, "Konfirmasi & selesai...")
        click_selesai(d); delay(None, 5, "")

        # [07/10] Set cover
        dlog(serial or "", f"Shopee [{item_id}] — Set cover")
        step(7, "Set cover...")
        click_pilih_cover(d);   delay(None, 5,  "")
        click_random_frame(d);  delay(None, 2,  "")
        click_check(d);         delay(None, 3,  "")

        # [08/10] Set caption
        dlog(serial or "", f"Shopee [{item_id}] — Set caption")
        step(8, "Set caption...")
        disable_share_whatsapp(d)
        delay(None, 3, "")
        click_caption_field(d); delay(None, 2,  "")
        input_caption_shopee(d, caption); delay(None, 2, "")
        click_ok(d);            delay(None, 3,  "")

        # [09/10] Posting
        dlog(serial or "", f"Shopee [{item_id}] — Posting")
        step(9, "Posting...")
        click_posting(d)
        wait_upload_success(d, log=log_fn)
        dlog(serial or "", f"Shopee [{item_id}] — SELESAI ✅")

        # [10/10] Selesai
        step(10, "✅ Shopee Selesai")
        _error_msg = ""

    except Exception as e:
        log(f"[{_step:02d}/10] ❌ {e}")
        _error_msg = str(e)
        log(f"[10/10] ❌ Shopee Gagal")
        return False, _error_msg

    # Menonton video — di luar slot
    try:
        delay(None, 5, "")
        click_profile_icon(d)
        delay(None, 3, "")
        click_top_video(d)
        if pre_watch_fn: pre_watch_fn()
        jeda_nonton = random.randint(watch_min, watch_max)
        if log_fn: log_fn(f"━━━ Jeda nonton {jeda_nonton}s sebelum video berikutnya ━━━")
        time.sleep(jeda_nonton)
    except: pass

    return True, ""
