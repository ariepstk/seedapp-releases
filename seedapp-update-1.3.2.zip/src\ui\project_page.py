"""
Project Page - SeedApp
- Tabel: kolom Status diganti 2 kolom Shopee + TikTok
- Dialog: radio button upload target (Shopee & TikTok / Shopee saja)
- Force stop: kirim stop_file → subprocess berhenti sendiri
- Ulangi Gagal: reset error + proses → antrian
- RunWorker: subprocess terpisah per HP (Opsi B — cegah crash uiautomator2)
- RetryWorker: tetap QThread (1 item, singkat)
"""

import os
import sys
import json
import subprocess
import threading
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView,
    QDialog, QLineEdit, QComboBox, QMessageBox, QStackedWidget,
    QMenu, QTextEdit, QProgressBar, QSplitter, QSpinBox,
    QButtonGroup, QRadioButton, QCheckBox
)
from PyQt6.QtCore import Qt, pyqtSignal, QThread, QTimer
from src.core.database import ProjectRepo, DatasetRepo, VideoRepo
from src.core.log_manager import log_file_path, stop_file_path
from src.macro import adb_helper

STATUS_OPTIONS = ["antrian","berjalan","berhenti","selesai"]
STATUS_LABELS  = {"antrian":"Antrian","berjalan":"Berjalan",
                  "berhenti":"Berhenti","selesai":"Selesai"}
STATUS_BADGE   = {"antrian":"badgeAntrian","berjalan":"badgeBerjalan",
                  "berhenti":"badgeBerhenti","selesai":"badgeSelesai"}


def _dialog_style():
    try:
        from src.ui.main_window import MainWindow
        return MainWindow.get_dialog_style()
    except Exception:
        from src.ui.styles import DIALOG_DARK
        return DIALOG_DARK


# ══════════════════════════════════════════════════
#  SubprocessWorker — 1 subprocess per HP
#  Menggantikan RunWorker QThread agar crash
#  uiautomator2 tidak membunuh proses UI.
# ══════════════════════════════════════════════════
class SubprocessWorker:
    """
    Wrapper subprocess per HP. Interface mirip QThread agar
    LogManager dan process_monitor tetap bisa pakai is_alive().
    Log dibaca dari file oleh LogPoller (QThread).
    """

    def __init__(self, project_id: int, device_serial: str = None,
                 target_selesai: int = 0, watch_min: int = 1750,
                 watch_max: int = 1800,
                 on_log=None, on_finished=None):
        self.project_id    = project_id
        self.device_serial = device_serial or ""
        self.target_selesai = target_selesai
        self.watch_min     = watch_min
        self.watch_max     = watch_max
        self._on_log       = on_log       # callback(msg: str)
        self._on_finished  = on_finished  # callback(success: int, error: int)
        self._proc         = None
        self._poller       = None
        self._alive        = False

    def is_alive(self) -> bool:
        return self._alive

    # Alias agar _is_alive() di log_manager support keduanya
    def isRunning(self) -> bool:
        return self._alive

    def start(self):
        # Paths
        worker_script = os.path.join(
            os.path.dirname(__file__), '..', 'core', 'worker_process.py')
        worker_script = os.path.normpath(worker_script)

        log_file  = log_file_path(self.project_id)
        stop_file = stop_file_path(self.project_id)

        # Bersihkan stop file lama
        try:
            if os.path.exists(stop_file):
                os.remove(stop_file)
        except Exception:
            pass

        cmd = [
            sys.executable, worker_script,
            f"--project_id={self.project_id}",
            f"--log_file={log_file}",
            f"--stop_file={stop_file}",
            f"--device_serial={self.device_serial}",
            f"--target={self.target_selesai}",
            f"--watch_min={self.watch_min}",
            f"--watch_max={self.watch_max}",
        ]

        self._alive = True
        self._proc  = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )

        # Start log poller thread (baca file log → callback ke UI)
        self._poller = LogPoller(
            project_id = self.project_id,
            log_file   = log_file,
            proc       = self._proc,
            on_log     = self._on_log,
            on_done    = self._on_proc_done,
        )
        self._poller.start()

    def _on_proc_done(self, success: int, error: int):
        self._alive = False
        if self._on_finished:
            self._on_finished(success, error)

    def stop(self):
        """Kirim stop flag — subprocess akan berhenti sendiri."""
        stop_file = stop_file_path(self.project_id)
        try:
            open(stop_file, "w").close()
        except Exception:
            pass

    def terminate(self):
        """Hard kill subprocess jika stop flag tidak cukup."""
        self.stop()
        if self._proc and self._proc.poll() is None:
            try: self._proc.terminate()
            except Exception: pass

    def wait(self, timeout_ms: int = 3000):
        if self._proc:
            try: self._proc.wait(timeout=timeout_ms / 1000)
            except Exception: pass


# ══════════════════════════════════════════════════
#  LogPoller — QThread yang polling file log
#  dan emit ke UI via callback
# ══════════════════════════════════════════════════
class LogPoller(QThread):
    _log_signal      = pyqtSignal(str)
    _finished_signal = pyqtSignal(int, int)

    def __init__(self, project_id: int, log_file: str,
                 proc: subprocess.Popen,
                 on_log=None, on_done=None):
        super().__init__()
        self.project_id = project_id
        self.log_file   = log_file
        self.proc       = proc
        self._log_signal.connect(on_log or (lambda m: None))
        self._finished_signal.connect(on_done or (lambda s, e: None))
        self._lines_read = 0

    def run(self):
        import time
        success = 0
        error   = 0

        while True:
            # Baca baris baru dari log file
            try:
                if os.path.exists(self.log_file):
                    with open(self.log_file, "r", encoding="utf-8") as f:
                        all_lines = f.readlines()
                    new_lines = all_lines[self._lines_read:]
                    for line in new_lines:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                            msg = entry.get("msg", "")
                            # Parse __DONE__ marker
                            if msg.startswith("__DONE__"):
                                parts = msg.split()
                                for p in parts:
                                    if p.startswith("success="):
                                        success = int(p.split("=")[1])
                                    elif p.startswith("error="):
                                        error = int(p.split("=")[1])
                            else:
                                self._log_signal.emit(msg)
                        except Exception:
                            self._log_signal.emit(line)
                    self._lines_read += len(new_lines)
            except Exception:
                pass

            # Cek apakah proses sudah selesai
            if self.proc.poll() is not None:
                # Baca sisa log sekali lagi
                try:
                    if os.path.exists(self.log_file):
                        with open(self.log_file, "r", encoding="utf-8") as f:
                            all_lines = f.readlines()
                        new_lines = all_lines[self._lines_read:]
                        for line in new_lines:
                            line = line.strip()
                            if not line: continue
                            try:
                                entry = json.loads(line)
                                msg = entry.get("msg", "")
                                if msg.startswith("__DONE__"):
                                    parts = msg.split()
                                    for p in parts:
                                        if p.startswith("success="): success = int(p.split("=")[1])
                                        elif p.startswith("error="): error = int(p.split("=")[1])
                                else:
                                    self._log_signal.emit(msg)
                            except Exception:
                                self._log_signal.emit(line)
                except Exception:
                    pass
                break

            time.sleep(0.5)

        self._finished_signal.emit(success, error)


# ══════════════════════════════════════════════════
#  Retry Worker — jalankan ulang 1 platform saja
# ══════════════════════════════════════════════════
class RetryWorker(QThread):
    log      = pyqtSignal(str)
    finished = pyqtSignal(bool)   # True = sukses

    def __init__(self, item: dict, platform: str, device_serial: str = None,
                 project_id: int = None):
        super().__init__()
        self.item            = item
        self.platform        = platform
        self.device_serial   = device_serial
        self.project_id_ref  = project_id
        self._stop           = False

    def stop(self): self._stop = True

    def run(self):
        from src.macro import shopee_only, tiktok_only
        from src.macro.media_helper import cleanup_hp
        from src.core.database import VideoRepo

        item   = self.item
        serial = self.device_serial
        log_fn = lambda msg: self.log.emit(msg)
        excel_no = item.get("no")

        try:
            # Hapus semua video di HP sebelum download agar select_first_video tidak salah pilih
            try:
                import uiautomator2 as u2
                d_pre = u2.connect(serial) if serial else u2.connect()
                d_pre.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mp4' -delete")
                d_pre.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mov' -delete")
                self.log.emit("🗑 Hapus video lama di HP sebelum retry")
            except Exception as e:
                self.log.emit(f"⚠ Gagal hapus video HP: {e}")

            import uiautomator2 as u2
            d = u2.connect(serial) if serial else u2.connect()
            try:
                if self.platform == "shopee":
                    self.log.emit("🔄 Retry Shopee...")
                    ok, err = shopee_only.run_upload_flow(
                        d         = d,
                        caption   = item.get("caption_shopee",""),
                        product   = item.get("product_shopee",""),
                        video_url = item.get("video_result",""),
                        item_id   = excel_no,
                        log_fn    = log_fn,
                    )
                    if not ok and err:
                        VideoRepo.save_error_message(
                            self.project_id_ref, item["id"], error_shopee=err)
                else:
                    self.log.emit("🔄 Retry TikTok...")
                    ok, err = tiktok_only.run_upload_flow(
                        d                = d,
                        caption          = item.get("caption_tiktok",""),
                        product          = item.get("product_shopee",""),
                        video_url        = item.get("video_result",""),
                        item_id          = excel_no,
                        caption_tiktok   = item.get("caption_tiktok",""),
                        link_tiktok      = item.get("link_tiktok",""),
                        keranjang_tiktok = item.get("keranjang_tiktok",""),
                        log_fn           = log_fn,
                    )
                    if not ok and err:
                        VideoRepo.save_error_message(
                            self.project_id_ref, item["id"], error_tiktok=err)
            finally:
                # Cleanup HP + destroy d
                self.log.emit(f"\n🧹 Cleanup HP retry [{excel_no}]...")
                try:
                    cleanup_hp(d, excel_no, f"retry_{self.platform}", log_fn)
                except Exception as e:
                    self.log.emit(f"⚠ Cleanup HP error: {e}")
                d = None

            self.finished.emit(ok)

        except Exception as e:
            self.log.emit(f"❌ Retry error: {e}")
            self.finished.emit(False)


# ══════════════════════════════════════════════════
#  Dialog Edit Video
# ══════════════════════════════════════════════════
class VideoEditDialog(QDialog):
    def __init__(self, parent=None, item=None, project_id=None):
        super().__init__(parent)
        self.item = item or {}
        self.project_id = project_id
        self.setWindowTitle("Edit Video")
        self.setMinimumWidth(500)
        self._build()

    def _build(self):
        self.setStyleSheet(_dialog_style())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24,20,24,20); layout.setSpacing(8)

        def row(lbl, widget):
            layout.addWidget(QLabel(lbl)); layout.addWidget(widget)

        self.caption_shopee = QLineEdit(self.item.get("caption_shopee",""))
        row("Caption Shopee", self.caption_shopee)
        self.product_shopee = QLineEdit(self.item.get("product_shopee",""))
        row("Judul (Product)", self.product_shopee)
        self.caption_tiktok = QLineEdit(self.item.get("caption_tiktok",""))
        row("Caption TikTok", self.caption_tiktok)
        self.link_tiktok = QLineEdit(self.item.get("link_tiktok",""))
        row("Link TikTok", self.link_tiktok)
        self.keranjang = QLineEdit(self.item.get("keranjang_tiktok",""))
        row("Keranjang TikTok", self.keranjang)
        self.video_result = QLineEdit(self.item.get("video_result",""))
        row("Video Result (URL)", self.video_result)

        # Status Shopee & TikTok side by side
        STATUS_OPTS = [("antrian","Antrian"),("proses","Proses"),("selesai","Selesai"),("error","Error")]
        layout.addSpacing(4)
        status_row = QHBoxLayout(); status_row.setSpacing(12)

        s_col = QVBoxLayout(); s_col.setSpacing(4)
        s_col.addWidget(QLabel("Status Shopee"))
        self.status_shopee_combo = QComboBox()
        for val, lbl in STATUS_OPTS: self.status_shopee_combo.addItem(lbl, val)
        cur_s = self.item.get("status_shopee","antrian")
        for i in range(self.status_shopee_combo.count()):
            if self.status_shopee_combo.itemData(i) == cur_s:
                self.status_shopee_combo.setCurrentIndex(i); break
        s_col.addWidget(self.status_shopee_combo)

        t_col = QVBoxLayout(); t_col.setSpacing(4)
        t_col.addWidget(QLabel("Status TikTok"))
        self.status_tiktok_combo = QComboBox()
        for val, lbl in STATUS_OPTS: self.status_tiktok_combo.addItem(lbl, val)
        cur_t = self.item.get("status_tiktok","antrian")
        for i in range(self.status_tiktok_combo.count()):
            if self.status_tiktok_combo.itemData(i) == cur_t:
                self.status_tiktok_combo.setCurrentIndex(i); break
        t_col.addWidget(self.status_tiktok_combo)

        status_row.addLayout(s_col); status_row.addLayout(t_col)
        layout.addLayout(status_row)

        layout.addSpacing(10)
        btn_row = QHBoxLayout(); btn_row.addStretch()
        cancel = QPushButton("Batal"); cancel.setObjectName("btnSecondary")
        cancel.setFixedSize(90,36); cancel.clicked.connect(self.reject)
        save = QPushButton("Simpan"); save.setObjectName("btnPrimary")
        save.setFixedSize(90,36); save.clicked.connect(self.accept)
        btn_row.addWidget(cancel); btn_row.addSpacing(8); btn_row.addWidget(save)
        layout.addLayout(btn_row)

    def get_data(self):
        return {
            "caption_shopee":   self.caption_shopee.text().strip(),
            "product_shopee":   self.product_shopee.text().strip(),
            "caption_tiktok":   self.caption_tiktok.text().strip(),
            "link_tiktok":      self.link_tiktok.text().strip(),
            "keranjang_tiktok": self.keranjang.text().strip(),
            "video_result":     self.video_result.text().strip(),
            "status_shopee":    self.status_shopee_combo.currentData(),
            "status_tiktok":    self.status_tiktok_combo.currentData(),
        }


# ══════════════════════════════════════════════════
#  Dialog Tambah / Edit Project
# ══════════════════════════════════════════════════
class ProjectDialog(QDialog):
    def __init__(self, parent=None, project=None):
        super().__init__(parent)
        self.project = project
        self.is_edit = project is not None
        self.setWindowTitle("Edit Project" if self.is_edit else "Tambah Project")
        self.setMinimumWidth(460)
        self._build()

    def _build(self):
        self.setStyleSheet(_dialog_style())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26,22,26,22); layout.setSpacing(10)

        def add(lbl, widget):
            layout.addWidget(QLabel(lbl)); layout.addWidget(widget)

        # Nama
        self.name_input = QLineEdit(self.project.get("name","") if self.is_edit else "")
        self.name_input.setPlaceholderText("Contoh: HP 01")
        add("Nama HP / Project", self.name_input)

        # ── Radio button upload target ──────────────
        cur_target = self.project.get("upload_target","shopee_tiktok") if self.is_edit else "shopee_tiktok"

        target_lbl = QLabel("Tujuan Upload")
        target_lbl.setStyleSheet("color:#8082b0; font-size:13px;")
        layout.addWidget(target_lbl)

        radio_frame = QFrame()
        radio_frame.setObjectName("radioFrame")
        radio_lay = QHBoxLayout(radio_frame)
        radio_lay.setContentsMargins(12,8,12,8); radio_lay.setSpacing(24)

        self.radio_both   = QRadioButton("Shopee & TikTok")
        self.radio_shopee = QRadioButton("Shopee Saja")
        for rb in (self.radio_both, self.radio_shopee):
            rb.setStyleSheet("background:transparent;")

        self._radio_group = QButtonGroup(self)
        self._radio_group.addButton(self.radio_both,   0)
        self._radio_group.addButton(self.radio_shopee, 1)

        if cur_target == "shopee":
            self.radio_shopee.setChecked(True)
        else:
            self.radio_both.setChecked(True)

        radio_lay.addWidget(self.radio_both)
        radio_lay.addWidget(self.radio_shopee)
        radio_lay.addStretch()
        layout.addWidget(radio_frame)

        # Deskripsi
        self.desc_input = QLineEdit(self.project.get("description","") if self.is_edit else "")
        self.desc_input.setPlaceholderText("Deskripsi singkat... (opsional)")
        add("Deskripsi", self.desc_input)

        # Dataset
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItem("-- Pilih Dataset --", None)
        try:
            for ds in DatasetRepo.get_all():
                self.dataset_combo.addItem(
                    f"{ds['name']}  ({ds.get('total_video',0)} video)", ds["id"])
            if self.is_edit and self.project.get("dataset_id"):
                for i in range(self.dataset_combo.count()):
                    if self.dataset_combo.itemData(i) == self.project["dataset_id"]:
                        self.dataset_combo.setCurrentIndex(i); break
        except Exception as e:
            self.dataset_combo.addItem(f"Error: {e}", None)
        add("Dataset", self.dataset_combo)

        if self.is_edit:
            self.status_combo = QComboBox()
            for s in STATUS_OPTIONS:
                self.status_combo.addItem(STATUS_LABELS[s], s)
            cur = self.project.get("status","antrian")
            for i in range(self.status_combo.count()):
                if self.status_combo.itemData(i) == cur:
                    self.status_combo.setCurrentIndex(i); break
            add("Status", self.status_combo)

        # Device
        layout.addWidget(QLabel("Device HP (ADB)"))
        dev_row = QHBoxLayout(); dev_row.setSpacing(6)
        self.device_combo = QComboBox()
        self._scan_devices()
        dev_row.addWidget(self.device_combo, 1)
        scan_btn = QPushButton("🔍"); scan_btn.setObjectName("btnSecondary")
        scan_btn.setFixedSize(38,38); scan_btn.clicked.connect(self._scan_devices)
        dev_row.addWidget(scan_btn); layout.addLayout(dev_row)

        layout.addSpacing(14)
        btn_row = QHBoxLayout(); btn_row.addStretch()
        cancel = QPushButton("Batal"); cancel.setObjectName("btnSecondary")
        cancel.setFixedSize(95,38); cancel.clicked.connect(self.reject)
        save = QPushButton("Simpan"); save.setObjectName("btnPrimary")
        save.setFixedSize(95,38); save.clicked.connect(self._save)
        btn_row.addWidget(cancel); btn_row.addSpacing(8); btn_row.addWidget(save)
        layout.addLayout(btn_row)

    def _scan_devices(self):
        saved = self.device_combo.currentData() if self.device_combo.count() else None
        self.device_combo.clear()
        self.device_combo.addItem("-- Pilih Device --", None)
        try:
            devices = adb_helper.get_devices()
            for d in devices:
                self.device_combo.addItem(d["label"], d["serial"])
            if not devices:
                self.device_combo.addItem("Tidak ada device terdeteksi", None)
        except RuntimeError:
            self.device_combo.addItem("ADB tidak ditemukan di PATH", None)
        target = saved or (self.project.get("device_serial") if self.is_edit else None)
        if target:
            for i in range(self.device_combo.count()):
                if self.device_combo.itemData(i) == target:
                    self.device_combo.setCurrentIndex(i); break

    def _save(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self,"Error","Nama project tidak boleh kosong!"); return
        self.result_name          = name
        self.result_desc          = self.desc_input.text().strip()
        self.result_dataset_id    = self.dataset_combo.currentData()
        self.result_status        = self.status_combo.currentData() if self.is_edit else "antrian"
        self.result_device_serial = self.device_combo.currentData()
        self.result_upload_target = "shopee" if self.radio_shopee.isChecked() else "shopee_tiktok"
        self.accept()


# ══════════════════════════════════════════════════
#  Bulk Start Dialog
# ══════════════════════════════════════════════════
class BulkStartDialog(QDialog):
    def __init__(self, parent=None, project_ids=None):
        super().__init__(parent)
        self.setWindowTitle("Start Massal")
        self.setMinimumWidth(340)
        self.project_ids  = project_ids or []
        self.target_val   = 1
        self.watch_min_val = 1750
        self.watch_max_val = 1800
        self._build()

    def _build(self):
        self.setStyleSheet(_dialog_style())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26,22,26,22); layout.setSpacing(12)

        n = len(self.project_ids)
        lbl = QLabel(f"Start {n} project secara bersamaan")
        lbl.setObjectName("pageTitle"); layout.addWidget(lbl)

        # Target selesai
        layout.addWidget(QLabel("Target Selesai (video)"))
        self.target_spin = QSpinBox()
        self.target_spin.setRange(1,9999); self.target_spin.setValue(1)
        self.target_spin.setFixedHeight(36); layout.addWidget(self.target_spin)

        # Durasi menonton
        layout.addWidget(QLabel("Durasi Menonton (detik)"))
        watch_row = QHBoxLayout(); watch_row.setSpacing(8)
        self.wmin_spin = QSpinBox()
        self.wmin_spin.setRange(1,99999); self.wmin_spin.setValue(1750)
        self.wmin_spin.setFixedHeight(36)
        dash = QLabel("–"); dash.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.wmax_spin = QSpinBox()
        self.wmax_spin.setRange(1,99999); self.wmax_spin.setValue(1800)
        self.wmax_spin.setFixedHeight(36)
        watch_row.addWidget(self.wmin_spin); watch_row.addWidget(dash)
        watch_row.addWidget(self.wmax_spin); layout.addLayout(watch_row)

        layout.addSpacing(8)
        btn_row = QHBoxLayout(); btn_row.addStretch()
        cancel = QPushButton("Batal"); cancel.setObjectName("btnSecondary")
        cancel.setFixedSize(95,38); cancel.clicked.connect(self.reject)
        ok = QPushButton("▶  Start"); ok.setObjectName("btnSuccess")
        ok.setFixedSize(95,38); ok.clicked.connect(self._confirm)
        btn_row.addWidget(cancel); btn_row.addSpacing(8); btn_row.addWidget(ok)
        layout.addLayout(btn_row)

    def _confirm(self):
        self.target_val    = self.target_spin.value()
        self.watch_min_val = self.wmin_spin.value()
        self.watch_max_val = self.wmax_spin.value()
        if self.watch_min_val > self.watch_max_val:
            self.watch_min_val, self.watch_max_val = self.watch_max_val, self.watch_min_val
        self.accept()


# ══════════════════════════════════════════════════
#  Project List Page
# ══════════════════════════════════════════════════
class ProjectListPage(QWidget):
    open_project = pyqtSignal(int)
    FILTERS = [("semua","Semua"),("berjalan","Berjalan"),
               ("berhenti","Berhenti"),("selesai","Selesai")]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._filter    = "semua"
        self._selected  = set()   # set of project_id yang dicentang
        self._sel_mode  = False   # mode select aktif atau tidak
        self._bulk_workers = {}   # {project_id: RunWorker} untuk start massal
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)

        # ── Page header bar ──
        hdr_frame = QFrame(); hdr_frame.setObjectName("pageHeader"); hdr_frame.setFixedHeight(64)
        hdr_lay = QHBoxLayout(hdr_frame); hdr_lay.setContentsMargins(28,0,28,0); hdr_lay.setSpacing(10)
        t = QLabel("Daftar Project"); t.setObjectName("pageTitle"); hdr_lay.addWidget(t)
        hdr_lay.addStretch()
        self.search = QLineEdit(); self.search.setObjectName("searchInput")
        self.search.setPlaceholderText("🔍  Cari project..."); self.search.setFixedWidth(220)
        self.search.textChanged.connect(self._apply); hdr_lay.addWidget(self.search)
        self.select_btn = QPushButton("☑ Select"); self.select_btn.setObjectName("btnSecondary")
        self.select_btn.setFixedHeight(28)
        self.select_btn.clicked.connect(self._toggle_select_mode); hdr_lay.addWidget(self.select_btn)
        self.select_all_btn = QPushButton("⬛ Select All"); self.select_all_btn.setObjectName("btnSecondary")
        self.select_all_btn.setFixedHeight(30); self.select_all_btn.setVisible(False)
        self.select_all_btn.clicked.connect(self._toggle_select_all); hdr_lay.addWidget(self.select_all_btn)
        self.bulk_start_btn = QPushButton("▶ Start Massal"); self.bulk_start_btn.setObjectName("btnSuccess")
        self.bulk_start_btn.setFixedHeight(28); self.bulk_start_btn.setVisible(False)
        self.bulk_start_btn.clicked.connect(self._bulk_start); hdr_lay.addWidget(self.bulk_start_btn)
        self.aksi_btn = QPushButton("▼ Aksi"); self.aksi_btn.setObjectName("btnSecondary")
        self.aksi_btn.setFixedHeight(28); self.aksi_btn.setVisible(False)
        self.aksi_btn.clicked.connect(self._show_aksi_menu); hdr_lay.addWidget(self.aksi_btn)
        add_btn = QPushButton("＋ Tambah"); add_btn.setObjectName("btnPrimary")
        add_btn.setFixedHeight(28)
        add_btn.clicked.connect(self._add); hdr_lay.addWidget(add_btn)
        layout.addWidget(hdr_frame)

        div = QFrame(); div.setFixedHeight(1); div.setObjectName("headerDivider")
        layout.addWidget(div)

        # ── Filter tabs + list ──
        body = QWidget()
        body_lay = QVBoxLayout(body); body_lay.setContentsMargins(28,16,28,16); body_lay.setSpacing(12)

        fr = QHBoxLayout(); fr.setSpacing(8); self._filter_btns = {}
        for key, label in self.FILTERS:
            btn = QPushButton(label); btn.setObjectName("filterTab")
            btn.clicked.connect(lambda _, k=key: self._set_filter(k))
            self._filter_btns[key] = btn; fr.addWidget(btn)
        fr.addStretch(); body_lay.addLayout(fr)

        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        self.list_container = QWidget()
        self.list_container.setStyleSheet("background:transparent;")
        self.list_layout = QVBoxLayout(self.list_container)
        self.list_layout.setSpacing(4); self.list_layout.setContentsMargins(0,0,0,0)
        self.list_layout.addStretch(); scroll.setWidget(self.list_container)
        body_lay.addWidget(scroll)
        layout.addWidget(body, 1)
        self._set_filter("semua")

    def _set_filter(self, key):
        self._filter = key
        for k, btn in self._filter_btns.items():
            btn.setProperty("active","true" if k==key else "false")
            btn.style().unpolish(btn); btn.style().polish(btn)
        self._apply()

    def _apply(self):
        q = self.search.text().lower()
        rows = [p for p in ProjectRepo.get_all()
                if (self._filter=="semua" or p.get("status")==self._filter)
                and (not q or q in p["name"].lower())]
        self._render(rows)

    def refresh(self): self._apply()

    def _get_current_list(self):
        """Kembalikan list project sesuai filter & search saat ini."""
        q = self.search.text().lower()
        return [p for p in ProjectRepo.get_all()
                if (self._filter=="semua" or p.get("status")==self._filter)
                and (not q or q in p["name"].lower())]

    def _render(self, projects):
        while self.list_layout.count() > 1:
            item = self.list_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        if not projects:
            lbl = QLabel("Tidak ada project ditemukan.")
            lbl.setObjectName("itemMeta"); lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.list_layout.insertWidget(0, lbl); return
        for i, p in enumerate(projects):
            self.list_layout.insertWidget(self.list_layout.count()-1, self._make_row(i+1, p))

    def _make_row(self, no, p):
        frame = QFrame(); frame.setObjectName("listItem"); frame.setFixedHeight(56)
        row = QHBoxLayout(frame); row.setContentsMargins(12,0,12,0); row.setSpacing(10)

        # Checkbox (hanya tampil di mode select)
        chk = QCheckBox(); chk.setFixedSize(20,20)
        chk.setChecked(p["id"] in self._selected)
        chk.setVisible(self._sel_mode)
        def on_check(state, pid=p["id"]):
            if state: self._selected.add(pid)
            else: self._selected.discard(pid)
            has_sel = len(self._selected) > 0
            self.bulk_start_btn.setVisible(has_sel)
            self.aksi_btn.setVisible(has_sel)
        chk.stateChanged.connect(on_check)
        row.addWidget(chk)

        icon_f = QFrame(); icon_f.setObjectName("projectIcon"); icon_f.setFixedSize(36,36)
        icon_f.setStyleSheet(
            "QFrame#projectIcon { background:transparent; border:none; }")
        il = QHBoxLayout(icon_f); il.setContentsMargins(0,0,0,0)
        s_lbl = QLabel("📱"); s_lbl.setStyleSheet("font-size:20px; background:transparent; border:none;")
        s_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter); il.addWidget(s_lbl)

        info = QVBoxLayout(); info.setSpacing(2)
        name_lbl = QLabel(f"{no}. {p['name']}"); name_lbl.setObjectName("itemTitle")
        ds = p.get("dataset_name") or "Belum ada dataset"
        dev = p.get("device_serial") or ""
        target = p.get("upload_target","shopee_tiktok")
        target_icon = "🛍🎵" if target == "shopee_tiktok" else "🛍"
        meta_lbl = QLabel(f"{target_icon}  📋 {ds}" + (f"  ·  📱 {dev}" if dev else ""))
        meta_lbl.setObjectName("itemMeta")
        info.addWidget(name_lbl); info.addWidget(meta_lbl)

        stats = QHBoxLayout(); stats.setSpacing(20)
        for lbl_text, val, obj in [
            ("Total",   str(p.get("total",0)),   "statNum"),
            ("Error",   str(p.get("error",0)),   "statNumError"),
            ("Selesai", str(p.get("selesai",0)), "statNumSuccess"),
        ]:
            col = QVBoxLayout(); col.setSpacing(0)
            v = QLabel(val); v.setObjectName(obj); v.setAlignment(Qt.AlignmentFlag.AlignCenter)
            l = QLabel(lbl_text); l.setObjectName("itemMeta"); l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            col.addWidget(v); col.addWidget(l); stats.addLayout(col)

        sk = p.get("status","antrian")
        badge = QLabel(STATUS_LABELS.get(sk,"Antrian"))
        badge.setObjectName(STATUS_BADGE.get(sk,"badgeAntrian"))
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter); badge.setFixedWidth(82)

        menu_btn = QPushButton("⋮"); menu_btn.setObjectName("btnIcon"); menu_btn.setFixedWidth(30)
        menu_btn.clicked.connect(lambda _, pr=p, b=menu_btn: self._menu(pr, b))

        row.addWidget(icon_f); row.addLayout(info,2); row.addStretch()
        row.addLayout(stats); row.addSpacing(14)
        row.addWidget(badge); row.addWidget(menu_btn)

        # Klik frame → buka project (hanya jika bukan mode select)
        frame.setCursor(Qt.CursorShape.PointingHandCursor)
        def on_frame_click(event, pid=p["id"], c=chk):
            if self._sel_mode:
                c.setChecked(not c.isChecked())
            else:
                self.open_project.emit(pid)
        frame.mousePressEvent = on_frame_click
        return frame

    def _toggle_select_mode(self):
        self._sel_mode = not self._sel_mode
        if not self._sel_mode:
            self._selected.clear()
            self._all_selected = False
            self.bulk_start_btn.setVisible(False)
            self.aksi_btn.setVisible(False)
            self.select_all_btn.setVisible(False)
            self.select_btn.setText("☑ Select")
        else:
            self._selected.clear()
            self._all_selected = False
            self.select_all_btn.setText("⬛ Select All")
            self.bulk_start_btn.setVisible(False)
            self.aksi_btn.setVisible(False)
            self.select_btn.setText("✕ Batal")
            self.select_all_btn.setVisible(True)
        self._apply()

    def _toggle_select_all(self):
        self._all_selected = not getattr(self, "_all_selected", False)
        if self._all_selected:
            # Select semua project yang tampil
            all_projects = [p for p in ProjectRepo.get_all()
                           if (self._filter == "semua" or p.get("status") == self._filter)]
            self._selected = set(p["id"] for p in all_projects)
            self.select_all_btn.setText("⬜  Unselect All")
        else:
            self._selected.clear()
            self.select_all_btn.setText("⬛  Select All")
        # Update tombol massal
        has_sel = len(self._selected) > 0
        self.bulk_start_btn.setVisible(has_sel)
        self.aksi_btn.setVisible(has_sel)
        self._apply()

    def _show_aksi_menu(self):
        menu = QMenu(self)
        menu.addAction("🔄  Ulangi Gagal", self._bulk_retry)
        menu.addAction("⏹  Stop Massal", self._bulk_stop)
        menu.exec(self.aksi_btn.mapToGlobal(self.aksi_btn.rect().bottomLeft()))

    def _bulk_stop(self):
        if not self._selected: return
        from src.core.log_manager import LogManager
        from src.core.database import get_connection
        lm   = LogManager.instance()
        pids = sorted(self._selected)
        for pid in pids:
            worker = lm.get_worker(pid)
            if worker:
                worker.stop()
                worker.terminate()
                worker.wait(2000)
                lm.remove_worker(pid)
            # Update video proses → error + project status → berhenti
            try:
                conn = get_connection()
                conn.execute("""
                    UPDATE project_videos SET status='error',
                        status_shopee=CASE WHEN status_shopee='proses' THEN 'error' ELSE status_shopee END,
                        status_tiktok=CASE WHEN status_tiktok='proses' THEN 'error' ELSE status_tiktok END,
                        updated_at=datetime('now','localtime')
                    WHERE project_id=? AND status='proses'
                """, (pid,))
                conn.commit(); conn.close()
                ProjectRepo.update_status(pid, "berhenti")
            except: pass
            if pid in self._bulk_workers:
                del self._bulk_workers[pid]
        # Reset select mode
        self._all_selected = False
        self._selected.clear()
        self.bulk_start_btn.setVisible(False)
        self.aksi_btn.setVisible(False)
        self.select_all_btn.setVisible(False)
        self.select_btn.setText("☑ Select")
        self._sel_mode = False
        self._apply()

    def _bulk_retry(self):
        if not self._selected: return
        pids = sorted(self._selected)
        total_error = 0
        for pid in pids:
            st = VideoRepo.get_stats_by_project(pid)
            total_error += st.get("error", 0) + st.get("proses", 0)
        if total_error == 0:
            QMessageBox.information(self, "Info", "Tidak ada video Error / Proses di project yang dipilih.")
            return
        if QMessageBox.question(self, "Ulangi Gagal Massal",
            f"Reset {total_error} video Error/Proses dari {len(pids)} project → Antrian?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        ) != QMessageBox.StandardButton.Yes:
            return
        for pid in pids:
            VideoRepo.reset_failed_to_antrian(pid)
        # Reset select mode
        self._sel_mode = False
        self._all_selected = False
        self._selected.clear()
        self.bulk_start_btn.setVisible(False)
        self.aksi_btn.setVisible(False)
        self.select_all_btn.setVisible(False)
        self.select_btn.setText("☑ Select")
        self._apply()

    def _bulk_start(self):
        if not self._selected: return
        dlg = BulkStartDialog(self, list(self._selected))
        if not dlg.exec(): return
        target    = dlg.target_val
        watch_min = dlg.watch_min_val
        watch_max = dlg.watch_max_val

        from src.core.log_manager import LogManager
        from PyQt6.QtCore import QTimer

        pids = sorted(self._selected)

        def start_one(idx):
            if idx >= len(pids): return
            pid = pids[idx]
            p = ProjectRepo.get_by_id(pid)
            if not p or not p.get("dataset_id"):
                # Skip, langsung next
                QTimer.singleShot(0, lambda: start_one(idx + 1))
                return
            device = p.get("device_serial") or None

            import weakref
            _self = weakref.ref(self)
            def _on_bulk_log(msg, _pid=pid):
                LogManager.instance().append_from_file(_pid, "", msg) if False else \
                LogManager.instance().append(_pid, msg)
            def _on_bulk_done(ok, err, _pid=pid):
                s = _self()
                if s is not None: s._on_bulk_finished(_pid)
            worker = SubprocessWorker(
                project_id    = pid,
                device_serial = device,
                target_selesai = target,
                watch_min     = watch_min,
                watch_max     = watch_max,
                on_log        = _on_bulk_log,
                on_finished   = _on_bulk_done,
            )
            self._bulk_workers[pid] = worker
            LogManager.instance().set_worker(pid, worker)
            worker.start()

            # Jeda 5s sebelum start project berikutnya (non-blocking)
            QTimer.singleShot(20000, lambda: start_one(idx + 1))

        start_one(0)

        # Reset select mode
        self._sel_mode = False
        self._all_selected = False
        self._selected.clear()
        self.bulk_start_btn.setVisible(False)
        self.aksi_btn.setVisible(False)
        self.select_all_btn.setVisible(False)
        self.select_btn.setText("☑ Select")
        self._apply()

    def _on_bulk_finished(self, pid):
        from src.core.log_manager import LogManager
        LogManager.instance().remove_worker(pid)
        if pid in self._bulk_workers:
            del self._bulk_workers[pid]
        self._apply()

    def _menu(self, p, btn):
        menu = QMenu(self)
        menu.addAction("✏️  Edit", lambda: self._edit(p))
        menu.addSeparator()
        for s in STATUS_OPTIONS:
            if s != p.get("status"):
                menu.addAction(f"→ Set {STATUS_LABELS[s]}",
                               lambda _, pid=p["id"], st=s: self._set_status(pid,st))
        menu.addSeparator()
        menu.addAction("🗑️  Hapus", lambda: self._delete(p))
        menu.exec(btn.mapToGlobal(btn.rect().bottomLeft()))

    def _add(self):
        dlg = ProjectDialog(self)
        if dlg.exec():
            ProjectRepo.create(dlg.result_name, dlg.result_desc,
                               dlg.result_dataset_id, dlg.result_device_serial,
                               dlg.result_upload_target)
            self.refresh()

    def _edit(self, p):
        dlg = ProjectDialog(self, p)
        if dlg.exec():
            ProjectRepo.update(p["id"], dlg.result_name, dlg.result_desc,
                               dlg.result_dataset_id, dlg.result_status,
                               dlg.result_device_serial, dlg.result_upload_target)
            self.refresh()

    def _set_status(self, pid, status):
        ProjectRepo.update_status(pid, status); self.refresh()

    def _delete(self, p):
        if QMessageBox.question(self,"Hapus Project",f"Hapus project '{p['name']}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        ) == QMessageBox.StandardButton.Yes:
            ProjectRepo.delete(p["id"]); self.refresh()


# ══════════════════════════════════════════════════
#  Project Detail Page
# ══════════════════════════════════════════════════
class ProjectDetailPage(QWidget):
    go_back = pyqtSignal()
    go_prev = pyqtSignal()
    go_next = pyqtSignal()

    FILTER_KEYS  = ["antrian","proses","selesai","error"]
    FILTER_LABEL = {"antrian":"Antrian","proses":"Proses","selesai":"Selesai","error":"Error"}
    # Kolom: No | Judul | Caption Shopee | Caption TikTok | Link | Keranjang | Video Result | Shopee | TikTok | Edit | Del
    COLUMNS    = ["No","Judul (Product)","Caption Shopee","Caption TikTok",
                  "Link TikTok","Keranjang","Video Result","Shopee","TikTok","",""]
    COL_WIDTHS = [60, 160, 200, 160, 100, 80, 120, 82, 82, 36, 36]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.project_id  = None
        self._filter     = "antrian"
        self._worker     = None
        self._upload_target = "shopee_tiktok"
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(3000)
        self._refresh_timer.timeout.connect(self._realtime_refresh)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)

        # ── Header bar ──────────────────────────────────
        hdr_frame = QFrame(); hdr_frame.setObjectName("pageHeader"); hdr_frame.setFixedHeight(64)
        hdr_lay = QHBoxLayout(hdr_frame); hdr_lay.setContentsMargins(28,0,28,0); hdr_lay.setSpacing(10)
        self.btn_prev = QPushButton("‹"); self.btn_prev.setObjectName("btnSecondary")
        self.btn_prev.setFixedSize(36,36); self.btn_prev.setToolTip("Project sebelumnya")
        self.btn_prev.clicked.connect(self.go_prev.emit)
        self.btn_next = QPushButton("›"); self.btn_next.setObjectName("btnSecondary")
        self.btn_next.setFixedSize(36,36); self.btn_next.setToolTip("Project berikutnya")
        self.btn_next.clicked.connect(self.go_next.emit)
        self.title_lbl = QLabel("Project"); self.title_lbl.setObjectName("pageTitle")
        self.retry_btn = QPushButton("🔄 Ulangi Gagal")
        self.retry_btn.setObjectName("btnSecondary"); self.retry_btn.setFixedHeight(36)
        self.retry_btn.setToolTip("Reset video Error + Proses → Antrian")
        self.retry_btn.clicked.connect(self._retry_failed)
        self.start_btn = QPushButton("▶  Start")
        self.start_btn.setObjectName("btnSuccess"); self.start_btn.setFixedSize(115,36)
        self.start_btn.clicked.connect(self._toggle_run)
        hdr_lay.addWidget(self.btn_prev); hdr_lay.addSpacing(4)
        hdr_lay.addWidget(self.btn_next); hdr_lay.addSpacing(10)
        hdr_lay.addWidget(self.title_lbl)
        hdr_lay.addStretch()
        hdr_lay.addWidget(self.retry_btn); hdr_lay.addSpacing(6); hdr_lay.addWidget(self.start_btn)
        layout.addWidget(hdr_frame)
        div = QFrame(); div.setFixedHeight(1); div.setObjectName("headerDivider")
        layout.addWidget(div)

        # ── Body ──
        body = QWidget()
        body_lay = QVBoxLayout(body); body_lay.setContentsMargins(28,16,28,16); body_lay.setSpacing(10)
        layout.addWidget(body, 1)

        # ── Info strip ───────────────────────────────
        info_strip = QFrame(); info_strip.setObjectName("statStrip")
        info_lay = QHBoxLayout(info_strip)
        info_lay.setContentsMargins(16,8,16,8); info_lay.setSpacing(0)

        def strip_item(parent_lay, value_lbl_ref, color, label_text, left_pad=0, right_pad=24):
            item = QWidget(); item.setObjectName("statStripItem")
            il = QVBoxLayout(item); il.setContentsMargins(left_pad,0,right_pad,0); il.setSpacing(1)
            val_lbl = QLabel("—")
            val_lbl.setStyleSheet(f"font-size:14px;font-weight:600;color:{color};background:transparent;")
            lbl2 = QLabel(label_text); lbl2.setObjectName("statStripLbl")
            il.addWidget(val_lbl); il.addWidget(lbl2)
            parent_lay.addWidget(item)
            return val_lbl

        def divider(parent_lay):
            d = QLabel("|"); d.setObjectName("statDivider")
            d.setAlignment(Qt.AlignmentFlag.AlignCenter); d.setFixedWidth(20)
            parent_lay.addWidget(d)

        self.dataset_lbl = strip_item(info_lay, None, "#8b8fff", "DATASET", 0, 24)
        divider(info_lay)
        self.device_lbl  = strip_item(info_lay, None, "#60a5fa", "DEVICE",  24, 24)
        divider(info_lay)
        self.target_lbl  = strip_item(info_lay, None, "#fbbf24", "UPLOAD TARGET", 24, 24)
        divider(info_lay)

        # Target Selesai spinner
        lim_item = QWidget(); lim_item.setObjectName("statStripItem")
        lim_il = QVBoxLayout(lim_item); lim_il.setContentsMargins(24,0,0,0); lim_il.setSpacing(1)
        lim_lbl2 = QLabel("TARGET SELESAI"); lim_lbl2.setObjectName("statStripLbl")
        self.limit_spin = QSpinBox()
        self.limit_spin.setRange(1,9999); self.limit_spin.setValue(1)
        self.limit_spin.setMinimumWidth(130); self.limit_spin.setFixedHeight(34)
        self.limit_spin.setToolTip(
            "Target jumlah produk SELESAI (min 1 platform sukses).\n"
            "Runner terus proses sampai target tercapai.")
        lim_il.addWidget(lim_lbl2); lim_il.addWidget(self.limit_spin)
        info_lay.addWidget(lim_item)

        divider(info_lay)

        # Durasi menonton (min-max)
        watch_item = QWidget(); watch_item.setObjectName("statStripItem")
        watch_il = QVBoxLayout(watch_item); watch_il.setContentsMargins(24,0,16,0); watch_il.setSpacing(1)
        watch_lbl2 = QLabel("DURASI TONTON (detik)"); watch_lbl2.setObjectName("statStripLbl")
        watch_row = QHBoxLayout(); watch_row.setSpacing(4)
        self.watch_min_spin = QSpinBox()
        self.watch_min_spin.setRange(1,99999); self.watch_min_spin.setValue(10)
        self.watch_min_spin.setFixedHeight(34); self.watch_min_spin.setFixedWidth(70)
        self.watch_min_spin.setToolTip("Durasi menonton minimum (detik)")
        dash_lbl = QLabel("–"); dash_lbl.setObjectName("statStripLbl")
        self.watch_max_spin = QSpinBox()
        self.watch_max_spin.setRange(1,99999); self.watch_max_spin.setValue(20)
        self.watch_max_spin.setFixedHeight(34); self.watch_max_spin.setFixedWidth(70)
        self.watch_max_spin.setToolTip("Durasi menonton maksimum (detik)")
        watch_row.addWidget(self.watch_min_spin); watch_row.addWidget(dash_lbl)
        watch_row.addWidget(self.watch_max_spin)
        watch_il.addWidget(watch_lbl2); watch_il.addLayout(watch_row)
        info_lay.addWidget(watch_item)

        info_lay.addStretch()
        body_lay.addWidget(info_strip)

        # ── Filter tabs ──────────────────────────────
        fr = QHBoxLayout(); fr.setSpacing(8)
        self._filter_btns = {}
        for key in self.FILTER_KEYS:
            btn = QPushButton(f"{self.FILTER_LABEL[key]}  0")
            btn.setObjectName("filterTab"); btn.setMinimumWidth(120); btn.setFixedHeight(34)
            btn.clicked.connect(lambda _, k=key: self._set_filter(k))
            self._filter_btns[key] = btn; fr.addWidget(btn)
        fr.addStretch(); body_lay.addLayout(fr)
        self._update_filter_btns("antrian")

        # ── Splitter: Tabel + Log ────────────────────
        splitter = QSplitter(Qt.Orientation.Vertical)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        for i, w in enumerate(self.COL_WIDTHS):
            self.table.setColumnWidth(i, w)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(9,  QHeaderView.ResizeMode.Fixed)
        self.table.horizontalHeader().setSectionResizeMode(10, QHeaderView.ResizeMode.Fixed)
        splitter.addWidget(self.table)

        log_frame = QFrame(); log_frame.setObjectName("logPanel")
        log_v = QVBoxLayout(log_frame); log_v.setContentsMargins(0,0,0,0); log_v.setSpacing(0)
        log_bar = QHBoxLayout(); log_bar.setContentsMargins(12,0,12,0)
        log_title = QLabel("📋  Activity Log"); log_title.setObjectName("logTitle")
        log_title.setFixedHeight(32); log_bar.addWidget(log_title); log_bar.addStretch()
        clear_btn = QPushButton("Bersihkan"); clear_btn.setObjectName("btnIcon")
        clear_btn.setFixedHeight(26); clear_btn.clicked.connect(lambda: self.log_text.clear())
        log_bar.addWidget(clear_btn); log_v.addLayout(log_bar)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0,0); self.progress_bar.setFixedHeight(5)
        self.progress_bar.setVisible(False); log_v.addWidget(self.progress_bar)
        self.log_text = QTextEdit(); self.log_text.setObjectName("logText")
        self.log_text.setReadOnly(True)
        self.log_text.setPlaceholderText("Log aktivitas akan muncul di sini...")
        log_v.addWidget(self.log_text)
        splitter.addWidget(log_frame)

        splitter.setSizes([420,280])
        body_lay.addWidget(splitter, 1)

    def _safe_refresh(self):
        """Refresh stats & table dengan guard - aman dipanggil dari background thread signal."""
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, self._do_safe_refresh)

    def _do_safe_refresh(self):
        try:
            if not self.project_id or not self.isVisible():
                return
            self._refresh_stats()
            self._load_table()
        except Exception:
            pass

    def set_nav_buttons(self, has_prev: bool, has_next: bool):
        self.btn_prev.setEnabled(has_prev)
        self.btn_next.setEnabled(has_next)

    # ── Helpers ──────────────────────────────────
    def _log(self, msg, project_id=None):
        from src.core.log_manager import LogManager
        from datetime import datetime
        from PyQt6.QtCore import QTimer
        ts  = datetime.now().strftime("%H:%M:%S")
        pid = project_id or self.project_id
        if pid:
            LogManager.instance().append(pid, msg)
        # Defer semua UI update ke main thread agar aman dari worker thread
        QTimer.singleShot(0, lambda: self._log_ui(msg, pid, ts))

    def _log_ui(self, msg, pid, ts):
        """Update UI log — hanya dipanggil dari main thread via QTimer."""
        from src.core.log_manager import get_log_color
        # Hanya tampilkan di log_text kalau project yang aktif sama
        if pid != self.project_id:
            return
        color = get_log_color(msg)
        ts_colored  = f'<span style="color:#5a5c8a;">{ts}</span>'
        if color:
            msg_colored = f'<span style="color:{color};">{msg}</span>'
        else:
            msg_colored = msg
        self.log_text.append(f'{ts_colored} &nbsp;{msg_colored}')
        self.log_text.verticalScrollBar().setValue(
            self.log_text.verticalScrollBar().maximum())
        self._refresh_stats()
        self._load_table()

    def _realtime_refresh(self):
        self._refresh_stats(); self._load_table()

    # ── Ulangi Gagal (error + proses) ────────────
    def _retry_failed(self):
        if not self.project_id: return
        st = VideoRepo.get_stats_by_project(self.project_id)
        ec = st.get("error",0); pc = st.get("proses",0)
        total = ec + pc
        if total == 0:
            QMessageBox.information(self,"Info","Tidak ada video Error / Proses yang bisa direset."); return
        msg = f"Reset {total} video"
        detail = []
        if ec: detail.append(f"{ec} Error")
        if pc: detail.append(f"{pc} Proses (nyangkut)")
        if QMessageBox.question(self,"Ulangi Gagal",
            f"{msg} ({', '.join(detail)}) → Antrian?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        ) == QMessageBox.StandardButton.Yes:
            VideoRepo.reset_failed_to_antrian(self.project_id)
            self._log(f"🔄  {msg} direset → Antrian")
            self._refresh_stats(); self._load_table()

    # ── Start / Force Stop ───────────────────────
    def _toggle_run(self):
        from src.core.log_manager import LogManager
        if LogManager.instance().is_running(self.project_id):
            self._force_stop()
        else:
            self._start_run()

    def _start_run(self):
        from src.core.log_manager import LogManager
        if not self.project_id: return
        p = ProjectRepo.get_by_id(self.project_id)
        if not p or not p.get("dataset_id"):
            QMessageBox.warning(self,"Tidak bisa Start",
                "Project belum punya dataset!\nEdit project dan pilih dataset."); return

        target    = self.limit_spin.value()
        watch_min = self.watch_min_spin.value()
        watch_max = self.watch_max_spin.value()
        if watch_min > watch_max:
            watch_min, watch_max = watch_max, watch_min
        device = p.get("device_serial") or None

        self.start_btn.setText("⏹  Stop")
        self.start_btn.setObjectName("btnDanger")
        self.start_btn.style().unpolish(self.start_btn)
        self.start_btn.style().polish(self.start_btn)
        self.progress_bar.setRange(0,0); self.progress_bar.setVisible(True)

        captured_pid = self.project_id
        import weakref
        _self = weakref.ref(self)
        def _on_log(msg):
            s = _self()
            if s is not None:
                s._log(msg, captured_pid)
                LogManager.instance().append(captured_pid, msg)
        def _on_finished(ok, err):
            s = _self()
            if s is not None: s._on_run_finished(ok, err)

        self._worker = SubprocessWorker(
            project_id    = self.project_id,
            device_serial = device,
            target_selesai = target,
            watch_min     = watch_min,
            watch_max     = watch_max,
            on_log        = _on_log,
            on_finished   = _on_finished,
        )
        self._worker.start()

        LogManager.instance().set_worker(self.project_id, self._worker)
        self._refresh_timer.start()

    def _force_stop(self):
        """Force terminate thread + set video proses → error."""
        from src.core.log_manager import LogManager
        worker = LogManager.instance().get_worker(self.project_id)
        if not worker: return
        self._log("⏹  Force stop...")

        worker.stop()
        worker.terminate()
        worker.wait(2000)
        LogManager.instance().remove_worker(self.project_id)

        if self.project_id:
            conn = None
            try:
                from src.core.database import get_connection
                conn = get_connection()
                # Set proses → error per platform
                conn.execute("""
                    UPDATE project_videos SET
                        status_shopee = CASE WHEN status_shopee='proses' THEN 'error' ELSE status_shopee END,
                        status_tiktok = CASE WHEN status_tiktok='proses' THEN 'error' ELSE status_tiktok END,
                        updated_at    = datetime('now','localtime')
                    WHERE project_id=? AND status='proses'
                """, (self.project_id,))
                # Overall: selesai jika minimal 1 platform selesai, error jika keduanya gagal
                conn.execute("""
                    UPDATE project_videos SET
                        status = CASE
                            WHEN status_shopee='selesai' OR status_tiktok='selesai' THEN 'selesai'
                            ELSE 'error'
                        END,
                        updated_at = datetime('now','localtime')
                    WHERE project_id=? AND status='proses'
                """, (self.project_id,))
                conn.commit()
            except Exception as e:
                self._log(f"⚠ cleanup error: {e}")
            finally:
                if conn: conn.close()

            ProjectRepo.update_status(self.project_id, "berhenti")

        self._log("✅ Proses dihentikan paksa. Video yang sedang proses → Error.")
        self._on_run_finished(0, 0)

    def _on_run_finished(self, success, error):
        from src.core.log_manager import LogManager
        self._refresh_timer.stop()
        if self.project_id:
            LogManager.instance().remove_worker(self.project_id)
        self.start_btn.setText("▶  Start")
        self.start_btn.setObjectName("btnSuccess")
        self.start_btn.style().unpolish(self.start_btn)
        self.start_btn.style().polish(self.start_btn)
        self.progress_bar.setRange(0,1); self.progress_bar.setValue(1)
        self.progress_bar.setVisible(False)
        self._refresh_stats(); self._load_table()

    # ── Data ─────────────────────────────────────
    def load_project(self, project_id, keep_filter=False):
        from src.core.log_manager import LogManager
        from datetime import datetime
        self.project_id = project_id
        if not keep_filter:
            self._filter = "antrian"
        self._update_filter_btns(self._filter)

        # Restore log dari LogManager
        self.log_text.clear()
        from src.core.log_manager import get_log_color
        for entry in LogManager.instance().get_logs(project_id):
            ts  = entry["ts"]
            msg = entry["msg"]
            color = get_log_color(msg)
            ts_colored  = f'<span style="color:#5a5c8a;">{ts}</span>'
            if color:
                msg_colored = f'<span style="color:{color};">{msg}</span>'
            else:
                msg_colored = msg
            self.log_text.append(f'{ts_colored} &nbsp;{msg_colored}')
        self.log_text.verticalScrollBar().setValue(
            self.log_text.verticalScrollBar().maximum())

        # Sync tombol Start/Stop dengan worker yang mungkin masih running
        lm = LogManager.instance()
        self._worker = lm.get_worker(project_id)
        if lm.is_running(project_id):
            self.start_btn.setText("⏹  Stop")
            self.start_btn.setObjectName("btnDanger")
            self.start_btn.style().unpolish(self.start_btn)
            self.start_btn.style().polish(self.start_btn)
            self.progress_bar.setRange(0,0); self.progress_bar.setVisible(True)
            self._refresh_timer.start()
        else:
            self.start_btn.setText("▶  Start")
            self.start_btn.setObjectName("btnSuccess")
            self.start_btn.style().unpolish(self.start_btn)
            self.start_btn.style().polish(self.start_btn)
            self.progress_bar.setRange(0,1); self.progress_bar.setValue(1)
            self.progress_bar.setVisible(False)
            self._refresh_timer.stop()

        self._refresh_stats(); self._load_table()

    def _refresh_stats(self):
        if not self.project_id: return
        p = ProjectRepo.get_by_id(self.project_id)
        if not p: return
        self.title_lbl.setText(f"Project : {p['name']}")
        self.dataset_lbl.setText(p.get("dataset_name") or "—")
        self.device_lbl.setText(p.get("device_serial") or "—")
        t = p.get("upload_target","shopee_tiktok")
        self.target_lbl.setText("Shopee & TikTok" if t == "shopee_tiktok" else "Shopee Saja")
        self._upload_target = t
        st = VideoRepo.get_stats_by_project(self.project_id)
        for key in self.FILTER_KEYS:
            count = st.get(key, 0)
            self._filter_btns[key].setText(f"{self.FILTER_LABEL[key]}  {count}")

    def _set_filter(self, key):
        self._filter = key; self._update_filter_btns(key); self._load_table()

    def _update_filter_btns(self, active):
        for k, btn in self._filter_btns.items():
            btn.setProperty("active","true" if k==active else "false")
            btn.style().unpolish(btn); btn.style().polish(btn)

    def _load_table(self):
        if not self.project_id: return
        p = ProjectRepo.get_by_id(self.project_id)
        if not p or not p.get("dataset_id"):
            self.table.setRowCount(0); return

        BADGE = {
            "antrian": ("Antrian","badgeAntrian"),
            "proses":  ("Proses", "badgeProses"),
            "selesai": ("Selesai","badgeSelesai"),
            "error":   ("Error",  "badgeError"),
        }
        is_dual = (self._upload_target == "shopee_tiktok")
        items = VideoRepo.get_by_project(self.project_id, self._filter)
        self.table.setRowCount(0)

        for item in items:
            r = self.table.rowCount(); self.table.insertRow(r)

            def cell(text, center=False):
                it = QTableWidgetItem(str(text) if text else "")
                it.setTextAlignment(
                    Qt.AlignmentFlag.AlignCenter if center else
                    (Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft))
                return it

            vr = item.get("video_result","")
            vr_item = QTableWidgetItem(vr[:24]+"..." if len(vr)>24 else vr)
            vr_item.setToolTip(vr)

            self.table.setItem(r,0,cell(item.get("no",""),True))
            self.table.setItem(r,1,cell(item.get("product_shopee","")))
            self.table.setItem(r,2,cell(item.get("caption_shopee","")))
            self.table.setItem(r,3,cell(item.get("caption_tiktok","")))
            self.table.setItem(r,4,cell(item.get("link_tiktok","")))
            self.table.setItem(r,5,cell(item.get("keranjang_tiktok","")))
            self.table.setItem(r,6,vr_item)

            # ── Helper buat badge cell ─────────────
            def make_badge_cell(status, platform, item_snap):
                """
                Jika status == error → QPushButton clickable (retry) + tooltip error.
                Selain itu → QLabel biasa.
                """
                s_text, s_obj = BADGE.get(status, ("Antrian","badgeAntrian"))
                w = QWidget(); lay = QHBoxLayout(w)
                lay.setContentsMargins(4,0,4,0); lay.setSpacing(0)

                err_msg = item_snap.get(f"error_{platform}", "")
                tooltip = f"❌ {err_msg}\n\nKlik untuk retry {platform.capitalize()}" \
                          if err_msg else f"Klik untuk retry {platform.capitalize()}"

                if status == "error":
                    btn = QPushButton(s_text)
                    btn.setObjectName(s_obj)
                    btn.setFixedHeight(26)
                    btn.setCursor(Qt.CursorShape.PointingHandCursor)
                    btn.setToolTip(tooltip)
                    btn.clicked.connect(
                        lambda _, i=item_snap, pl=platform: self._retry_platform(i, pl))
                    lay.addWidget(btn)
                else:
                    lbl = QLabel(s_text); lbl.setObjectName(s_obj)
                    lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
                    lay.addWidget(lbl)
                return w

            # Shopee badge (col 7)
            s_shopee = item.get("status_shopee","antrian")
            self.table.setCellWidget(r, 7, make_badge_cell(s_shopee, "shopee", item))

            # TikTok badge (col 8) — "—" jika shopee-only
            s_tiktok = item.get("status_tiktok","antrian")
            if not is_dual:
                w8 = QWidget(); l8 = QHBoxLayout(w8); l8.setContentsMargins(4,0,4,0)
                lbl8 = QLabel("—"); lbl8.setObjectName("badgeAntrian")
                lbl8.setAlignment(Qt.AlignmentFlag.AlignCenter); l8.addWidget(lbl8)
                self.table.setCellWidget(r, 8, w8)
            else:
                self.table.setCellWidget(r, 8, make_badge_cell(s_tiktok, "tiktok", item))

            vid_id = item["id"]

            # Edit (col 9)
            edit_btn = QPushButton("✏"); edit_btn.setObjectName("btnIcon")
            edit_btn.setFixedSize(32,28); edit_btn.setToolTip("Edit video")
            edit_btn.clicked.connect(lambda _, i=item: self._edit_video(i))
            ew = QWidget(); el = QHBoxLayout(ew); el.setContentsMargins(2,0,2,0); el.addWidget(edit_btn)
            self.table.setCellWidget(r,9,ew)

            # Delete (col 10)
            del_btn = QPushButton("🗑"); del_btn.setObjectName("btnIconDanger")
            del_btn.setFixedSize(32,28); del_btn.setToolTip("Hapus video")
            del_btn.clicked.connect(lambda _, vid=vid_id: self._delete_video(vid))
            dw = QWidget(); dl = QHBoxLayout(dw); dl.setContentsMargins(2,0,2,0); dl.addWidget(del_btn)
            self.table.setCellWidget(r,10,dw)

            self.table.setRowHeight(r,42)

    def _retry_platform(self, item: dict, platform: str):
        """Jalankan ulang 1 platform (shopee/tiktok) untuk 1 video."""
        from src.core.log_manager import LogManager
        if LogManager.instance().is_running(self.project_id):
            QMessageBox.warning(self, "Sedang Berjalan",
                "Tunggu proses utama selesai sebelum retry."); return

        p = ProjectRepo.get_by_id(self.project_id)
        device = p.get("device_serial") or None if p else None
        label  = platform.capitalize()

        self._log(f"\n{'─'*50}")
        self._log(f"🔄 Retry {label} — [{item.get('no')}] {item.get('product_shopee','-')}")

        # Set status platform → proses
        VideoRepo.update_status_by_project(
            self.project_id, item["id"], "proses",
            status_shopee = "proses" if platform == "shopee" else item.get("status_shopee","error"),
            status_tiktok = "proses" if platform == "tiktok" else item.get("status_tiktok","error"),
        )
        self._load_table()

        if not hasattr(self, "_retry_workers"):
            self._retry_workers = {}

        # Stop worker lama kalau masih running
        item_id = item["id"]
        worker_key = (self.project_id, item_id)
        if worker_key in self._retry_workers:
            old_worker = self._retry_workers[worker_key]
            if old_worker.isRunning():
                old_worker.stop()
                old_worker.terminate()
                old_worker.wait(2000)
            del self._retry_workers[worker_key]

        worker = RetryWorker(item, platform, device, project_id=self.project_id)
        self._retry_workers[worker_key] = worker

        import weakref
        _self = weakref.ref(self)
        _pid  = self.project_id
        def _on_retry_log(msg, pid=_pid):
            s = _self()
            if s is not None: s._log(msg, pid)
        def _on_retry_log2(msg):
            s = _self()
            if s is not None: s._safe_refresh()
        def _on_retry_done(ok, i=item, pl=platform, iid=item_id, pid=_pid):
            s = _self()
            if s is not None: s._on_retry_finished(ok, i, pl, iid, pid)
        worker.log.connect(_on_retry_log)
        worker.log.connect(_on_retry_log2)
        worker.finished.connect(_on_retry_done)

        # Daftarkan ke LogManager agar muncul di Process Monitor & bisa di-Stop
        from src.core.log_manager import LogManager
        LogManager.instance().set_worker(self.project_id, worker)

        worker.start()
        self.progress_bar.setRange(0,0); self.progress_bar.setVisible(True)

    def _on_retry_finished(self, ok: bool, item: dict, platform: str, item_id: int = None, project_id: int = None):
        # Hapus dari LogManager & registry
        from src.core.log_manager import LogManager
        pid = project_id or self.project_id
        LogManager.instance().remove_worker(pid)
        if hasattr(self, "_retry_workers"):
            worker_key = (pid, item_id)
            if worker_key in self._retry_workers:
                del self._retry_workers[worker_key]

        self.progress_bar.setRange(0,1); self.progress_bar.setValue(1)
        label = platform.capitalize()

        # Ambil status terbaru dari DB (bukan snapshot lama di item)
        from src.core.database import get_connection
        conn = get_connection()
        row = conn.execute(
            "SELECT status_shopee, status_tiktok FROM project_videos WHERE project_id=? AND video_id=?",
            (pid, item["id"])
        ).fetchone()
        conn.close()

        s_shopee = row["status_shopee"] if row else item.get("status_shopee", "error")
        s_tiktok = row["status_tiktok"] if row else item.get("status_tiktok", "error")

        # Override platform yang baru selesai di-retry
        new_platform_status = "selesai" if ok else "error"
        if platform == "shopee":
            s_shopee = new_platform_status
        else:
            s_tiktok = new_platform_status

        # Overall: selesai jika minimal 1 sukses
        overall = "selesai" if (s_shopee == "selesai" or s_tiktok == "selesai") else "error"

        VideoRepo.update_status_by_project(
            pid, item["id"], overall,
            status_shopee = s_shopee,
            status_tiktok = s_tiktok,
        )

        if ok:
            self._log(f"✅ Retry {label} berhasil!", pid)
        else:
            self._log(f"❌ Retry {label} gagal.", pid)

        self._refresh_stats(); self._load_table()

    def _edit_video(self, item):
        dlg = VideoEditDialog(self, item, project_id=self.project_id)
        if not dlg.exec(): return
        data = dlg.get_data()
        try:
            from src.core.database import get_connection
            conn = get_connection()
            conn.execute("""
                UPDATE video_items SET caption_shopee=?,product_shopee=?,caption_tiktok=?,
                    link_tiktok=?,keranjang_tiktok=?,video_result=? WHERE id=?
            """, (data["caption_shopee"],data["product_shopee"],data["caption_tiktok"],
                  data["link_tiktok"],data["keranjang_tiktok"],data["video_result"],item["id"]))
            # Update status shopee & tiktok + hitung overall status
            s_shopee = data["status_shopee"]
            s_tiktok = data["status_tiktok"]
            if s_shopee == "selesai" or s_tiktok == "selesai":
                overall = "selesai"
            elif s_shopee == "proses" or s_tiktok == "proses":
                overall = "proses"
            elif s_shopee == "error" and s_tiktok == "error":
                overall = "error"
            elif s_shopee == "antrian" and s_tiktok == "antrian":
                overall = "antrian"
            else:
                overall = "error"
            conn.execute("""
                UPDATE project_videos SET
                    status=?, status_shopee=?, status_tiktok=?,
                    updated_at=datetime('now','localtime')
                WHERE video_id=? AND project_id=?
            """, (overall, s_shopee, s_tiktok, item["id"], self.project_id))
            conn.commit(); conn.close()
        except Exception as e:
            QMessageBox.warning(self,"Error",f"Gagal simpan: {e}")
        self._load_table()

    def _delete_video(self, video_id):
        if QMessageBox.question(self,"Hapus Video","Hapus video ini dari dataset?\n(Tidak bisa di-undo)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        ) == QMessageBox.StandardButton.Yes:
            try:
                from src.core.database import get_connection
                conn = get_connection()
                conn.execute("DELETE FROM project_videos WHERE video_id=?", (video_id,))
                conn.execute("DELETE FROM video_items WHERE id=?", (video_id,))
                conn.commit(); conn.close()
            except Exception as e:
                QMessageBox.warning(self,"Error",f"Gagal hapus: {e}")
            self._refresh_stats(); self._load_table()


# ══════════════════════════════════════════════════
#  Project Page (wrapper stack)
# ══════════════════════════════════════════════════
class ProjectPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self); layout.setContentsMargins(0,0,0,0)
        self.stack       = QStackedWidget()
        self.list_page   = ProjectListPage()
        self.detail_page = ProjectDetailPage()
        self.stack.addWidget(self.list_page); self.stack.addWidget(self.detail_page)
        self._current_ids = []
        self._current_idx = -1
        self._current_list = []
        self.list_page.open_project.connect(self._open_detail)
        self.detail_page.go_back.connect(self._go_back)
        self.detail_page.go_prev.connect(self._go_prev)
        self.detail_page.go_next.connect(self._go_next)
        layout.addWidget(self.stack)

    def _open_detail(self, project_id):
        self._open_project_by_id(project_id)
        self.stack.setCurrentWidget(self.detail_page)

    def _open_project_by_id(self, project_id, keep_filter=False):
        """Load project dan update state prev/next berdasarkan list saat ini."""
        self._current_list = self.list_page._get_current_list()
        ids = [p["id"] for p in self._current_list]
        idx = ids.index(project_id) if project_id in ids else -1
        self.detail_page.load_project(project_id, keep_filter=keep_filter)
        self.detail_page.set_nav_buttons(
            has_prev = idx > 0,
            has_next = idx < len(ids) - 1
        )
        self._current_ids = ids
        self._current_idx = idx

    def _go_prev(self):
        if self._current_idx > 0:
            self._current_idx -= 1
            pid = self._current_ids[self._current_idx]
            self._open_project_by_id(pid, keep_filter=True)

    def _go_next(self):
        if self._current_idx < len(self._current_ids) - 1:
            self._current_idx += 1
            pid = self._current_ids[self._current_idx]
            self._open_project_by_id(pid, keep_filter=True)

    def _go_back(self):
        self.list_page.refresh()
        self.stack.setCurrentWidget(self.list_page)

    def refresh(self):
        self.list_page.refresh()
        self.stack.setCurrentWidget(self.list_page)
