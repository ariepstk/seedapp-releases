"""
LogManager — Global log store per project_id
Mendukung 2 mode worker:
  - SubprocessWorker : baca log dari file (Opsi B)
  - QThread legacy   : terima log via append() langsung
"""
import os
import json
from datetime import datetime
from typing import Dict, List, Callable, Optional

# Folder logs — sama lokasi dengan crash.log
LOGS_DIR = os.path.join(os.path.dirname(__file__), '..', '..', 'logs')


def log_file_path(project_id: int) -> str:
    os.makedirs(LOGS_DIR, exist_ok=True)
    return os.path.join(LOGS_DIR, f"log_{project_id}.txt")


def stop_file_path(project_id: int) -> str:
    os.makedirs(LOGS_DIR, exist_ok=True)
    return os.path.join(LOGS_DIR, f"stop_{project_id}.flag")


class LogManager:
    _instance = None

    def __init__(self):
        self._logs:             Dict[int, List[dict]] = {}
        self._workers:          Dict[int, object]     = {}
        self._all_workers:      List[object]          = []
        self._listeners:        Dict[int, List[Callable]] = {}
        self._global_listeners: List[Callable]        = []

    @classmethod
    def instance(cls) -> "LogManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def append(self, project_id: int, msg: str):
        """Tambah log entry langsung (legacy QThread mode)."""
        ts = datetime.now().strftime("%H:%M:%S")
        entry = {"ts": ts, "msg": msg}
        if project_id not in self._logs:
            self._logs[project_id] = []
        self._logs[project_id].append(entry)
        self._notify(project_id, entry)

    def append_from_file(self, project_id: int, ts: str, msg: str):
        """Tambah log entry yang sudah punya ts (dari file polling)."""
        entry = {"ts": ts, "msg": msg}
        if project_id not in self._logs:
            self._logs[project_id] = []
        self._logs[project_id].append(entry)
        self._notify(project_id, entry)

    def _notify(self, project_id: int, entry: dict):
        try:
            from PyQt6.QtCore import QTimer
            for cb in list(self._listeners.get(project_id, [])):
                QTimer.singleShot(0, lambda c=cb, e=entry: c(e))
            for cb in list(self._global_listeners):
                QTimer.singleShot(0, lambda c=cb, pid=project_id, e=entry: c(pid, e))
        except ImportError:
            for cb in list(self._listeners.get(project_id, [])):
                try: cb(entry)
                except: pass
            for cb in list(self._global_listeners):
                try: cb(project_id, entry)
                except: pass

    def get_logs(self, project_id: int) -> List[dict]:
        return self._logs.get(project_id, [])

    def clear_logs(self, project_id: int):
        self._logs[project_id] = []

    # ── Worker tracking ───────────────────────
    def set_worker(self, project_id: int, worker):
        self._workers[project_id] = worker
        if worker not in self._all_workers:
            self._all_workers.append(worker)

    def get_worker(self, project_id: int):
        return self._workers.get(project_id)

    def remove_worker(self, project_id: int):
        w = self._workers.pop(project_id, None)
        if w is not None:
            try:
                if not w.is_alive():
                    try: self._all_workers.remove(w)
                    except ValueError: pass
            except Exception:
                try: self._all_workers.remove(w)
                except ValueError: pass
        self._all_workers = [w for w in self._all_workers if _is_alive(w)]

    def is_running(self, project_id: int) -> bool:
        w = self._workers.get(project_id)
        if w is None:
            return False
        return _is_alive(w)

    def running_projects(self) -> List[int]:
        return [pid for pid, w in self._workers.items() if _is_alive(w)]

    # ── Listeners ─────────────────────────────
    def subscribe(self, project_id: int, cb: Callable):
        if project_id not in self._listeners:
            self._listeners[project_id] = []
        if cb not in self._listeners[project_id]:
            self._listeners[project_id].append(cb)

    def unsubscribe(self, project_id: int, cb: Callable):
        if project_id in self._listeners:
            self._listeners[project_id] = [
                c for c in self._listeners[project_id] if c != cb]

    def subscribe_global(self, cb: Callable):
        if cb not in self._global_listeners:
            self._global_listeners.append(cb)

    def unsubscribe_global(self, cb: Callable):
        self._global_listeners = [c for c in self._global_listeners if c != cb]


def _is_alive(w) -> bool:
    """Cek apakah worker masih running — support QThread dan SubprocessWorker."""
    try:
        # SubprocessWorker
        return w.is_alive()
    except AttributeError:
        pass
    try:
        # QThread
        return w.isRunning()
    except Exception:
        return False


def get_log_color(msg: str) -> str:
    if "❌" in msg or "FAIL" in msg or ("error" in msg.lower() and "✅" not in msg):
        return "#ff5555"
    if ("— ✅ Selesai" in msg
            or "🛍 Shopee" in msg and "berhasil" in msg
            or "🎵 TikTok" in msg and "berhasil" in msg
            or "🎯 Target" in msg):
        return "#4cde7a"
    return None
