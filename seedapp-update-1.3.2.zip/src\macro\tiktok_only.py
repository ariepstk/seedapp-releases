"""
TikTok Macro - tiktok_only.py
Download video → Push ke HP → Upload TikTok → Force close TikTok
Cleanup (hapus file PC + HP) dilakukan oleh runner setelah kedua flow selesai
"""

import time
import random
import os
import requests
from src.core.debug_logger import dlog
import uiautomator2 as u2

import unicodedata as _ud
import re as _re_strip


def _strip_symbols(text: str) -> str:
    """Hapus simbol/emoji/special char dari text input TikTok.
    Keep: huruf (Latin/aksen/dll), angka, spasi, dash, dot.
    Drop: emoji, !@#$%^&*()_+={}[]|\\:;\"'<>?/~` dan punctuation lain.
    """
    if not text:
        return ""
    out = []
    for ch in str(text):
        cat = _ud.category(ch)
        # L* = letters (semua skrip), N* = numbers, Zs = space — keep
        # Plus manual whitelist: dash, dot
        if cat[0] in ("L", "N") or cat == "Zs" or ch in "-.":
            out.append(ch)
    cleaned = "".join(out)
    # Collapse multiple spaces → 1
    cleaned = _re_strip.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def type_text(d, text: str, chunk: int = 5, strip_symbols: bool = True):
    """Ketik teks per 5 karakter seperti manusia mengetik.
    strip_symbols=True (default): hapus simbol/emoji otomatis sebelum ketik.
    Set False untuk URL atau text yg butuh simbol original.
    """
    import random as _r
    text = str(text)
    if strip_symbols:
        text = _strip_symbols(text)
    for i in range(0, len(text), chunk):
        d.send_keys(text[i:i+chunk])
        time.sleep(_r.uniform(0.01, 0.03))



TIKTOK_PACKAGE  = "com.ss.android.ugc.trill"
DOWNLOAD_DIR_PC = "temp"
DOWNLOAD_DIR_HP = "/sdcard/DCIM/"


def delay(log, seconds, label=""):
    if seconds <= 0: return
    if log and label:
        for i in range(seconds, 0, -1):
            log(f"⏳ {label} {i}s...")
            time.sleep(1)
    else:
        time.sleep(seconds)


# ===============================
# DOWNLOAD VIDEO KE PC
# ===============================
def download_video(video_url, item_no, log=None, force_download=False):
    """
    Download {item_no}_tiktok.mp4 → upscale → copy → {item_no}_shopee.mp4
    Cache: tiktok adalah master, shopee adalah copy.
    """
    import shutil
    if not os.path.exists(DOWNLOAD_DIR_PC):
        os.makedirs(DOWNLOAD_DIR_PC)

    tiktok_filename = f"{item_no}_tiktok.mp4"
    shopee_filename = f"{item_no}_shopee.mp4"
    tiktok_path = os.path.join(DOWNLOAD_DIR_PC, tiktok_filename)
    shopee_path = os.path.join(DOWNLOAD_DIR_PC, shopee_filename)

    def _is_valid(path):
        return os.path.exists(path) and os.path.getsize(path) / (1024*1024) >= 0.5

    # Force download — hapus cache lama
    if force_download:
        for p in [tiktok_path, shopee_path]:
            if os.path.exists(p):
                os.remove(p)

    # Cek cache tiktok
    if not force_download and _is_valid(tiktok_path):
        if log: log(f"📋 Cache tiktok ada, skip download")
        # Pastikan shopee juga ada
        if not _is_valid(shopee_path):
            if log: log(f"📋 Copy tiktok → shopee...")
            shutil.copy2(tiktok_path, shopee_path)
        return tiktok_path, tiktok_filename
    elif os.path.exists(tiktok_path):
        if log: log(f"⚠ Cache tiktok corrupt, hapus...")
        os.remove(tiktok_path)

    # Hapus shopee corrupt juga
    if os.path.exists(shopee_path) and not _is_valid(shopee_path):
        os.remove(shopee_path)

    # Download tiktok dari GDrive dengan retry
    max_attempt = 10
    for attempt in range(1, max_attempt + 1):
        try:
            if "drive.google.com" in video_url or "drive.usercontent.google.com" in video_url:
                from src.macro.media_helper import _download_gdrive
                _download_gdrive(video_url, tiktok_path)
            else:
                r = requests.get(video_url, stream=True, timeout=60)
                r.raise_for_status()
                with open(tiktok_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk: f.write(chunk)

            size_mb = os.path.getsize(tiktok_path) / (1024 * 1024)
            if size_mb < 0.5:
                raise Exception("File terlalu kecil, kemungkinan corrupt")
            break

        except Exception as e:
            if attempt >= max_attempt:
                raise Exception(f"Download gagal setelah {max_attempt}x percobaan: {e}")
            delay_sec = random.randint(10, 15)
            if log: log(f"⚠ Download gagal (percobaan {attempt}/{max_attempt}), retry dalam {delay_sec}s... ({e})")
            time.sleep(delay_sec)

    # Copy tiktok → shopee
    if log: log(f"📋 Copy tiktok → shopee...")
    shutil.copy2(tiktok_path, shopee_path)

    return tiktok_path, tiktok_filename


# ===============================
# UPSCALE VIDEO (reuse dari shopee_only)
# ===============================
def upscale_if_needed(local_path, log=None, target_w=1080, target_h=1920):
    from src.macro.shopee_only import upscale_if_needed as _upscale
    return _upscale(local_path, log, target_w, target_h)


# ===============================
# PUSH VIDEO KE HP
# ===============================
def push_to_device(d, local_path, filename, log=None):
    from src.macro.media_helper import push_and_wait
    # Hapus semua file mp4/mov di DCIM dulu — prevent video lama ikut ke gallery
    d.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mp4' -delete")
    d.shell("find /sdcard/DCIM -maxdepth 2 -name '*.mov' -delete")
    time.sleep(1)
    push_and_wait(d, local_path, filename, log=log)


# ===============================
# CONNECT + OPEN TIKTOK
# ===============================
def connect_device(serial, log_fn=None):
    return u2.connect(serial) if serial else u2.connect()

def open_tiktok(d, log=None):
    d.shell(f"am force-stop {TIKTOK_PACKAGE}")
    time.sleep(2)
    result = d.shell(f"monkey -p {TIKTOK_PACKAGE} -c android.intent.category.LAUNCHER 1")
    if "Events injected: 1" not in result.output:
        raise Exception("TikTok gagal dibuka (package salah?)")
    time.sleep(5)

def click_plus_button(d):
    if d(description="Create").exists: d(description="Create").click(); return
    if d(description="Post").exists:   d(description="Post").click(); return
    w, h = d.window_size(); d.click(int(w*0.5), int(h*0.92))

def click_gallery(d, log=None):
    """
    Klik thumbnail gallery TikTok.
    Versi A: ImageView kanan bawah (cx > 70%, cy > 60%)
    Versi B: FrameLayout kiri bawah (cx < 30%, cy > 80%)
    Validasi: gallery terbuka jika muncul text Recents atau Videos
    """
    w, h = d.window_size()

    # Versi A — ImageView kanan bawah
    candidates = d(className="android.widget.ImageView")
    for i in range(len(candidates)):
        try:
            info   = candidates[i].info
            bounds = info.get("bounds")
            if not bounds: continue
            cx     = (bounds["left"] + bounds["right"])  // 2
            cy     = (bounds["top"]  + bounds["bottom"]) // 2
            width  = bounds["right"] - bounds["left"]
            if cx > w * 0.7 and cy > h * 0.6 and width < w * 0.4:
                d.click(cx, cy)
                time.sleep(2)
                if d(text="Recents").exists or d(text="Videos").exists:
                        return
        except: pass

    # Versi B — FrameLayout kiri bawah
    candidates = d(className="android.widget.FrameLayout")
    for i in range(len(candidates)):
        try:
            info   = candidates[i].info
            bounds = info.get("bounds")
            if not bounds: continue
            cx     = (bounds["left"] + bounds["right"])  // 2
            cy     = (bounds["top"]  + bounds["bottom"]) // 2
            width  = bounds["right"] - bounds["left"]
            if cx < w * 0.3 and cy > h * 0.8 and width < w * 0.4:
                d.click(cx, cy)
                time.sleep(2)
                if d(text="Recents").exists or d(text="Videos").exists:
                        return
        except: pass

    raise Exception("Thumbnail gallery tidak ditemukan")

def click_video_tab(d):
    if d(text="Videos").wait(timeout=5): d(text="Videos").click(); return
    raise Exception("Tab Videos tidak ditemukan")

def disable_select_multiple_if_active(d, log=None):
    """Matikan 'Select multiple' jika aktif (ditandai munculnya tombol Next pink)."""
    time.sleep(1)
    # Kalau ada Next → Select multiple aktif → matikan
    if d(text="Next").exists:
        if d(text="Select multiple").exists:
            d(text="Select multiple").click()
            time.sleep(1)
    # Kalau tidak ada Next → Select multiple mati, skip

def select_first_video(d):
    videos = d.xpath("//*[contains(@text,'00:')]").all()
    if not videos: raise Exception("Video tidak ditemukan")
    bounds = videos[0].info.get("bounds")
    d.click((bounds["left"]+bounds["right"])//2, (bounds["top"]+bounds["bottom"])//2)

def _is_editor_ready(d) -> bool:
    """Cek apakah sudah di halaman editor TikTok."""
    if d(textContains="AutoCut").exists:
        return True
    if d(descriptionContains="music").exists:
        return True
    if d(descriptionContains="sound").exists:
        return True
    if d(descriptionContains="Music").exists:
        return True
    if d(descriptionContains="Sound").exists:
        return True
    return False

def wait_editor_and_click_next_if_needed(d, log=None):
    """
    Setelah select_first_video, tunggu sampai halaman editor muncul.
    Deteksi via 'AutoCut' atau icon musik/sound di sound bar atas.
    Kalau belum muncul tapi ada tombol Next → klik Next dulu.
    """
    for attempt in range(3):
        time.sleep(3)
        if _is_editor_ready(d):
            return
        # Belum di editor, cek ada Next?
        if d(text="Next").exists:
            d(text="Next").click()
            time.sleep(8)
            if _is_editor_ready(d):
                return
    # Fallback: lanjut saja walau tidak terdeteksi

def click_next(d):
    if d(text="Next").wait(timeout=5):       d(text="Next").click(); return
    if d(description="Next").exists:          d(description="Next").click(); return
    raise Exception("Tombol Next tidak ditemukan")

def click_sound_top(d, log=None):
    w, h = d.window_size()
    d.click(int(w*0.5), int(h*0.08)); time.sleep(2)

def click_original_mute(d, log=None):
    if d(text="Original").exists: d(text="Original").click(); return
    raise Exception("Tombol Original tidak ditemukan")

def click_favorites(d, log=None):
    if d(text="Favorites").exists: d(text="Favorites").click(); return
    raise Exception("Tab Favorites tidak ditemukan")

def click_mute_sound(d, log=None):
    """Klik tombol 'Sound' di bottom row untuk mute layer musik."""
    el = d(resourceId="com.ss.android.ugc.trill:id/ui7")
    if el.exists:
        el.click()
        return
    if d(text="Sound").exists:
        d(text="Sound").click()
        return
    raise Exception("Tombol Mute Sound tidak ditemukan")

def click_pencarian(d, log=None):
    """Klik tombol Search (kaca pembesar) di sound popup."""
    if d(description="Search").exists:
        d(description="Search").click()
        return
    el = d(resourceId="com.ss.android.ugc.trill:id/bm0")
    if el.exists:
        el.click()
        return
    raise Exception("Tombol Pencarian (Search) tidak ditemukan")

def click_dropdown_kategori(d, log=None):
    """Klik dropdown 'Down' arrow di header Sounds untuk buka kategori."""
    el = d(resourceId="com.ss.android.ugc.trill:id/l50")
    if el.exists:
        el.click()
        return
    if d(description="Down").exists:
        d(description="Down").click()
        return
    raise Exception("Dropdown kategori (Down arrow) tidak ditemukan")

def click_commercial_sounds(d, log=None):
    """Pilih kategori 'Commercial Sounds' dari dropdown."""
    if d(text="Commercial Sounds").exists:
        d(text="Commercial Sounds").click()
        return
    el = d(resourceId="com.ss.android.ugc.trill:id/yhd")
    if el.exists:
        el.click()
        return
    raise Exception("Pilihan Commercial Sounds tidak ditemukan")

def input_search_lagu(d, query, log=None):
    """Klik search bar, ketik query, lalu tekan enter."""
    el = d(resourceId="com.ss.android.ugc.trill:id/gpy")
    if not el.exists:
        el = d(text="Search")
    if not el.exists:
        raise Exception("Search bar tidak ditemukan")
    el.click()
    time.sleep(1)

    try:
        d.clear_text()
    except Exception:
        pass
    time.sleep(0.5)

    # Strip simbol biar search lebih clean (search lagu gak butuh emoji/special char)
    query_clean = _strip_symbols(query) if query else ""

    # Set text one-shot biar gak ke-chunk
    el2 = d(resourceId="com.ss.android.ugc.trill:id/gpy")
    if el2.exists:
        try:
            el2.set_text(query_clean)
        except Exception:
            d.send_keys(query_clean)
    else:
        d.send_keys(query_clean)
    time.sleep(1)
    d.press("enter")
    if log: log(f"🔍 Search: {query_clean!r}")

def pick_random_song_from_search(d, log=None):
    """Pilih lagu random dari hasil search.
    Random scroll dulu (0/1/2x, equal probability), lalu pilih random dari 8 yang visible.
    """
    # Random scroll 0/1/2x sebelum pilih (variasi natural)
    scroll_count = random.choice([0, 1, 2])
    if scroll_count > 0:
        if log: log(f"📜 Scroll {scroll_count}x dulu...")
        for _ in range(scroll_count):
            d.swipe_ext("up", scale=0.7)  # 70% layar
            time.sleep(1.2)

    # Setelah scroll, RecyclerView re-render — xpath return items yang sekarang visible
    songs = d.xpath("//androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout").all()
    if not songs:
        raise Exception("List lagu hasil search tidak ditemukan")

    # Cap 8 (sesuai jumlah lagu visible per layar)
    visible_count = min(8, len(songs))
    chosen_idx = random.randint(0, visible_count - 1)
    if log: log(f"🎵 Pilih lagu #{chosen_idx + 1} dari {visible_count} terdeteksi (scroll {scroll_count}x)")

    # Klik checkmark (ViewGroup[2]) dari song yang dipilih
    checkmark_xpath = (
        f"//androidx.recyclerview.widget.RecyclerView"
        f"/android.widget.FrameLayout[{chosen_idx + 1}]"
        f"/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[2]"
    )
    el = d.xpath(checkmark_xpath)
    if el.exists:
        el.click()
        return

    raise Exception(f"Checkmark song #{chosen_idx + 1} tidak ditemukan")

def scroll_and_pick_random_song(d, log=None):
    # Random swipe 1-3x agar lagu yang terpilih lebih variatif
    swipe_count = random.randint(1, 3)
    for _ in range(swipe_count):
        d.swipe_ext("up", scale=0.6); time.sleep(2)
    songs = d.xpath("//*[contains(@text,' - original') or contains(@text,'posts')]").all()
    if not songs: raise Exception("List lagu tidak ditemukan")
    song   = random.choice(songs)
    bounds = song.info.get("bounds")
    x = (bounds["left"]+bounds["right"])//2
    y = (bounds["top"]+bounds["bottom"])//2
    d.click(x, y)

def close_sound_popup(d, log=None):
    w, h = d.window_size(); d.click(int(w*0.5), int(h*0.2))

def click_next_editor(d, log=None):
    if d(text="Next").exists: d(text="Next").click(); return
    raise Exception("Tombol Next tidak ditemukan")

def click_add_description(d, log=None):
    if d(textContains="Add description").exists: d(textContains="Add description").click(); return
    raise Exception("Field Add description tidak ditemukan")

def input_caption_tiktok(d, caption, log=None):
    d.clear_text(); type_text(d, caption); d.press("enter")

def click_edit_cover(d, log=None):
    if d(textContains="Edit cover").exists: d(textContains="Edit cover").click(); return
    raise Exception("Tombol Edit cover tidak ditemukan")

def click_random_frame(d):
    w, h = d.window_size(); d.click(int(w*0.5), int(h*0.75))

def click_save_cover(d):
    if d(text="Save").exists: d(text="Save").click()

def press_enter(d, log=None):
    if log: log("↩ Press Enter")
    d.press("enter"); time.sleep(1)

def click_add_link(d):
    if d(textContains="Add link").exists: d(textContains="Add link").click()

def _is_product_blocked(d) -> bool:
    """Cek apakah Product di Add link popup grayed out / blocked (perlu Replace sound)."""
    return (
        d(resourceId="com.ss.android.ugc.trill:id/yx8").exists or
        d(textContains="Replace sound").exists or
        d(textContains="Use commercial sound").exists
    )

def _click_replace_sound(d):
    """Klik tombol Replace sound > di popup Add link. Return True jika ditemukan, False jika tidak."""
    els = d.xpath('//*[contains(@text,"Use commercial")]').all()
    if not els:
        return False
    bounds = els[0].bounds  # (left, top, right, bottom)
    x = bounds[0] + 50     # 50px dari tepi kiri = area "Replace sound >"
    h = bounds[3] - bounds[1]
    y = bounds[1] + int(h * 0.75)  # 75% dari atas = baris bawah "Replace sound >"
    d.touch.down(x, y).sleep(0.2).up(x, y)
    time.sleep(3)
    return True

def _click_favorites_if_needed(d):
    """Klik tab Favorites hanya jika belum aktif."""
    if d(text="Favorites").exists:
        d(text="Favorites").click(); time.sleep(2)

def click_product_with_replace_sound_retry(d, log=None, max_retry=10):
    """
    Klik Product di Add link popup.
    Jika blocked (Use commercial sound / Replace sound) → ganti lagu → retry max 3x.
    """
    for attempt in range(max_retry + 1):
        # Cek apakah product blocked
        if _is_product_blocked(d):
            if attempt >= max_retry:
                raise Exception(f"Product masih blocked setelah {max_retry}x ganti lagu")
            if log: log(f"⚠ Sound blocked, ganti lagu (percobaan {attempt+1}/{max_retry})...")
            replaced = _click_replace_sound(d)
            if not replaced:
                # Replace sound tidak ada → product sudah aktif, langsung klik Product
                if log: log("✅ Replace sound tidak ditemukan, product sudah aktif, lanjut...")
                if d(text="Product").exists:
                    d(text="Product").click(); time.sleep(10); return
                raise Exception("Tombol Product tidak ditemukan setelah replace sound")
            click_sound_top(d, log);              time.sleep(3)
            _click_favorites_if_needed(d);        time.sleep(4)
            scroll_and_pick_random_song(d, log);  time.sleep(4)
            close_sound_popup(d, log);            time.sleep(7)
            click_next_editor(d, log);            time.sleep(5)
            # Buka Add link lagi
            click_add_link(d);                    time.sleep(2)
            continue
        # Product aktif → klik
        if d(text="Product").exists:
            d(text="Product").click(); time.sleep(10); return
        raise Exception("Tombol Product tidak ditemukan")

def click_product_option(d):
    if d(text="Product").exists: d(text="Product").click()

def click_add_more_products(d, log=None):
    obj = d(textContains="Add more products")
    if obj.exists: obj.click(); time.sleep(2); return
    node = d.xpath("//*[contains(@text,'Add more products')]")
    if node.exists:
        el = node.get(); bounds = el.info["bounds"]
        d.click((bounds["left"]+bounds["right"])//2, (bounds["top"]+bounds["bottom"])//2)
        time.sleep(2); return
    w, h = d.window_size()
    d.click(int(w*0.5), int(h*0.88)); time.sleep(2)

def click_product_marketplace(d, log=None):
    obj = d(textContains="Product Marketplace")
    if obj.exists: obj.click(); time.sleep(2); return
    node = d.xpath("//*[contains(@text,'Product Marketplace')]")
    if node.exists:
        el = node.get(); bounds = el.info["bounds"]
        d.click((bounds["left"]+bounds["right"])//2, (bounds["top"]+bounds["bottom"])//2)
        time.sleep(2); return
    w, h = d.window_size()
    d.click(int(w*0.5), int(h*0.75)); time.sleep(2)

def search_marketplace(d, link_tiktok, log=None):
    if log: log("🔎 Klik kolom search (tengah)...")
    w, h = d.window_size()
    d.click(int(w*0.45), int(h*0.14)); time.sleep(5)
    text = str(link_tiktok) if link_tiktok is not None else ""
    if log: log(f"📋 Paste Link_TikTok: {text}")
    d.clear_text(); time.sleep(1); type_text(d, text)
    time.sleep(1); d.press("enter"); time.sleep(5)

def _check_add_status(d):
    """
    Cek status tombol Add di layar pakai exact match content-desc.
    Return: 'add'   jika ' Add,button' tersedia
            'added' jika ' disabled,Added,button' (sudah ter-add)
            'none'  jika tidak ada sama sekali
    """
    # Exact match Add (dengan/tanpa spasi di depan)
    add_nodes = d.xpath('//*[@content-desc=" Add,button"]').all()
    if not add_nodes:
        add_nodes = d.xpath('//*[@content-desc="Add,button"]').all()
    if add_nodes:
        return "add"

    # Exact match Added/disabled (dengan/tanpa spasi di depan)
    added_nodes = d.xpath('//*[@content-desc=" disabled,Added,button"]').all()
    if not added_nodes:
        added_nodes = d.xpath('//*[@content-desc="disabled,Added,button"]').all()
    if added_nodes:
        return "added"

    return "none"

def _click_add_button(d, log=None):
    """Klik tombol Add pertama via exact match content-desc."""
    nodes = d.xpath('//*[@content-desc=" Add,button"]').all()
    if not nodes:
        nodes = d.xpath('//*[@content-desc="Add,button"]').all()
    if not nodes:
        raise Exception("Tombol Add tidak ditemukan")
    bounds = nodes[0].info["bounds"]
    x = (bounds["left"] + bounds["right"])  // 2
    y = (bounds["top"]  + bounds["bottom"]) // 2
    d.click(x, y); time.sleep(2)

def search_and_add_product(d, link_tiktok, product_shopee=None, log=None):
    """
    Cari produk di marketplace TikTok pakai link_tiktok saja.
    - Add button  → klik → return
    - Added/none  → raise Exception
    """
    w, h = d.window_size()

    text1 = str(link_tiktok).lstrip("'") if link_tiktok else ""
    time.sleep(5)
    if d.xpath("//android.widget.EditText").exists:
        edit = d.xpath("//android.widget.EditText").get()
        edit.click()
        time.sleep(5)  # ← jeda 5 detik biar input field fully loaded & focused
        # Pakai set_text (one-shot, no chunk drop) + clear dulu biar bersih
        try:
            d.clear_text()
        except Exception:
            pass
        try:
            edit.set_text(text1)
        except Exception:
            # Fallback ke send_keys full text (bukan loop chunk)
            d.send_keys(text1)
    else:
        d.click(int(w*0.45), int(h*0.14))
        time.sleep(5)
        try: d.clear_text()
        except Exception: pass
        d.send_keys(text1)
    time.sleep(1); d.press("enter"); time.sleep(10)

    status = _check_add_status(d)
    if status == "add":
        if log: log(f"✅ Tombol Add ditemukan")
        _click_add_button(d, log)
        return
    elif status == "added":
        raise Exception("Produk sudah ter-add (disabled)")
    else:
        raise Exception("Tombol Add tidak ditemukan")

def confirm_add_popup_if_exist(d, log=None):
    """
    Klik tombol Add di popup 'Add product to video?' kalau muncul. Ada 2 varian.
    Deteksi via ScrollView 'Make sure you...' karena tombol Add tidak punya element text.
    Klik Add = tepat di bawah ScrollView tersebut.
    """
    time.sleep(2)
    nodes = d.xpath("//android.widget.ScrollView").all()
    make_sure = None
    for node in nodes:
        try:
            bounds = node.info.get("bounds")
            if bounds:
                make_sure = bounds
                break
        except: pass

    if not make_sure:
            return

    # Tombol Add tepat di bawah ScrollView
    x = (make_sure["left"] + make_sure["right"]) // 2
    y = make_sure["bottom"] + 60  # offset ke tengah tombol Add

    d.click(x, y)
    time.sleep(2)

def click_add_button(d, log=None):
    time.sleep(2)
    nodes = d.xpath("//*[contains(@text,'Add')]").all()
    if not nodes: nodes = d.xpath("//*[contains(@content-desc,'Add')]").all()
    if not nodes: raise Exception("Tombol Add tidak ditemukan")
    bounds = nodes[0].info["bounds"]
    x = (bounds["left"]+bounds["right"])//2
    y = (bounds["top"]+bounds["bottom"])//2
    d.click(x, y); time.sleep(2)

def replace_product_name(d, new_text, log=None):
    if not new_text: return
    # Coba EditText dulu, fallback ke content-desc
    node = d.xpath("//android.widget.EditText")
    if not node.exists:
        node = d.xpath('//*[@content-desc="edit_anchor_name_input"]')
    if node.exists:
        el = node.get(); el.click()
        time.sleep(5)
        d.clear_text(); type_text(d, new_text)
        d.press("enter"); time.sleep(1); return
    if log: log("⚠ Field rename product tidak ditemukan, lanjut...")

def press_enter2(d, log=None):
    d.press("enter"); time.sleep(1)

def click_add_button2(d, log=None):
    w, h = d.window_size()
    d.click(int(w*0.5), int(h*0.88)); time.sleep(2)

def click_post(d, log=None):
    time.sleep(3)  # tunggu halaman stabil setelah add produk
    if d(text="Post").exists:
        d(text="Post").click(); time.sleep(2); return
    if d(description="Post").exists:
        d(description="Post").click(); time.sleep(2); return
    raise Exception("Tombol Post tidak ditemukan")


# ===============================
# MAIN ENTRY
# ===============================
def run_upload_flow(
    d,
    caption=None,
    product=None,
    video_url=None,
    item_id=None,
    caption_tiktok=None,
    link_tiktok=None,
    keranjang_tiktok=None,
    log_fn=None,
    folder_sound=None,
    serial=None,
    is_retry=False,
    max_retry=10,
    mix_sound=True,
    search_query="remix terbaru",
):
    def log(msg):
        if log_fn: log_fn(msg)

    def slog(msg):
        """Sub-log: pakai prefix step aktif"""
        if log_fn: log_fn(f"[{_step:02d}/10] {msg}")

    _step = 0
    def step(n, msg):
        nonlocal _step
        _step = n
        log(f"[{n:02d}/10] {msg}")

    _error_msg = ""
    try:
        # ── Header ──
        log(f"━━━━━━━━━━ TikTok ━━━━━━━━━━")

        # [01/10] Push video ke HP
        local_path, filename = download_video(video_url, item_id, slog, force_download=is_retry)
        # Upscale + mix sound
        _did_upscale = False
        try:
            import subprocess, json as _j
            _probe = subprocess.run(["ffprobe","-v","quiet","-print_format","json","-show_streams",local_path], capture_output=True, text=True, timeout=30)
            _info = _j.loads(_probe.stdout)
            _vs = next((s for s in _info.get("streams",[]) if s.get("codec_type")=="video"), None)
            if _vs:
                _w, _h = int(_vs.get("width",0)), int(_vs.get("height",0))
                if _w < 1080 or _h < 1920:
                    _did_upscale = True
        except: pass
        from src.macro.shopee_only import upscale_if_needed as _upscale, mix_sound as _mix_sound
        _upscale(local_path, None)
        _song = None
        if mix_sound:
            _sounds_folder = folder_sound or "D:\\TikTok\\sounds"
            _song = _mix_sound(local_path, _sounds_folder)
        if _did_upscale and _song:
            slog(f"⬆ Upscale + 🎵 {_song}")
        elif _did_upscale and mix_sound:
            slog(f"⬆ Upscale (no sound)")
        elif _did_upscale:
            slog(f"⬆ Upscale (Mix Sound OFF)")
        elif _song:
            slog(f"🎵 {_song}")
        elif mix_sound:
            slog(f"⚠ No sound")
        else:
            slog(f"🔇 Mix Sound dimatikan")
        size_mb = os.path.getsize(local_path) / (1024*1024)
        push_to_device(d, local_path, filename)
        step(1, f"Push video ke HP... ({size_mb:.2f} MB)")

        # [02/10] Buka TikTok
        dlog(serial, f"TikTok [{item_id}] — Buka TikTok")
        step(2, "Buka TikTok...")
        open_tiktok(d);                   delay(None, 7,  "")
        click_plus_button(d);             delay(None, 7,  "")

        # [03/10] Pilih video dari gallery
        dlog(serial, f"TikTok [{item_id}] — Pilih video gallery")
        step(3, "Pilih video dari gallery...")
        click_gallery(d, slog);            delay(None, 5,  "")
        click_video_tab(d);               delay(None, 3,  "")
        disable_select_multiple_if_active(d)
        select_first_video(d);            delay(None, 2,  "")
        wait_editor_and_click_next_if_needed(d)

        # [04/10] Set sound & musik
        dlog(serial, f"TikTok [{item_id}] — Set sound")
        step(4, "Set sound & musik...")
        click_sound_top(d, slog);                                delay(None, 7, "")
        click_original_mute(d, slog);                            delay(None, 4, "")
        click_pencarian(d, slog);                                delay(None, 3, "")
        click_dropdown_kategori(d, slog);                        delay(None, 2, "")
        click_commercial_sounds(d, slog);                        delay(None, 3, "")
        input_search_lagu(d, search_query, slog);                delay(None, 5, "")
        pick_random_song_from_search(d, slog);                   delay(None, 4, "")
        close_sound_popup(d, slog);                              delay(None, 7, "")
        click_next_editor(d, slog);                              delay(None, 7, "")

        # [05/10] Set caption & cover
        dlog(serial, f"TikTok [{item_id}] — Set caption & cover")
        step(5, "Set caption & cover...")
        click_add_description(d, slog);    delay(None, 7,  "")
        input_caption_tiktok(d, caption_tiktok or caption)
        delay(None, 5, "")
        click_edit_cover(d)
        click_random_frame(d);            delay(None, 2,  "")
        click_save_cover(d);              delay(None, 4,  "")
        press_enter(d, slog);              delay(None, 2,  "")

        # [06/10] Tambah produk
        dlog(serial, f"TikTok [{item_id}] — Tambah produk")
        step(6, "Tambah produk...")
        click_add_link(d);                delay(None, 4,  "")
        click_product_with_replace_sound_retry(d, slog, max_retry=max_retry); delay(None, 3, "")

        # [07/10] Cek showcase
        dlog(serial, f"TikTok [{item_id}] — Cek showcase")
        step(7, "Cek showcase...")
        _found_in_showcase = False
        try:
            if d(text="Search products").exists:
                d(text="Search products").click(); delay(None, 5, "")
                _link_clean = link_tiktok.lstrip("'"); d(text="Search products").set_text(_link_clean); time.sleep(1); d.press("enter"); delay(None, 5, "")
                if d.xpath('//*[@content-desc="button_add_product"]').exists:
                    slog(f"Produk ditemukan di showcase ✓")
                    d.xpath('//*[@content-desc="button_add_product"]').click()
                    delay(None, 6, "")
                    confirm_add_popup_if_exist(d, slog)
                    delay(None, 10, "")
                    replace_product_name(d, keranjang_tiktok, slog); delay(None, 6, "")
                    press_enter2(d, slog);             delay(None, 2,  "")
                    click_add_button2(d, slog);        delay(None, 4,  "")
                    _found_in_showcase = True
                else:
                    slog(f"Produk tidak ada di showcase, coba marketplace...")
                    w, h = d.window_size()
                    d.click(int(w * 0.055), int(h * 0.077)); delay(None, 5, "")
        except Exception as _e:
            slog(f"⚠ Cek showcase error: {_e}, lanjut marketplace...")
            try: d.press("back"); delay(None, 3, "")
            except: pass

        # [08/10] Konfirmasi & finalisasi produk
        dlog(serial, f"TikTok [{item_id}] — Konfirmasi produk")
        step(8, "Konfirmasi & finalisasi produk...")
        if not _found_in_showcase:
            click_add_more_products(d, slog);  delay(None, 3,  "")
            click_product_marketplace(d, slog); delay(None, 6, "")
            search_and_add_product(d, link_tiktok, product, slog)
            delay(None, 6, "")
            confirm_add_popup_if_exist(d, slog)
            delay(None, 10, "")
            replace_product_name(d, keranjang_tiktok, slog); delay(None, 6, "")
            press_enter2(d, slog);             delay(None, 2,  "")
            click_add_button2(d, slog);        delay(None, 4,  "")

        # [09/10] Posting
        dlog(serial, f"TikTok [{item_id}] — Posting")
        step(9, "Posting...")
        click_post(d, slog);               delay(None, 15, "")

        # [10/10] Selesai
        dlog(serial, f"TikTok [{item_id}] — SELESAI ✅")
        step(10, "✅ TikTok Selesai")
        _error_msg = ""

    except Exception as e:
        log(f"[{_step:02d}/10] ❌ {e}")
        _error_msg = str(e)
        log(f"[10/10] ❌ TikTok Gagal")

    finally:
        try:
            d.shell(f"am force-stop {TIKTOK_PACKAGE}")
            time.sleep(2)
        except: pass

    return (_error_msg == ""), _error_msg
