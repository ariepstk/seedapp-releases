"""
slideshow_overlays.py
Generator elemen overlay (PNG transparan) untuk template slideshow:
kartu review, checklist fitur, mockup CTA Shopee, badge, dll.
Dipakai oleh slideshow_generator → dioverlay ffmpeg di window waktu tertentu.

Review card & CTA card punya BANYAK VARIAN (style) yang dipilih acak per video
biar 1000+ video tidak kelihatan template yang itu-itu saja.
"""
import os
import math
import random
from PIL import Image, ImageDraw, ImageFont


def _star(d, cx, cy, r, fill):
    """Gambar 1 bintang 5-sudut."""
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.42
        pts.append((cx + rr * math.cos(ang), cy + rr * math.sin(ang)))
    d.polygon(pts, fill=fill)


def _stars_row(d, x, y, n, total=5, r=13, gap=7, fill="#FFC107", empty="#E0E0E0"):
    for i in range(total):
        cx = x + r + i * (2 * r + gap)
        _star(d, cx, y + r, r, fill if i < n else empty)
    return total * (2 * r + gap)

# Font Windows (Arial). Fallback ke default PIL kalau tak ada.
_FONTS = {
    "reg": "C:/Windows/Fonts/arial.ttf",
    "bold": "C:/Windows/Fonts/arialbd.ttf",
}


def _font(kind, size):
    try:
        return ImageFont.truetype(_FONTS[kind], size)
    except Exception:
        return ImageFont.load_default()


def _wrap(draw, text, font, max_w):
    words = (text or "").split()
    lines, cur = [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=font) <= max_w:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def _rounded(draw, box, r, fill):
    draw.rounded_rectangle(box, radius=r, fill=fill)


def _bolt(d, x, y, col, s=18):
    """Gambar petir kecil (untuk badge FLASH SALE)."""
    d.polygon([(x + s * 0.55, y), (x, y + s * 0.6), (x + s * 0.4, y + s * 0.6),
               (x + s * 0.2, y + s), (x + s, y + s * 0.35), (x + s * 0.55, y + s * 0.35)],
              fill=col)


def _cart(d, cx, cy, col):
    """Ikon keranjang belanja sederhana."""
    d.line([(cx - 14, cy - 9), (cx - 9, cy - 9)], fill=col, width=4)
    d.line([(cx - 9, cy - 9), (cx + 12, cy - 9)], fill=col, width=4)
    d.line([(cx - 9, cy - 9), (cx - 5, cy + 5)], fill=col, width=4)
    d.line([(cx - 5, cy + 5), (cx + 9, cy + 5)], fill=col, width=4)
    d.line([(cx + 12, cy - 9), (cx + 9, cy + 5)], fill=col, width=4)
    d.ellipse((cx - 5, cy + 8, cx - 1, cy + 12), fill=col)
    d.ellipse((cx + 5, cy + 8, cx + 9, cy + 12), fill=col)


def _arrow(d, ax, ay, col):
    """Panah > kecil di lingkaran (untuk tombol checkout)."""
    d.line([(ax + 13, ay + 10), (ax + 23, ay + 18), (ax + 13, ay + 26)], fill=col, width=4, joint="curve")


_AVATAR_COLORS = ["#E57373", "#64B5F6", "#81C784", "#FFB74D", "#BA68C8", "#4DB6AC", "#F06292"]
_QUOTE_TINTS = [(255, 248, 240), (240, 248, 255), (244, 255, 246), (252, 244, 255), (255, 245, 247)]
_QUOTE_ACCENTS = ["#ee4d2d", "#1aa39a", "#3b82f6", "#8b5cf6", "#f59e0b"]

# ── REVIEW CARD ─────────────────────────────────────────────────────────────
_REVIEW_STYLES = ["bubble", "verified", "quote", "dark", "bubble", "verified"]  # bubble/verified lebih sering


def make_review_card(out_png, name, text, stars=5, width=820, date="", seed=0, style=None):
    """Kartu review pembeli. style=None → dipilih acak (bubble/verified/quote/dark)."""
    rnd = random.Random(seed)
    if style is None:
        style = rnd.choice(_REVIEW_STYLES)
    if style == "quote":
        return _review_quote(out_png, name, text, stars, width, date, rnd)
    return _review_card_base(out_png, name, text, stars, width, date, rnd,
                             dark=(style == "dark"), verified=(style == "verified"))


def _review_card_base(out_png, name, text, stars, width, date, rnd, dark=False, verified=False):
    """Kartu chat-bubble: avatar + nama + bintang + teks. Mode terang/gelap + tag terverifikasi."""
    pad = 34
    av = 64
    name_f = _font("bold", 30)
    date_f = _font("reg", 20)
    ver_f = _font("bold", 20)
    text_f = _font("reg", 28)
    inner_w = width - pad * 2
    tmp = Image.new("RGBA", (10, 10)); td = ImageDraw.Draw(tmp)
    lines = _wrap(td, text, text_f, inner_w)
    line_h = text_f.getbbox("Ay")[3] + 8
    ver_h = 34 if verified else 0
    text_h = len(lines) * line_h
    height = pad + av + ver_h + 18 + text_h + pad
    # palet warna sesuai mode
    if dark:
        card_fill = (29, 36, 48, 255); name_col = "#FFFFFF"; text_col = "#D7DBE2"
        date_col = "#8B93A1"; empty_star = "#3A4453"; border = (47, 56, 71, 255)
    else:
        card_fill = (255, 255, 255, 255); name_col = "#222222"; text_col = "#333333"
        date_col = "#9AA0A6"; empty_star = "#E0E0E0"; border = (235, 235, 235, 255)
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    _rounded(d, (6, 10, width - 2, height - 2), 26, (0, 0, 0, 70))
    _rounded(d, (0, 0, width - 8, height - 12), 26, card_fill)
    d.rounded_rectangle((0, 0, width - 8, height - 12), radius=26, outline=border, width=2)
    # avatar
    ax, ay = pad, pad
    col = rnd.choice(_AVATAR_COLORS)
    d.ellipse((ax, ay, ax + av, ay + av), fill=col)
    initial = (name[:1] or "A").upper()
    iw = d.textlength(initial, font=name_f)
    d.text((ax + av / 2 - iw / 2, ay + av / 2 - 18), initial, font=name_f, fill="white")
    # nama + bintang + tanggal
    tx = ax + av + 18
    d.text((tx, ay + 2), name, font=name_f, fill=name_col)
    _stars_row(d, tx, ay + 38, int(stars), empty=empty_star)
    if date:
        dw = d.textlength(date, font=date_f)
        d.text((width - pad - dw, ay + 6), date, font=date_f, fill=date_col)
    ty = pad + av
    # tag "Pembelian terverifikasi" (hijau)
    if verified:
        tag = "Pembelian terverifikasi"
        tw = d.textlength(tag, font=ver_f)
        gx, gy = pad, ty + 6
        _rounded(d, (gx, gy, gx + 30 + tw + 18, gy + 28), 14, (35, 165, 89, 255))
        d.line([(gx + 11, gy + 14), (gx + 17, gy + 20), (gx + 27, gy + 8)], fill="white", width=3, joint="curve")
        d.text((gx + 36, gy + 4), tag, font=ver_f, fill="white")
        ty += ver_h
    # teks review
    ty += 18
    for ln in lines:
        d.text((pad, ty), ln, font=text_f, fill=text_col)
        ty += line_h
    img.save(out_png)
    return out_png, width, height


def _review_quote(out_png, name, text, stars, width, date, rnd):
    """Kartu review gaya kutipan: tanda petik besar + teks + bintang + nama di bawah."""
    pad = 38
    tint = rnd.choice(_QUOTE_TINTS)
    accent = rnd.choice(_QUOTE_ACCENTS)
    quote_f = _font("bold", 110)
    text_f = _font("reg", 30)
    name_f = _font("bold", 28)
    date_f = _font("reg", 20)
    inner_w = width - pad * 2
    tmp = Image.new("RGBA", (10, 10)); td = ImageDraw.Draw(tmp)
    lines = _wrap(td, text, text_f, inner_w)
    line_h = text_f.getbbox("Ay")[3] + 9
    text_h = len(lines) * line_h
    height = pad + 58 + text_h + 18 + 40 + pad
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    _rounded(d, (6, 10, width - 2, height - 2), 26, (0, 0, 0, 60))
    _rounded(d, (0, 0, width - 8, height - 12), 26, tint + (255,))
    # garis aksen kiri
    _rounded(d, (0, 0, 12, height - 12), 6, accent)
    # tanda kutip besar
    d.text((pad - 6, -8), "“", font=quote_f, fill=accent)
    # teks
    ty = pad + 64
    for ln in lines:
        d.text((pad, ty), ln, font=text_f, fill="#2b2b2b")
        ty += line_h
    # bintang + nama + tanggal di bawah
    ty += 14
    _stars_row(d, pad, ty, int(stars), r=12, gap=6)
    nm = "— " + name
    d.text((pad + 175, ty + 1), nm, font=name_f, fill="#444444")
    if date:
        dw = d.textlength(date, font=date_f)
        d.text((width - pad - dw, ty + 4), date, font=date_f, fill="#9aa0a6")
    img.save(out_png)
    return out_png, width, height


# ── CHECKLIST ───────────────────────────────────────────────────────────────
def make_checklist(out_png, items, width=600, accent="#23a559"):
    """Checklist fitur: tiap item = pill putih + centang hijau + teks (gaya V12/V13)."""
    items = [x for x in (items or []) if x][:6]
    if not items:
        return None, 0, 0
    f = _font("bold", 28)
    ph = 60          # tinggi pill
    gap = 5          # jeda antar pill dirapatkan
    pad = 4
    height = pad + len(items) * (ph + gap)
    img = Image.new("RGBA", (width, height + pad), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = pad
    for it in items:
        _rounded(d, (4, y + 4, width - 2, y + ph + 2), ph // 2, (0, 0, 0, 45))
        _rounded(d, (0, y, width - 6, y + ph - 4), (ph - 4) // 2, (255, 255, 255, 240))
        cy = y + (ph - 4) // 2
        cr = 18
        cx = 18 + cr
        d.ellipse((cx - cr, cy - cr, cx + cr, cy + cr), fill=accent)
        d.line([(cx - 9, cy + 1), (cx - 2, cy + 8), (cx + 10, cy - 8)], fill="white", width=4, joint="curve")
        d.text((cx + cr + 16, cy - 16), str(it), font=f, fill="#222222")
        y += ph + gap
    img.save(out_png)
    return out_png, width, height


def _heart(d, cx, cy, s, fill):
    r = s / 2
    d.ellipse((cx - r, cy - r, cx, cy), fill=fill)
    d.ellipse((cx, cy - r, cx + r, cy), fill=fill)
    d.polygon([(cx - r, cy - r / 4), (cx + r, cy - r / 4), (cx, cy + r)], fill=fill)


# ── CTA CARD (mockup halaman Shopee) ────────────────────────────────────────
_CTA_STYLES = ["shopee", "single", "flash", "checkout", "shopee", "flash"]
_BUY_TXT = ["Beli Sekarang!", "Beli Sekarang", "Ambil Sekarang", "Order Yuk!", "Checkout Yuk!"]
_CART_TXT = ["Masuk Keranjang", "+ Keranjang", "Keranjang"]
_CHECKOUT_TXT = ["Checkout Sekarang", "Selesaikan Pesanan", "Bayar Sekarang"]


def make_cta_card(out_png, W, H, product_img=None, style=None, seed=0):
    """Mockup kartu CTA Shopee. style=None → acak (shopee/single/flash/checkout)."""
    rnd = random.Random(seed if seed else random.randint(0, 999999))
    if style is None:
        style = rnd.choice(_CTA_STYLES)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    rad = 34
    top_h = 96
    bot_h = 104
    # shadow + kartu PUTIH solid
    _rounded(d, (8, 12, W - 2, H - 2), rad, (0, 0, 0, 55))
    d.rounded_rectangle((4, 4, W - 8, H - 10), radius=rad, fill=(255, 255, 255, 255))
    # gambar produk di tengah (di depan kartu putih → tidak tenggelam)
    if product_img:
        try:
            pim = Image.open(product_img).convert("RGBA")
            iw, ih = W - 56, H - top_h - bot_h - 20
            pim.thumbnail((iw, ih), Image.LANCZOS)
            px = (W - 4 - pim.width) // 2
            py = top_h + (ih - pim.height) // 2
            img.paste(pim, (px, py), pim)
        except Exception:
            pass
    d.rounded_rectangle((4, 4, W - 8, H - 10), radius=rad, outline=(228, 228, 228, 255), width=3)
    # back arrow kuning kiri-atas
    bx, by = 30, 30
    d.ellipse((bx, by, bx + 40, by + 40), fill="#FFC107")
    d.line([(bx + 26, by + 12), (bx + 14, by + 20), (bx + 26, by + 28)], fill="white", width=4, joint="curve")
    # ikon kanan-atas: •••  S  +  ❤
    ix = W - 44
    iy = by + 20
    icbg = (242, 242, 242, 255)
    for kind in ["dots", "S", "plus", "heart"]:
        if kind == "heart":
            d.ellipse((ix - 18, iy - 18, ix + 18, iy + 18), fill=icbg)
            _heart(d, ix, iy - 2, 20, "#ee4d2d")
        elif kind == "plus":
            d.ellipse((ix - 18, iy - 18, ix + 18, iy + 18), fill=icbg)
            d.line([(ix - 8, iy), (ix + 8, iy)], fill="#555", width=4)
            d.line([(ix, iy - 8), (ix, iy + 8)], fill="#555", width=4)
        elif kind == "S":
            d.ellipse((ix - 18, iy - 18, ix + 18, iy + 18), fill="#ee4d2d")
            d.text((ix - 7, iy - 14), "S", font=_font("bold", 26), fill="white")
        else:
            for k in range(3):
                d.ellipse((ix - 16 + k * 13, iy - 3, ix - 10 + k * 13, iy + 3), fill="#bbbbbb")
        ix -= 50
    # badge FLASH SALE kiri-atas (di samping back arrow) untuk style 'flash'
    if style == "flash":
        ff = _font("bold", 22)
        ftxt = "FLASH SALE"
        ftw = d.textlength(ftxt, font=ff)
        fx, fy = 84, 30
        _rounded(d, (fx, fy, fx + 30 + ftw + 16, fy + 40), 12, "#ee4d2d")
        _bolt(d, fx + 12, fy + 11, "#FFD54A")
        d.text((fx + 36, fy + 8), ftxt, font=ff, fill="white")
    # footer tombol sesuai style
    _cta_footer(d, W, H, style, rnd)
    img.save(out_png)
    return out_png, W, H


def _cta_footer(d, W, H, style, rnd):
    """Gambar area tombol bawah kartu CTA, bervariasi sesuai style."""
    bf = _font("bold", 30)
    by2 = H - 84
    buy = rnd.choice(_BUY_TXT)
    cart = rnd.choice(_CART_TXT)
    if style in ("single", "checkout"):
        if style == "single":
            col = "#ee4d2d"; label = buy
        else:
            col = "#16a34a"; label = rnd.choice(_CHECKOUT_TXT)
        _rounded(d, (30, by2, W - 30, by2 + 60), 30, col)
        tw = d.textlength(label, font=bf)
        lx = W / 2 - (tw + 40) / 2
        d.text((lx, by2 + 12), label, font=bf, fill="white")
        # ikon di ujung kanan tombol
        cgx = lx + tw + 34
        d.ellipse((cgx, by2 + 12, cgx + 36, by2 + 48), fill="white")
        if style == "single":
            _cart(d, cgx + 18, by2 + 30, col)
        else:
            _arrow(d, cgx, by2 + 12, col)
    else:  # 'shopee' / 'flash' → dua tombol (Beli + Keranjang)
        bw = (W - 60) // 2
        _rounded(d, (30, by2, 30 + bw - 8, by2 + 60), 30, "#ee4d2d")
        tw = d.textlength(buy, font=bf)
        d.text((30 + (bw - 8) / 2 - tw / 2, by2 + 12), buy, font=bf, fill="white")
        x2 = 30 + bw + 8
        _rounded(d, (x2, by2, W - 30, by2 + 60), 30, "#1aa39a")
        tw2 = d.textlength(cart, font=bf)
        d.text((x2 + (W - 30 - x2) / 2 - tw2 / 2 - 12, by2 + 12), cart, font=bf, fill="white")
        ax = W - 52
        d.ellipse((ax, by2 + 12, ax + 36, by2 + 48), fill="white")
        d.line([(ax + 13, by2 + 22), (ax + 23, by2 + 30), (ax + 13, by2 + 38)], fill="#1aa39a", width=4, joint="curve")


def make_badge(out_png, text, bg="#ee4d2d", star=True):
    """Badge pill kecil (mis. TERLARIS / BEST SELLER) untuk pojok — bintang emas + teks putih."""
    f = _font("bold", 30)
    tmp = Image.new("RGBA", (10, 10)); td = ImageDraw.Draw(tmp)
    tw = td.textlength(text, font=f)
    sw = 40 if star else 0
    pad = 22
    W = int(tw + sw + pad * 2)
    H = 60
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    _rounded(d, (4, 6, W - 2, H - 2), H // 2, (0, 0, 0, 60))
    _rounded(d, (0, 0, W - 4, H - 6), (H - 6) // 2, bg)
    x = pad
    if star:
        _star(d, x + 13, H // 2 - 3, 14, "#FFD54A")
        x += sw
    d.text((x, H // 2 - 21), text, font=f, fill="white")
    img.save(out_png)
    return out_png, W, H


def make_banner(out_png, W, top_text, bottom_text, bar_h=120):
    """Banner ala 'HARGA TERBAIK' (atas) + 'Checkout Sekarang!' (bawah). Tengah transparan."""
    H = 1920
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    ft = _font("bold", 56)
    fb = _font("bold", 46)
    d.rectangle((0, 0, W, bar_h), fill=(0, 0, 0, 235))
    tw = d.textlength(top_text, font=ft)
    d.text((W / 2 - tw / 2, bar_h / 2 - 32), top_text, font=ft, fill="white")
    d.rectangle((0, H - bar_h, W, H), fill=(0, 0, 0, 235))
    bw = d.textlength(bottom_text, font=fb)
    d.text((W / 2 - bw / 2, H - bar_h / 2 - 26), bottom_text, font=fb, fill="#FFC107")
    img.save(out_png)
    return out_png, W, H


if __name__ == "__main__":
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    outdir = sys.argv[1] if len(sys.argv) > 1 else "."
    rev_txt = ("Topi bulu beruangnya lucu banget dan bahannya lembut! "
               "Hangat dipakai, anak aku suka banget. Recommended deh!")
    for i, st in enumerate(["bubble", "verified", "quote", "dark"]):
        make_review_card(os.path.join(outdir, f"rev_{st}.png"), "Nadia Vogue",
                         rev_txt, stars=5, date="12 Mei 2026", seed=i + 1, style=st)
    for st in ["shopee", "single", "flash", "checkout"]:
        make_cta_card(os.path.join(outdir, f"cta_{st}.png"), 860, 760, style=st, seed=7)
    print("OK semua varian dibuat di", outdir)
