"""
slideshow_generator.py
Generate video slideshow 9:16 dari judul produk + galeri gambar.
Alur: judul -> Gemini (script: headline/subtitle/frasa+keyword) -> edge-tts (voice over per frasa)
      -> FFmpeg (gambar Ken Burns + bg blur + caption ASS highlight + audio + musik) -> mp4.
"""

import os
import re
import json
import time
import random
import asyncio
import threading
import subprocess

import edge_tts
try:
    from curl_cffi import requests as _cffi
except Exception:
    _cffi = None
import requests as _req

HERE = os.path.dirname(os.path.abspath(__file__))   # _internal/update/src/macro
FFMPEG = os.path.join(HERE, "..", "..", "..", "ffmpeg", "ffmpeg.exe")    # _internal/ffmpeg
FFPROBE = os.path.join(HERE, "..", "..", "..", "ffmpeg", "ffprobe.exe")
F5_DIR = os.path.abspath(os.path.join(HERE, "..", "..", "..", "f5tts"))  # _internal/f5tts

# Prompt default (editable di UI). Variabel: {{Product}} & {{Duration}} diisi otomatis saat generate.
DEFAULT_AI_PROMPT = (
    "Buatkan script voice-over promosi berdurasi sekitar {{Duration}} detik untuk produk: {{Product}}.\n\n"
    "Ikuti ALUR ini (kamu yang tentukan kata-katanya, buat se-natural & semenarik mungkin):\n"
    "Hook (bikin penonton berhenti scroll) → kenalkan produk → benefit utama → 2-3 keunggulan singkat "
    "→ use-case / kapan dipakai → CTA mendesak (ajak checkout).\n\n"
    "Gaya bahasa: Bahasa Indonesia santai ala TikTok/Shopee affiliate, sapaan langsung ke penonton "
    "(kamu/kalian), kalimat pendek & natural seperti diucapkan orang, antusias tapi tidak lebay. "
    "Hindari bahasa iklan yang kaku/formal/baku."
)

DEFAULTS = {
    "voice": "id-ID-GadisNeural",
    "rate": "+0%",                 # natural (boost bikin kedengaran robot)
    "music_folder": "",
    "music_volume": 0.15,
    "highlight_rgb": "FF8C00",     # oranye
    "ai_base_url": "https://ai.sumopod.com/v1",   # OpenAI-compatible (sumopod, dst)
    "gemini_key": "",                              # API key (sumopod / lainnya)
    "gemini_model": "gemini/gemini-2.5-flash-lite",   # sumopod butuh prefix provider
    "ai_prompt": DEFAULT_AI_PROMPT,  # template prompt (editable), pakai {{Product}} & {{Duration}}
    "duration_sec": 15,            # target durasi video (script di-generate sesuai ini)
    "width": 1080,
    "height": 1920,
    "fps": 25,
    "image_sec": 3.0,              # durasi tampil per gambar
    "transition": 0.5,             # lama transisi antar gambar (detik)
    "template": "auto",            # auto (overlay review/checklist/CTA acak) | off (polos)
    "bg_style": "clean",           # latar (kalau bg_path kosong): clean | gradient | blur
    "bg_path": "",                 # folder/file gambar latar custom. Isi = pakai ini; kosong = pakai bg_style
    "tts_engine": "auto",          # auto | piper | gemini | edge | f5
    # F5-TTS (voice cloning lokal, kualitas top) — server persisten auto-start. Path default = hasil install.
    "f5_python": "", "f5_ckpt": "", "f5_vocab": "", "f5_ref": "", "f5_ref_text": "",
    "f5_arch": "F5TTS_v1_Base", "f5_url": "http://127.0.0.1:18765",
    # Gemini TTS (suara natural) — pakai API key Google AI Studio (gratis). Kosong = pakai edge-tts.
    "tts_key": "",
    "tts_model": "gemini-2.5-flash-preview-tts",
    "tts_voice": "Kore",           # suara Gemini (lihat TTS_VOICES)
    "tts_style": "Bacakan dengan gaya antusias, ramah, dan persuasif seperti host promosi TikTok:",
    # Piper TTS (lokal, gratis, unlimited — terbaik utk volume massal). Isi path = aktif.
    "piper_exe": "",               # path piper.exe
    "piper_model": "",             # path voice .onnx (Indonesia)
    "ss_workers": 0,               # jumlah video paralel (0 = auto)
    "use_gpu": "auto",             # render GPU NVENC (auto/on/off)
}

# Suara Gemini TTS pilihan (wanita & pria) — natural & ekspresif
TTS_VOICES = [
    ("Kore", "Wanita - tegas"), ("Leda", "Wanita - muda"), ("Aoede", "Wanita - santai"),
    ("Callirrhoe", "Wanita - lembut"), ("Sulafat", "Wanita - hangat"),
    ("Puck", "Pria - ceria"), ("Charon", "Pria - berwibawa"), ("Orus", "Pria - tegas"),
]
# Latar lembut utk mode gradient (cycle per slide)
_BG_COLORS = ["0xFDF1E7", "0xEAF2F8", "0xF4ECF7", "0xEAF7EF", "0xFBEEE6", "0xEFEAF7"]

# Throttle panggilan script AI (sumopod) — maks N bersamaan walau render banyak paralel,
# biar tak kebanjiran → tak 429 → AI sukses → hook selalu dari AI (bukan fallback).
_AI_SEM = threading.BoundedSemaphore(3)


# ── util ────────────────────────────────────────────────────────────
def _ff_duration(path):
    out = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                          "-of", "default=nw=1:nk=1", path], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip()
    try:
        return float(out)
    except Exception:
        return 0.0


def _rgb_to_ass(rgb):
    rgb = (rgb or "FF8C00").lstrip("#")
    if len(rgb) != 6:
        rgb = "FF8C00"
    r, g, b = rgb[0:2], rgb[2:4], rgb[4:6]
    return "&H" + b + g + r + "&"   # ASS = &HBBGGRR


def _download_image(url, path):
    if not url:
        return False
    try:
        if _cffi is not None:
            r = _cffi.get(url, impersonate="chrome", timeout=25)
        else:
            r = _req.get(url, timeout=25)
        if r.status_code == 200 and len(r.content) > 3000:
            with open(path, "wb") as f:
                f.write(r.content)
            return True
    except Exception:
        pass
    return False


# ── Gemini: judul -> script ─────────────────────────────────────────
def _clean_title(t):
    t = re.sub(r"\s+", " ", t or "").strip()
    return t


def _smart_trunc(s, n):
    s = (s or "").strip()
    if len(s) <= n:
        return s
    cut = s[:n].rsplit(" ", 1)[0]
    return cut if len(cut) >= 6 else s[:n]


def _fill_vars(tmpl, product, dur, n_phrase):
    """Ganti {{Product}}/{{Duration}}/{{Phrases}} (case-insensitive) di template prompt."""
    repl = {
        "product": product or "", "title": product or "", "produk": product or "",
        "duration": str(int(dur)), "durasi": str(int(dur)),
        "phrases": str(n_phrase), "frasa": str(n_phrase),
    }
    def _sub(m):
        return repl.get(m.group(1).strip().lower(), m.group(0))
    return re.sub(r"\{\{\s*([A-Za-z]+)\s*\}\}", _sub, tmpl or "")


# Struktur output WAJIB + guardrail anti-overclaim (di-append ke prompt user → selalu aktif)
_SCHEMA_INSTR = (
    "\n\nWAJIB: voice over harus benar-benar tentang PRODUK sesuai judul di atas. JANGAN mengganti "
    "jenis produk dan JANGAN mengarang material/fitur yang tidak ada/tidak tersirat di judul "
    "(mis. judul 'topi' jangan dibahas jadi 'tas'; jangan klaim 'kulit asli' kalau tak disebut).\n"
    "\nKEBIJAKAN SHOPEE — DILARANG overclaim (klaim berlebihan/tak terbukti), WAJIB dipatuhi:\n"
    "- Tanpa superlatif absolut: 'termurah','terbaik','nomor 1','paling','satu-satunya','terlengkap'.\n"
    "- Tanpa jaminan mutlak: '100% dijamin','pasti','permanen','tanpa efek samping'.\n"
    "- Tanpa klaim kesehatan/medis/khasiat, dan tanpa klaim original/BPOM/SNI kalau tak ada di judul produk.\n"
    "- Tanpa urgensi palsu yang spesifik ('stok tinggal 3','diskon 90%'). Boleh 'stok terbatas' yang umum.\n"
    "Pakai ajakan wajar & jujur, benefit yang masuk akal sesuai produk saja.\n"
    "\nKeluarkan HANYA JSON valid (tanpa markdown), struktur:\n"
    '{"headline":"<2-4 kata nama produk ringkas + 1 emoji>",'
    '"subtitle":"<tagline benefit singkat 3-6 kata>",'
    '"features":["<fitur singkat 2-4 kata>","<fitur lain>","..."],'
    '"review":{"name":"<nama orang Indonesia>","stars":5,"text":"<testimoni singkat 1-2 kalimat, gaya pembeli puas>"},'
    '"phrases":[{"text":"<frasa SINGKAT & padat, MAKS 6 kata, gaya diucapkan, diakhiri koma>","keyword":"<1 kata penting di text utk di-highlight>"}]}\n'
    "features = 4-5 keunggulan produk (dari judul, jujur, tanpa overclaim). review = 1 testimoni wajar.\n"
    "WAJIB tepat __NPHRASE__ frasa. Tiap \"text\" harus terdengar natural kayak diucapkan orang. "
    "keyword HARUS salah satu kata yang ADA di dalam text frasa itu."
)


# perkiraan detik per frasa diucapkan, beda per engine (F5 paling cepat → butuh lebih banyak frasa)
_PHRASE_SEC = {"f5": 2.05, "edge": 2.55, "piper": 2.2, "gemini": 2.35, "auto": 2.2}


def _target_phrases(settings):
    """Jumlah frasa ~ durasi target, menyesuaikan kecepatan bicara engine TTS."""
    dur = settings.get("duration_sec") or DEFAULTS["duration_sec"]
    try:
        dur = float(dur)
    except Exception:
        dur = DEFAULTS["duration_sec"]
    dur = max(8.0, min(40.0, dur))
    engine = (settings.get("tts_engine") or "auto").lower()
    per = _PHRASE_SEC.get(engine, 2.1)
    return dur, max(3, min(14, round(dur / per)))


_FALLBACK_HOOKS = [
    "eh stop dulu scroll kamu,", "guys, wajib liat ini deh,", "eh jangan di-skip dulu ya,",
    "kalian lagi cari ini ya?", "nih yang kamu butuhin,", "buruan merapat semuanya,",
    "psst, ada yang menarik nih,", "yang lagi nyari, mampir dulu,", "cek dulu yang satu ini,",
    "eh ini lagi viral lho,", "jangan sampai kelewatan ya,", "buat kamu yang suka praktis,",
]
_FALLBACK_BODY = [
    ("bahannya premium dan nyaman,", "premium"), ("bahannya adem dan lembut,", "adem"),
    ("desainnya kekinian dan elegan,", "elegan"), ("modelnya simpel tapi stylish,", "stylish"),
    ("harganya ramah banget di kantong,", "ramah"), ("kualitasnya oke punya,", "oke"),
    ("cocok buat dipake sehari-hari,", "cocok"), ("pas buat segala suasana,", "pas"),
    ("bikin tampilan kamu makin kece,", "kece"), ("nyaman dipakai seharian,", "nyaman"),
    ("stok terbatas jangan kehabisan,", "terbatas"), ("warnanya juga banyak pilihan,", "warnanya"),
]
_FALLBACK_CTA = [
    ("yuk langsung checkout sekarang!", "sekarang"), ("buruan klik keranjangnya ya!", "buruan"),
    ("klik keranjang kuningnya sekarang!", "sekarang"), ("cuss order sebelum kehabisan!", "cuss"),
    ("gas checkout sekarang juga!", "gas"),
]
_FALLBACK_REVIEWS = [
    "Barangnya bagus banget, sesuai foto dan pengiriman cepat. Recommended!",
    "Suka banget sama produknya, kualitasnya oke dan worth it.",
    "Mantap, sesuai ekspektasi. Bakal beli lagi sih.",
    "Pengemasan rapi, barang aman sampai. Puas banget belanja di sini.",
    "Awalnya ragu, ternyata bagus banget. Gak nyesel beli.",
]


def _fallback_script(title, n_phrase=6):
    """Script sederhana tanpa AI (kalau key kosong/gagal). Hook & isi DIACAK biar tak monoton."""
    short = _clean_title(title)
    short = re.sub(r"[|/].*$", "", short).strip()[:40]
    hook = {"text": random.choice(_FALLBACK_HOOKS), "keyword": random.choice(["stop", "guys", "ini", "nih"])}
    intro = {"text": (short + " ini nih,") if short else "produk ini nih,",
             "keyword": short.split(" ")[0] if short else "ini"}
    mids = random.sample(_FALLBACK_BODY, min(len(_FALLBACK_BODY), max(1, n_phrase - 3)))
    body = [hook, intro] + [{"text": t, "keyword": k} for t, k in mids]
    cta_t, cta_k = random.choice(_FALLBACK_CTA)
    phrases = body[:n_phrase - 1] + [{"text": cta_t, "keyword": cta_k}]
    return {
        "headline": _smart_trunc(short, 26) if short else "Produk Pilihan",
        "subtitle": "Kualitas oke, harga bersahabat",
        "features": ["Bahan premium", "Desain kekinian", "Nyaman dipakai", "Harga ramah", "Banyak warna"],
        "review": {"name": "Pembeli", "stars": 5, "text": random.choice(_FALLBACK_REVIEWS)},
        "phrases": phrases,
    }


def _gemini_script(title, settings, log=None):
    """Generate script via endpoint OpenAI-compatible (sumopod, dst). Fallback kalau gagal."""
    dur, n_phrase = _target_phrases(settings)
    key = (settings.get("gemini_key") or settings.get("ai_key") or "").strip()
    if not key:
        return _fallback_script(title, n_phrase)
    base = (settings.get("ai_base_url") or DEFAULTS["ai_base_url"]).strip().rstrip("/")
    model = (settings.get("gemini_model") or settings.get("ai_model") or DEFAULTS["gemini_model"]).strip()
    url = base + "/chat/completions"
    tmpl = (settings.get("ai_prompt") or DEFAULT_AI_PROMPT).strip()
    prompt = _fill_vars(tmpl, title, dur, n_phrase)
    # Pengaman: kalau template lupa pakai {{Product}}, paksa produk asli ke depan (override apapun di template)
    if not re.search(r"\{\{\s*(product|produk|title)\s*\}\}", tmpl, re.I):
        prompt = ("PRODUK (WAJIB ini, abaikan nama produk lain di bawah): %s\nDURASI: %d detik\n\n%s"
                  % (title, int(dur), prompt))
    prompt += _SCHEMA_INSTR.replace("__NPHRASE__", str(n_phrase))
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.9,
    }
    headers = {"Authorization": "Bearer " + key, "Content-Type": "application/json"}
    try:
        r = None
        with _AI_SEM:   # throttle: maks 3 panggilan AI bersamaan → cegah 429
            for attempt in range(3):   # retry (batch paralel bisa kena rate-limit sesaat)
                if _cffi is not None:
                    r = _cffi.post(url, json=payload, headers=headers, timeout=45, impersonate="chrome")
                else:
                    r = _req.post(url, json=payload, headers=headers, timeout=45)
                if r.status_code == 200:
                    break
                if r.status_code in (429, 500, 502, 503, 529) and attempt < 2:
                    time.sleep(1.5 * (attempt + 1) + random.uniform(0, 1.5))   # backoff + jitter
                    continue
                break
        if r is None or r.status_code != 200:
            if log:
                log("⚠ AI %s: %s — pakai script default" % (r.status_code if r else "?", (r.text[:120] if r else "")))
            return _fallback_script(title, n_phrase)
        j = r.json()
        raw = (j["choices"][0]["message"]["content"] or "").strip()
        raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.I | re.M).strip()
        m = re.search(r"\{.*\}", raw, re.S)
        data = json.loads(m.group(0) if m else raw)
        if data.get("headline") and data.get("phrases"):
            ph = data["phrases"]
            if len(ph) > n_phrase:   # paksa sesuai target (AI kadang bikin kebanyakan) → durasi terkontrol
                data["phrases"] = ph[:n_phrase - 1] + [ph[-1]]   # potong, CTA (terakhir) tetap dipertahankan
            return data
    except Exception as e:
        if log:
            log("⚠ AI error: %s — pakai script default" % e)
    return _fallback_script(title, n_phrase)


# ── TTS ─────────────────────────────────────────────────────────────
async def _tts(text, voice, rate, path):
    c = edge_tts.Communicate(text, voice, rate=rate)
    with open(path, "wb") as f:
        async for ch in c.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])


def _gemini_tts(text, settings, out_mp3, log=None):
    """Gemini TTS (Google AI Studio) → suara natural. Return True kalau sukses, False kalau gagal/no-key."""
    key = (settings.get("tts_key") or "").strip()
    if not key:
        return False
    model = (settings.get("tts_model") or DEFAULTS["tts_model"]).strip()
    voice = (settings.get("tts_voice") or DEFAULTS["tts_voice"]).strip()
    style = (settings.get("tts_style") or "").strip()
    say = (style + "\n" + text) if style else text
    url = ("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, key))
    body = {
        "contents": [{"parts": [{"text": say}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}},
        },
    }
    try:
        r = None
        for attempt in range(2):
            if _cffi is not None:
                r = _cffi.post(url, json=body, headers={"Content-Type": "application/json"}, timeout=120, impersonate="chrome")
            else:
                r = _req.post(url, json=body, headers={"Content-Type": "application/json"}, timeout=120)
            if r.status_code != 429 or attempt == 1:
                break
            # 429: baca retryDelay; kalau singkat (<=12s) tunggu & coba sekali lagi, kalau lama langsung edge
            md = re.search(r"retryDelay\D+(\d+)", r.text or "")
            wait = int(md.group(1)) if md else 0
            if 0 < wait <= 12:
                if log: log("⚠ Gemini TTS 429 (rate limit) — tunggu %ss lalu coba lagi" % wait)
                time.sleep(wait + 1)
            else:
                break
        if r.status_code != 200:
            if r.status_code == 429:
                if log: log("⚠ Gemini TTS 429: kuota/limit Google habis — pakai edge-tts")
            elif log:
                log("⚠ Gemini TTS %s: %s — pakai edge-tts" % (r.status_code, (r.text or "")[:140]))
            return False
        j = r.json()
        b64, mime = None, ""
        for p in j["candidates"][0]["content"]["parts"]:
            if "inlineData" in p:
                b64 = p["inlineData"]["data"]; mime = p["inlineData"].get("mimeType", ""); break
        if not b64:
            return False
        import base64
        pcm_path = out_mp3 + ".pcm"
        with open(pcm_path, "wb") as f:
            f.write(base64.b64decode(b64))
        rate = 24000
        mr = re.search(r"rate=(\d+)", mime)
        if mr:
            rate = int(mr.group(1))
        pr = subprocess.run([FFMPEG, "-y", "-f", "s16le", "-ar", str(rate), "-ac", "1",
                             "-i", pcm_path, out_mp3], capture_output=True, text=True, encoding="utf-8", errors="replace")
        try:
            os.remove(pcm_path)
        except Exception:
            pass
        ok = pr.returncode == 0 and os.path.exists(out_mp3) and os.path.getsize(out_mp3) > 1000
        if ok and log:
            log("🎙 Gemini TTS (%s) OK" % voice)
        return ok
    except Exception as e:
        if log:
            log("⚠ Gemini TTS error: %s — pakai edge-tts" % e)
        return False


def _piper_tts(text, settings, out_mp3, log=None):
    """Piper TTS lokal (gratis, instan, unlimited). Return True kalau sukses."""
    exe = (settings.get("piper_exe") or "").strip().strip('"')
    model = (settings.get("piper_model") or "").strip().strip('"')
    if not exe or not model or not os.path.isfile(exe) or not os.path.isfile(model):
        return False
    try:
        wav = out_mp3 + ".wav"
        p = subprocess.run([exe, "--model", model, "--output_file", wav],
                           input=text, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
        if p.returncode != 0 or not os.path.exists(wav):
            if log: log("⚠ Piper gagal: %s" % ((p.stderr or "")[:120]))
            return False
        subprocess.run([FFMPEG, "-y", "-i", wav, out_mp3], capture_output=True, text=True, encoding="utf-8", errors="replace")
        try:
            os.remove(wav)
        except Exception:
            pass
        ok = os.path.exists(out_mp3) and os.path.getsize(out_mp3) > 500
        if ok and log: log("🎙 Piper TTS OK")
        return ok
    except Exception as e:
        if log: log("⚠ Piper error: %s" % e)
        return False


_F5_PROC = None
_F5_LOCK = threading.Lock()


def _f5_paths(settings):
    return (
        (settings.get("f5_python") or os.path.join(F5_DIR, "venv", "Scripts", "python.exe")),
        (settings.get("f5_ckpt") or os.path.join(F5_DIR, "model", "f5_tts_indo_v2.pt")),
        (settings.get("f5_vocab") or os.path.join(F5_DIR, "model", "vocab.txt")),
        (settings.get("f5_ref") or os.path.join(F5_DIR, "refs", "ref_voice.wav")),
        (settings.get("f5_ref_text") or ""),
        (settings.get("f5_arch") or "F5TTS_v1_Base"),
        (settings.get("f5_url") or "http://127.0.0.1:18765"),
    )


def _f5_alive(url):
    """True hanya kalau server F5 KITA yang jawab (penanda 'f5-ready'), bukan app lain di port itu."""
    try:
        r = _req.get(url, timeout=1)
        return r.status_code == 200 and "f5-ready" in (r.text or "")
    except Exception:
        return False


def _ensure_f5_server(settings, log=None):
    """Pastikan server F5 hidup (auto-start sekali, model nyangkut di VRAM). Return url / None."""
    global _F5_PROC
    pyv, ckpt, vocab, ref, ref_text, arch, url = _f5_paths(settings)
    if not (os.path.isfile(pyv) and os.path.isfile(ckpt) and os.path.isfile(ref)):
        if log: log("⚠ F5 belum lengkap (python/model/ref tidak ditemukan)")
        return None
    if _f5_alive(url):
        return url
    with _F5_LOCK:
        if _f5_alive(url):
            return url
        if _F5_PROC is None or _F5_PROC.poll() is not None:
            port = url.rsplit(":", 1)[-1].split("/")[0]
            cmd = [pyv, os.path.join(F5_DIR, "f5_server.py"), "--ckpt", ckpt, "--vocab", vocab,
                   "--ref", ref, "--ref_text", ref_text, "--arch", arch, "--port", str(port)]
            if log: log("🚀 F5: menyalakan server (load model ~20-30s, sekali saja)...")
            _F5_PROC = subprocess.Popen(cmd, cwd=F5_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(150):   # tunggu model siap (maks 150s)
            if _f5_alive(url):
                if log: log("✅ F5 server siap")
                return url
            time.sleep(1)
    if log: log("⚠ F5 server tidak siap (timeout)")
    return None


def _f5_tts(text, settings, out_mp3, log=None):
    """Sintesis via server F5 (voice cloning). Return True kalau sukses."""
    url = _ensure_f5_server(settings, log=log)
    if not url:
        return False
    _, _, _, ref, ref_text, _, _ = _f5_paths(settings)   # kirim ref per-request
    try:
        r = _req.post(url.rstrip("/") + "/tts",
                      json={"text": text, "ref": ref, "ref_text": ref_text}, timeout=180)
        if r.status_code != 200 or len(r.content) < 500:
            if log: log("⚠ F5 %s" % r.status_code)
            return False
        wav = out_mp3 + ".f5.wav"
        with open(wav, "wb") as f:
            f.write(r.content)
        subprocess.run([FFMPEG, "-y", "-i", wav, out_mp3], capture_output=True, text=True, encoding="utf-8", errors="replace")
        try:
            os.remove(wav)
        except Exception:
            pass
        ok = os.path.exists(out_mp3) and os.path.getsize(out_mp3) > 500
        if ok and log: log("🎙 F5 TTS (clone) OK")
        return ok
    except Exception as e:
        if log: log("⚠ F5 error: %s" % e)
        return False


def _synthesize(text, settings, out_mp3, log=None):
    """Sintesis 1 teks → out_mp3 sesuai tts_engine. Return nama engine yg DIPAKAI ('piper'/'gemini'/'edge')."""
    engine = (settings.get("tts_engine") or "auto").lower()
    if engine == "f5":
        if _f5_tts(text, settings, out_mp3, log=log):
            return "f5"
    elif engine == "piper":
        if _piper_tts(text, settings, out_mp3, log=log):
            return "piper"
    elif engine == "gemini":
        if _gemini_tts(text, settings, out_mp3, log=log):
            return "gemini"
    elif engine == "edge":
        pass
    else:  # auto: piper → gemini → edge
        if _piper_tts(text, settings, out_mp3, log=log):
            return "piper"
        if _gemini_tts(text, settings, out_mp3, log=log):
            return "gemini"
    # edge (default / fallback terakhir)
    voice = settings.get("voice") or DEFAULTS["voice"]
    rate = settings.get("rate") or DEFAULTS["rate"]
    asyncio.run(_tts(text, voice, rate, out_mp3))
    return "edge"


def _caption_durs(voice_path, phrases, total):
    """Durasi tiap caption — pakai DETEKSI JEDA asli di audio (akurat), fallback proporsional."""
    n = len(phrases)
    if n <= 1:
        return [total]
    try:
        res = subprocess.run([FFMPEG, "-hide_banner", "-i", voice_path,
                              "-af", "silencedetect=noise=-33dB:d=0.10", "-f", "null", "-"],
                             capture_output=True, text=True, encoding="utf-8", errors="replace")
        txt = res.stderr or ""
        starts = [float(x) for x in re.findall(r"silence_start: ([-\d.]+)", txt)]
        ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", txt)]
        sil = []   # (titik_potong, panjang_jeda)
        for st in starts:
            en = next((e for e in ends if e > st), total)
            mid = (st + en) / 2.0
            if 0.2 < mid < total - 0.2:
                sil.append((mid, en - st))
        wpro = [max(1, len((p.get("text") or "").strip())) for p in phrases]
        twp = sum(wpro) or 1
        if len(sil) >= n - 1:
            sil.sort(key=lambda x: -x[1])            # jeda terpanjang = batas antar kalimat
            cuts = sorted(c for c, _ in sil[:n - 1])
            bounds = [0.0] + cuts + [total]
            durs = [bounds[i + 1] - bounds[i] for i in range(n)]
            # validasi: tiap caption ≥0.7s & tidak jauh menyimpang dari porsi huruf (cegah salah deteksi)
            ok = all(d >= 0.7 for d in durs)
            ok = ok and all(0.4 <= d / (total * w / twp) <= 2.6 for d, w in zip(durs, wpro))
            if ok:
                return durs
    except Exception:
        pass
    weights = [max(1, len((p.get("text") or "").strip())) for p in phrases]
    tw = sum(weights) or 1
    return [total * w / tw for w in weights]


def _make_voiceover(phrases, settings, workdir, log=None):
    """Generate SELURUH script 1x (mengalir natural). Engine sesuai tts_engine.
    Caption disinkronkan ke JEDA asli di audio."""
    voice_path = os.path.join(workdir, "voice.mp3")
    full_text = " ".join(p["text"].strip() for p in phrases if p.get("text"))
    _synthesize(full_text, settings, voice_path, log=log)
    total = _ff_duration(voice_path)
    durs = _caption_durs(voice_path, phrases, total)
    return durs, total


# ── ASS subtitle ────────────────────────────────────────────────────
def _ass_t(s):
    h = int(s // 3600); m = int((s % 3600) // 60); sec = s % 60
    return f"{h}:{m:02d}:{sec:05.2f}"


def _build_ass(script, segs, total, settings):
    W, Hh = settings["width"], settings["height"]
    hl = _rgb_to_ass(settings.get("highlight_rgb"))
    head = (
        "[Script Info]\nScriptType: v4.00+\n"
        f"PlayResX: {W}\nPlayResY: {Hh}\nWrapStyle: 0\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        "Style: Title,Arial,66,&H00FFFFFF,&H00000000,&H64000000,1,0,1,5,2,8,60,60,170,1\n"
        "Style: Sub,Arial,42,&H00FFFFFF,&H00000000,&H64000000,0,1,1,4,1,8,60,60,258,1\n"
        "Style: Cap,Arial,64,&H00FFFFFF,&H00000000,&H50000000,1,0,1,6,2,2,90,90,260,1\n\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    # headline + subtitle hanya tampil di AWAL (biar tak tabrakan dgn overlay di tengah)
    hl_end = _ass_t(total * 0.42)
    head_txt = _smart_trunc(script.get("headline", ""), 22)   # ringkas → 1 baris
    lines = [
        f"Dialogue: 0,{_ass_t(0)},{hl_end},Title,,0,0,0,,{head_txt}",
        f"Dialogue: 0,{_ass_t(0)},{hl_end},Sub,,0,0,0,,{script.get('subtitle','')}",
    ]
    for text, kw, st, en in segs:
        t = text
        if kw and kw in text:
            t = text.replace(kw, "{\\c" + hl + "}" + kw + "{\\c&HFFFFFF&}", 1)
        lines.append(f"Dialogue: 1,{_ass_t(st)},{_ass_t(en)},Cap,,0,0,0,,{t}")
    return head + "\n".join(lines) + "\n"


# ── Ken Burns bervariasi (zoom in/out + geser kiri/kanan/atas) ──────
_KB = ["in", "out", "left", "right", "up", "down"]
_XF = ["fade", "slideleft", "slideright", "wipeleft", "smoothleft", "circleopen", "fadeblack"]


def _kb_filter(eff, N, fps):
    """zoompan dengan efek tertentu (eff = nama efek dari _KB)."""
    if eff == "in":
        z = "min(1.16,1.0+0.0011*on)"; x = "iw/2-(iw/zoom/2)"; y = "ih/2-(ih/zoom/2)"
    elif eff == "out":
        z = "max(1.02,1.16-0.0011*on)"; x = "iw/2-(iw/zoom/2)"; y = "ih/2-(ih/zoom/2)"
    elif eff == "left":
        z = "1.12"; x = f"(iw-iw/zoom)*(1-on/{N})"; y = "ih/2-(ih/zoom/2)"
    elif eff == "right":
        z = "1.12"; x = f"(iw-iw/zoom)*(on/{N})"; y = "ih/2-(ih/zoom/2)"
    elif eff == "up":
        z = "1.12"; x = "iw/2-(iw/zoom/2)"; y = f"(ih-ih/zoom)*(1-on/{N})"
    else:  # down
        z = "1.12"; x = "iw/2-(iw/zoom/2)"; y = f"(ih-ih/zoom)*(on/{N})"
    return f"zoompan=z='{z}':x='{x}':y='{y}':d={N}"


_NVENC = None
# Batasi sesi NVENC paralel (GPU consumer cuma kuat sedikit sesi → kalau kebanyakan, render mandek)
_NVENC_SEM = threading.BoundedSemaphore(2)
RENDER_TIMEOUT = 90    # detik; render macet > ini dibunuh & dicoba ulang (cegah batch nyangkut lama)


def _run_ff(cmd, workdir):
    try:
        return subprocess.run(cmd, cwd=workdir, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=RENDER_TIMEOUT)
    except subprocess.TimeoutExpired:
        return None


def _has_nvenc():
    """Cek sekali apakah h264_nvenc (GPU NVIDIA) bisa dipakai. Cache hasilnya."""
    global _NVENC
    if _NVENC is not None:
        return _NVENC
    try:
        p = subprocess.run([FFMPEG, "-hide_banner", "-f", "lavfi", "-i", "color=c=black:s=320x240:d=0.2",
                            "-c:v", "h264_nvenc", "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        _NVENC = (p.returncode == 0)
    except Exception:
        _NVENC = False
    return _NVENC


def _vcodec_args(settings):
    """Pilih encoder video: GPU NVENC kalau ada & diizinkan, else libx264 cepat."""
    use_gpu = settings.get("use_gpu", "auto")
    if (use_gpu in (True, "auto", "1", "on", "true")) and _has_nvenc():
        return ["-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", "26", "-b:v", "0", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p"]


def _render_video(slot_images, settings, total, out_video, bg_image=None,
                  voice="voice.mp3", music=None, ass="sub.ass", workdir=None, overlays=None):
    """Render slideshow + overlay template + caption + audio dalam 1x ffmpeg (cepat).
    bg_image (opsional) = gambar latar custom; overlays = list elemen template ber-timing."""
    W, Hh, fps = settings["width"], settings["height"], settings["fps"]
    mvol = float(settings.get("music_volume") or 0.15)
    D = float(settings.get("image_sec") or 3.0)
    T = float(settings.get("transition") or 0.5)
    style = (settings.get("bg_style") or "clean").lower()
    Ns = len(slot_images)
    N = max(1, round(fps * D))
    # acak urutan efek per video → tiap generate terlihat beda
    kb_order = _KB[:]; random.shuffle(kb_order)
    xf_order = _XF[:]; random.shuffle(xf_order)

    inputs = []
    for img in slot_images:
        inputs += ["-loop", "1", "-t", f"{D + T:.3f}", "-i", img]
    if bg_image:
        # 1 input latar saja (di-scale 1x lalu split) → ringan & tak deadlock saat paralel
        inputs += ["-loop", "1", "-t", f"{total + T:.3f}", "-i", bg_image]

    parts = []
    if bg_image:
        bgi = Ns
        outs = "".join(f"[cb{i}]" for i in range(Ns))
        parts.append(f"[{bgi}:v]scale={W}:{Hh}:force_original_aspect_ratio=increase,"
                     f"crop={W}:{Hh},setsar=1,split={Ns}{outs}")
    for i in range(Ns):
        kb = f"{_kb_filter(kb_order[i % len(kb_order)], N, fps)}:s={W}x{Hh}:fps={fps}"
        if bg_image:
            # latar custom DIAM (statis) — HANYA produk yang Ken Burns (zoom di canvas rgba transparan)
            fg_w, fg_h = int(W * 0.74), int(Hh * 0.60)
            kb_fg = f"{_kb_filter(kb_order[i % len(kb_order)], N, fps)}:s={fg_w}x{fg_h}:fps={fps}"
            seg = (f"[{i}:v]scale={fg_w}:{fg_h}:force_original_aspect_ratio=decrease,"
                   f"format=rgba,pad={fg_w}:{fg_h}:(ow-iw)/2:(oh-ih)/2:color=black@0,{kb_fg}[fg{i}];"
                   f"[cb{i}][fg{i}]overlay=(W-w)/2:(H-h)/2,setpts=PTS-STARTPTS[v{i}]")
        elif style == "blur":
            # latar blur DIAM — hanya produk yang Ken Burns
            fg_w, fg_h = int(W * 0.83), int(Hh * 0.72)
            kb_fg = f"{_kb_filter(kb_order[i % len(kb_order)], N, fps)}:s={fg_w}x{fg_h}:fps={fps}"
            seg = (f"[{i}:v]split=2[bsrc{i}][fsrc{i}];"
                   f"[bsrc{i}]scale={W}:{Hh}:force_original_aspect_ratio=increase,crop={W}:{Hh},boxblur=20:1,eq=brightness=-0.12:saturation=1.1[bg{i}];"
                   f"[fsrc{i}]scale={fg_w}:{fg_h}:force_original_aspect_ratio=decrease,"
                   f"format=rgba,pad={fg_w}:{fg_h}:(ow-iw)/2:(oh-ih)/2:color=black@0,{kb_fg}[fg{i}];"
                   f"[bg{i}][fg{i}]overlay=(W-w)/2:(H-h)/2,setpts=PTS-STARTPTS[v{i}]")
        else:
            # latar bersih: produk di tengah dgn margin, vignette halus
            fg_w, fg_h = int(W * 0.74), int(Hh * 0.60)
            col = _BG_COLORS[i % len(_BG_COLORS)] if style == "gradient" else "0xF5F4F2"
            seg = (f"[{i}:v]scale={fg_w}:{fg_h}:force_original_aspect_ratio=decrease,"
                   f"pad={W}:{Hh}:(ow-iw)/2:(oh-ih)/2:color={col},"
                   f"{kb},vignette=PI/7,setpts=PTS-STARTPTS[v{i}]")
        parts.append(seg)
    if len(slot_images) == 1:
        parts.append("[v0]copy[vout]")
    else:
        prev = "v0"; off = D - T
        for i in range(1, len(slot_images)):
            trans = xf_order[(i - 1) % len(xf_order)]
            out_lbl = "vout" if i == len(slot_images) - 1 else f"x{i}"
            parts.append(f"[{prev}][v{i}]xfade=transition={trans}:duration={T:.3f}:offset={off:.3f}[{out_lbl}]")
            prev = out_lbl; off += (D - T)

    # ── encode helper (NVENC/CPU + semaphore + timeout + fallback) ──
    def _do_encode(enc_inputs, enc_fc, enc_maps, out):
        head = [FFMPEG, "-y"] + enc_inputs + ["-filter_complex", enc_fc] + enc_maps + ["-r", str(fps)]
        tail = ["-c:a", "aac", "-threads", "0", out]
        NV = ["-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", "26", "-b:v", "0", "-pix_fmt", "yuv420p"]
        CPU = ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p"]
        use_gpu = settings.get("use_gpu", "auto")
        want = (use_gpu in (True, "auto", "1", "on", "true")) and _has_nvenc()
        got = _NVENC_SEM.acquire(blocking=False) if want else False
        try:
            p = _run_ff(head + (NV if got else CPU) + tail, workdir)
        finally:
            if got:
                _NVENC_SEM.release()
        if (p is None or p.returncode != 0) and got:
            p = _run_ff(head + CPU + tail, workdir)
        if p is None or p.returncode != 0:
            raise RuntimeError("FFmpeg render gagal: " + (p.stderr[-400:] if p else "timeout/macet"))

    # PASS 1: slideshow (gambar+kenburns+xfade+bg) → slide.mp4. Filtergraph berat tapi TANPA
    # overlay/audio → terbukti stabil di paralel. (mencampur overlay di sini = deadlock)
    slide = os.path.join(workdir, "_slide.mp4")
    _do_encode(inputs, ";".join(parts), ["-map", "[vout]", "-t", f"{total:.3f}"], slide)

    # PASS 2: slide.mp4 (video flat) + overlay + caption + audio → final. Sederhana → tak deadlock.
    inputs2 = ["-i", slide, "-i", voice or "voice.mp3"]
    nidx = 2
    if music:
        inputs2 += ["-i", os.path.abspath(music)]; nidx = 3
    ov_parts = []
    vlast = "0:v"
    for j, ov in enumerate(overlays or []):
        # overlay di-loop sepanjang video → bisa fade-in (animasi halus, tak "pop")
        inputs2 += ["-loop", "1", "-t", f"{total:.3f}", "-i", ov["path"]]
        fin = f"ovin{j}"; out = f"ovl{j}"
        ov_parts.append(f"[{nidx + j}:v]format=rgba,fade=t=in:st={ov['t0']:.2f}:d=0.35:alpha=1[{fin}]")
        ov_parts.append(f"[{vlast}][{fin}]overlay={int(ov['x'])}:{int(ov['y'])}:"
                        f"enable='between(t,{ov['t0']:.2f},{ov['t1']:.2f})'[{out}]")
        vlast = out
    fc2 = (";".join(ov_parts) + ";" if ov_parts else "") + f"[{vlast}]ass={ass or 'sub.ass'}[vf]"
    maps2 = ["-map", "[vf]"]
    fc2 += f";[1:a]apad,atrim=0:{total:.3f},asetpts=N/SR/TB[va]"
    if music:
        fc2 += (f";[2:a]volume={mvol},apad,atrim=0:{total:.3f},asetpts=N/SR/TB[ma];"
                f"[va][ma]amix=inputs=2:duration=first:dropout_transition=0[a]")
        maps2 += ["-map", "[a]"]
    else:
        maps2 += ["-map", "[va]"]
    _do_encode(inputs2, fc2, maps2 + ["-t", f"{total:.3f}"], out_video)


def _pick_bg(path):
    """Resolve background custom: file -> file itu; folder -> 1 gambar random. None kalau kosong/invalid."""
    path = (path or "").strip().strip('"')
    if not path:
        return None
    try:
        if os.path.isfile(path):
            return path
        if os.path.isdir(path):
            imgs = [f for f in os.listdir(path) if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".bmp"))]
            if imgs:
                return os.path.join(path, random.choice(imgs))
    except Exception:
        pass
    return None


def _pick_music(folder):
    try:
        files = [f for f in os.listdir(folder) if f.lower().endswith((".mp3", ".m4a", ".wav", ".aac"))]
        if files:
            return os.path.join(folder, random.choice(files))
    except Exception:
        pass
    return None


_REVIEW_NAMES = ["Rina", "Siti", "Dewi", "Putri", "Sari", "Maya", "Fitri", "Nadia", "Wulan", "Indah",
                 "Ayu", "Citra", "Dian", "Eka", "Budi", "Andi", "Bayu", "Rizki", "Yoga", "Lutfi",
                 "Hana", "Tari", "Vina", "Gita", "Reza", "Dimas", "Fajar", "Aldi"]
_REVIEW_MONTHS = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]


def _rand_reviewer():
    """Nama + tanggal (acak masa LALU, 3hari–6bln sebelum hari ini) + rating (mostly 5)."""
    import datetime
    name = random.choice(_REVIEW_NAMES) + " " + random.choice("ABDEFGHKMNPRSTW") + "."
    d = datetime.date.today() - datetime.timedelta(days=random.randint(3, 185))
    date = "%d %s %d" % (d.day, _REVIEW_MONTHS[d.month - 1], d.year)
    stars = random.choices([5, 4], weights=[80, 20])[0]
    return name, date, stars


def _build_overlays(script, settings, workdir, total, imgs=None, log=None):
    """Bikin elemen template (kartu review / checklist / mockup CTA) + timing.
    Pilih 1 template acak per video → variasi. Return list {path,x,y,t0,t1}."""
    if (settings.get("template") or "auto").lower() in ("off", "none", "polos"):
        return []
    try:
        from src.macro import slideshow_overlays as OV
    except Exception as e:
        if log: log("⚠ overlay nonaktif: %s" % e)
        return []
    W = settings["width"]; Hh = settings["height"]
    feats = [f for f in (script.get("features") or []) if f][:5]
    rev = script.get("review") or {}
    out = []
    tpl = random.choice(["full", "review_cta", "check_cta", "review_cta", "full"])  # CTA selalu ada
    # CTA mockup di akhir (selalu)
    cw, ch = int(W * 0.80), int(Hh * 0.60)
    prod = random.choice(imgs) if imgs else None   # gambar produk ditempel ke kartu CTA
    try:
        p, _, _ = OV.make_cta_card(os.path.join(workdir, "ov_cta.png"), cw, ch, product_img=prod)
        out.append({"path": p, "x": (W - cw) // 2, "y": int(Hh * 0.20), "t0": total * 0.74, "t1": total})
    except Exception:
        pass
    if tpl in ("full", "check_cta") and feats:
        clw = int(W * 0.62)
        try:
            p, _, h = OV.make_checklist(os.path.join(workdir, "ov_chk.png"), feats, width=clw)
            out.append({"path": p, "x": (W - clw) // 2, "y": int(Hh * 0.165),  # di bawah headline, tak nutup produk
                        "t0": total * 0.12, "t1": total * (0.45 if tpl == "full" else 0.70)})
        except Exception:
            pass
    if tpl in ("full", "review_cta") and rev.get("text"):
        rw = int(W * 0.84)
        rname, rdate, rstars = _rand_reviewer()   # acak nama/tanggal/rating (sistem, bukan AI)
        try:
            p, _, h = OV.make_review_card(os.path.join(workdir, "ov_rev.png"), rname,
                                          rev.get("text", ""), rstars,
                                          width=rw, date=rdate, seed=random.randint(0, 9999))
            out.append({"path": p, "x": (W - rw) // 2, "y": int(Hh * 0.165),  # dinaikkan biar tak nutup produk
                        "t0": total * (0.48 if tpl == "full" else 0.12), "t1": total * 0.72})
        except Exception:
            pass
    if log: log(f"🎨 template: {tpl} ({len(out)} overlay)")
    return out


# ── API utama ───────────────────────────────────────────────────────
def generate(title, image_urls, settings, out_path, workdir=None, log=None):
    """Render 1 video slideshow. Return out_path kalau sukses, raise kalau gagal."""
    s = dict(DEFAULTS); s.update(settings or {})
    image_urls = [u for u in (image_urls or []) if u]
    if not image_urls:
        raise RuntimeError("Tidak ada gambar")
    if workdir is None:
        workdir = os.path.join(os.path.dirname(out_path) or ".", "_ss_" + re.sub(r"\W+", "", os.path.basename(out_path))[:20])
    os.makedirs(workdir, exist_ok=True)

    from concurrent.futures import ThreadPoolExecutor
    _tmr = {}

    # 0. Download gambar JALAN PARALEL dgn script+TTS (tdk saling tunggu)
    urls7 = image_urls[:7]
    paths = [os.path.join(workdir, f"img{i}.jpg") for i in range(len(urls7))]
    def _dl_all():
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=7) as ex:
            ok = list(ex.map(lambda i: i if _download_image(urls7[i], paths[i]) else None, range(len(urls7))))
        _tmr["dl"] = time.time() - t0
        return [paths[i] for i in range(len(urls7)) if ok[i] is not None]
    _dl_pool = ThreadPoolExecutor(max_workers=1)
    _dl_future = _dl_pool.submit(_dl_all)

    # 1. Script (AI OpenAI-compatible / fallback)
    t0 = time.time()
    script = _gemini_script(title, s, log=log)
    phrases = script.get("phrases") or []
    if not phrases:
        raise RuntimeError("Script kosong")
    _tmr["script"] = time.time() - t0
    if log: log(f"📝 script: {script.get('headline')} ({len(phrases)} frasa)")

    # 2. Voice over (1x generate utuh → natural) + durasi per frasa proporsional
    t0 = time.time()
    durs, total = _make_voiceover(phrases, s, workdir, log=log)
    _tmr["tts"] = time.time() - t0
    if total < 1:
        raise RuntimeError("Voice over gagal")

    # Kunci durasi ke target: atempo (percepat/perlambat voice) dalam batas natural → isi penuh, tak diam
    dur_target = float(s.get("duration_sec") or DEFAULTS["duration_sec"])
    if total > 1:
        atempo = max(0.85, min(1.22, total / dur_target))   # >1 percepat, <1 perlambat
        if abs(atempo - 1.0) > 0.03:
            vp = os.path.join(workdir, "voice.mp3")
            vp2 = os.path.join(workdir, "voice_t.mp3")
            pr = subprocess.run([FFMPEG, "-y", "-i", vp, "-filter:a", f"atempo={atempo:.4f}", vp2],
                                capture_output=True, text=True, encoding="utf-8", errors="replace")
            if pr.returncode == 0 and os.path.exists(vp2):
                os.replace(vp2, vp)
                total = total / atempo
                durs = [d / atempo for d in durs]
    # Durasi video = panjang voice (tak ada ekor diam) + sedikit nafas
    video_total = total + 0.4

    # 3. Caption timing (CTA/frasa terakhir tampil sampai akhir video)
    segs = []; t = 0.0
    for p, d in zip(phrases, durs):
        segs.append([p["text"], p.get("keyword", ""), t, t + d]); t += d
    if segs:
        segs[-1][3] = video_total
    open(os.path.join(workdir, "sub.ass"), "w", encoding="utf-8").write(_build_ass(script, segs, video_total, s))

    # 4. Tunggu download selesai (kemungkinan sdh kelar saat script+TTS jalan)
    imgs = _dl_future.result(); _dl_pool.shutdown(wait=False)
    if not imgs:
        raise RuntimeError("Semua gambar gagal di-download")

    # 5. Susun slot gambar — ACAK & UNIK (tak berulang), urutan beda tiap generate
    img_sec = float(s.get("image_sec") or 3.0)
    target = max(1, round(video_total / img_sec))
    n_slots = min(target, len(imgs))                 # ≤ jumlah gambar → tak ada yang berulang
    slots = random.sample(imgs, n_slots)             # pilih acak & unik, urutan acak (beda tiap generate)
    s["image_sec"] = video_total / n_slots           # durasi per gambar menyesuaikan biar isi penuh
    bg_image = _pick_bg(s.get("bg_path"))
    if log:
        log(f"🖼 {len(imgs)} gambar → {n_slots} slot acak unik @~{s['image_sec']:.1f}s"
            + (f" | latar custom: {os.path.basename(bg_image)}" if bg_image else f" | latar: {s.get('bg_style')}"))
    # 6. Render final (slideshow + overlay template + caption + voice + musik) — 1x encode
    t0 = time.time()
    music = _pick_music(s["music_folder"]) if s.get("music_folder") else None
    overlays = _build_overlays(script, s, workdir, video_total, imgs=imgs, log=log)
    out_abs = os.path.abspath(out_path)
    _render_video(slots, s, video_total, out_abs, bg_image=bg_image,
                  voice="voice.mp3", music=music, ass="sub.ass", workdir=workdir, overlays=overlays)
    _tmr["render"] = time.time() - t0
    if log:
        log(f"🎬 OK ({round(_ff_duration(out_abs),1)}s) → {out_abs}")
        log("⏱ script %.1fs · tts %.1fs · download %.1fs · render %.1fs"
            % (_tmr.get("script", 0), _tmr.get("tts", 0), _tmr.get("dl", 0), _tmr.get("render", 0)))
    return out_abs


if __name__ == "__main__":
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    urls = ["https://cf.shopee.co.id/file/id-11134207-7r98y-lprxocbzqyx19a",
            "https://cf.shopee.co.id/file/id-11134211-7r992-lz730dlexmnc01",
            "https://cf.shopee.co.id/file/id-11134211-822wi-mnvad79aa8lia2"]
    out_path = os.path.join(HERE, "..", "..", "temp", "ss_module_test.mp4")
    out = generate("Sarung Tangan Anti UV Wanita Korea Premium", urls, {}, out_path, log=print)
    print("HASIL:", out)
