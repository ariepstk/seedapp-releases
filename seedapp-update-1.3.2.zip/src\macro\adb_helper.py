"""
╔══════════════════════════════════════╗
║  src/macro/adb_helper.py             ║
║  Perintah ADB dasar - JANGAN DIUBAH  ║
╚══════════════════════════════════════╝

File ini hanya berisi wrapper ADB.
Yang perlu kamu edit ada di: shopee_macro.py
"""

import subprocess
import time

ADB_PATH  = "adb"   # Ganti path jika adb.exe bukan di PATH


def _run(args: list, serial: str = None, timeout: int = 30) -> str:
    cmd = [ADB_PATH]
    if serial:
        cmd += ["-s", serial]
    cmd += args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, encoding="utf-8", errors="replace")
        return (r.stdout + r.stderr).strip()
    except FileNotFoundError:
        raise RuntimeError("ADB tidak ditemukan! Pastikan ADB sudah ada di PATH.")
    except subprocess.TimeoutExpired:
        return "TIMEOUT"
    except Exception as e:
        return f"ERROR: {e}"


def get_devices() -> list:
    """Return list device: [{"serial": "...", "label": "..."}]"""
    out     = _run(["devices", "-l"])
    devices = []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            serial = parts[0]
            model  = next((p.replace("model:", "").replace("_", " ")
                           for p in parts if p.startswith("model:")), serial)
            devices.append({"serial": serial, "label": f"{model}  ({serial})"})
    return devices


def launch_app(package: str, serial: str = None) -> str:
    """Buka aplikasi berdasarkan package name."""
    return _run(["shell", "monkey", "-p", package, "-c",
                 "android.intent.category.LAUNCHER", "1"], serial)


def tap(x: int, y: int, serial: str = None, delay: float = 0.6):
    _run(["shell", "input", "tap", str(x), str(y)], serial)
    time.sleep(delay)


def swipe(x1: int, y1: int, x2: int, y2: int,
          ms: int = 300, serial: str = None, delay: float = 0.4):
    _run(["shell", "input", "swipe",
          str(x1), str(y1), str(x2), str(y2), str(ms)], serial)
    time.sleep(delay)


def input_text(text: str, serial: str = None):
    safe = text.replace(" ", "%s").replace("'", "\\'")
    _run(["shell", "input", "text", safe], serial)
    time.sleep(0.5)


def press_back(serial: str = None):
    _run(["shell", "input", "keyevent", "KEYCODE_BACK"], serial)
    time.sleep(0.4)


def press_home(serial: str = None):
    _run(["shell", "input", "keyevent", "KEYCODE_HOME"], serial)
    time.sleep(0.4)


def shell(cmd: str, serial: str = None, timeout: int = 30) -> str:
    """Jalankan perintah shell bebas di HP."""
    return _run(["shell", cmd], serial, timeout)


def download_gdrive(item_id: int, url: str, serial: str = None) -> bool:
    """Download file dari GDrive langsung di HP via curl."""
    if not url or not url.startswith("http"):
        return False
    remote = f"/sdcard/SeedApp/video_{item_id}.mp4"
    shell("mkdir -p /sdcard/SeedApp", serial)
    out = shell(f'curl -L --max-time 120 -o "{remote}" "{url}" '
                f'&& echo DL_OK || echo DL_FAIL', serial, timeout=130)
    return "DL_OK" in out

def airplane_toggle(serial: str, log=None):
    """Toggle airplane mode ON lalu OFF via swipe-down + tap tile (PURE ADB SHELL).
    Layout asumsi (dari screenshot user): Quick Settings full-expanded.
    Tile Airplane mode @ ~(38%, 41%) — row toggle pertama setelah WiFi/BT cards + sliders.
    """
    def _adb(cmd, timeout=8):
        return subprocess.run(
            ["adb", "-s", serial] + cmd,
            capture_output=True, text=True, timeout=timeout
        )
    try:
        size = _get_screen_size(serial)
        if not size:
            if log: log(f"⚠ Airplane toggle: get screen size gagal — {serial}")
            return
        w, h = size
        tap_x = int(w * 0.38)
        tap_y = int(h * 0.41)

        # ── Airplane ON ──
        if log: log(f"✈ Airplane ON — {serial}")
        _adb(["shell", "cmd", "statusbar", "expand-settings"])
        time.sleep(1.2)
        _adb(["shell", "input", "tap", str(tap_x), str(tap_y)])
        time.sleep(0.8)
        _adb(["shell", "input", "keyevent", "KEYCODE_BACK"])  # tutup panel
        time.sleep(3)  # tunggu radio off

        # ── Airplane OFF ──
        if log: log(f"✈ Airplane OFF — {serial}")
        _adb(["shell", "cmd", "statusbar", "expand-settings"])
        time.sleep(1.2)
        _adb(["shell", "input", "tap", str(tap_x), str(tap_y)])
        time.sleep(0.8)
        _adb(["shell", "input", "keyevent", "KEYCODE_BACK"])
        time.sleep(5)  # tunggu radio on + koneksi pulih
    except Exception as e:
        if log: log(f"⚠ Airplane toggle gagal: {e}")

def wifi_toggle(serial: str, on: bool, log=None):
    """Turn WiFi ON or OFF on a device via ADB."""
    def _adb(cmd):
        return subprocess.run(
            ["adb", "-s", serial] + cmd,
            capture_output=True, text=True
        )
    try:
        state = "enable" if on else "disable"
        label = "ON" if on else "OFF"
        if log: log(f"📶 WiFi {label} — {serial}")
        _adb(["shell", "svc", "wifi", state])
        time.sleep(3 if on else 1)
    except Exception as e:
        if log: log(f"⚠ WiFi toggle gagal: {e}")

def wifi_off_all(serials: list, log=None):
    """Turn off WiFi on all devices in the list."""
    for serial in serials:
        wifi_toggle(serial, on=False, log=log)


def _get_screen_size(serial: str) -> tuple | None:
    """Return (width, height) layar HP via shell, atau None kalo gagal."""
    import re as _re
    try:
        r = subprocess.run(
            ["adb", "-s", serial, "shell", "wm", "size"],
            capture_output=True, text=True, timeout=5
        )
        m = _re.search(r'(\d+)x(\d+)', r.stdout)
        if m:
            return int(m.group(1)), int(m.group(2))
    except Exception:
        pass
    return None


def hotspot_enable(serial: str, log=None) -> bool:
    """Aktifkan WiFi hotspot via swipe-down + tap tile (PURE ADB SHELL — no uiautomator2).
    Layout asumsi (dari screenshot user): Quick Settings full-expanded.
    Tile Hotspot @ ~(60%, 41%) — row toggle pertama setelah WiFi/BT cards + sliders.
    """
    if log: log(f"📡 Hotspot enable — {serial}")

    # Skip kalau udah aktif
    if hotspot_is_active(serial):
        if log: log(f"📡 Hotspot sudah ON — {serial}")
        return True

    try:
        # Buka Quick Settings panel via shell (tanpa uiautomator2)
        subprocess.run(
            ["adb", "-s", serial, "shell", "cmd", "statusbar", "expand-settings"],
            capture_output=True, text=True, timeout=8
        )
        time.sleep(1.5)

        # Tap Hotspot tile by coordinate
        size = _get_screen_size(serial)
        if not size:
            if log: log(f"⚠ Get screen size gagal — {serial}")
            subprocess.run(["adb", "-s", serial, "shell", "input", "keyevent", "KEYCODE_BACK"],
                           capture_output=True, timeout=5)
            return False

        w, h = size
        # Tile Hotspot @ ~60% x, 41% y (row toggle setelah WiFi/BT + sliders)
        tap_x = int(w * 0.60)
        tap_y = int(h * 0.41)
        subprocess.run(
            ["adb", "-s", serial, "shell", "input", "tap", str(tap_x), str(tap_y)],
            capture_output=True, text=True, timeout=5
        )
        if log: log(f"📡 Tap Hotspot tile @ ({tap_x},{tap_y}) — {serial}")
        time.sleep(2.5)  # tunggu state change + dialog confirmation

        # Kalau muncul dialog "Continue" / "OK" / "Hotspot will use mobile data" — tap Enter (default OK)
        subprocess.run(["adb", "-s", serial, "shell", "input", "keyevent", "KEYCODE_ENTER"],
                       capture_output=True, timeout=5)
        time.sleep(1)

        # Tutup Quick Settings panel
        subprocess.run(["adb", "-s", serial, "shell", "input", "keyevent", "KEYCODE_BACK"],
                       capture_output=True, timeout=5)
        time.sleep(0.8)

        # Verify hotspot beneran ON
        ok = hotspot_is_active(serial)
        if log:
            log(f"📡 Hotspot {'ON ✓' if ok else 'gagal ✗ (verify FAIL)'} — {serial}")
        return ok

    except Exception as e:
        if log: log(f"⚠ Hotspot enable error: {e}")
        return False


def lock_rotation_portrait(serial: str, log=None):
    """Lock HP ke portrait (disable auto-rotate). Penting untuk HP tethering biar
    coord tile Quick Settings tetap akurat saat swipe-tap.
    Pure ADB shell.
    """
    try:
        subprocess.run(
            ["adb", "-s", serial, "shell", "settings", "put", "system", "accelerometer_rotation", "0"],
            capture_output=True, text=True, timeout=5
        )
        subprocess.run(
            ["adb", "-s", serial, "shell", "settings", "put", "system", "user_rotation", "0"],
            capture_output=True, text=True, timeout=5
        )
        if log: log(f"🔒 Rotation locked portrait — {serial}")
    except Exception as e:
        if log: log(f"⚠ Lock rotation gagal: {e}")


def airplane_then_hotspot_reset(serial: str, log=None):
    """Combined flow per batch: buka panel SEKALI, toggle airplane (ON→OFF), enable hotspot, tutup.
    Single panel session, jeda 5s antar aksi. Pure ADB shell.

    Flow:
       1. Swipe panel down (cmd statusbar expand-settings)
       2. Tunggu 1s (panel fully open)
       3. Tap Airplane tile (38%, 41%) → Airplane ON
       4. Tunggu 5s
       5. Tap Airplane tile lagi → Airplane OFF
       6. Tunggu 5s
       7. Tap Hotspot tile (60%, 41%) → Hotspot ON
       8. Tunggu 5s
       9. KEYCODE_HOME → tutup panel
    """
    def _adb(cmd, timeout=8):
        return subprocess.run(
            ["adb", "-s", serial] + cmd,
            capture_output=True, text=True, timeout=timeout
        )
    try:
        size = _get_screen_size(serial)
        if not size:
            if log: log(f"⚠ Combined reset: get screen size gagal — {serial}")
            return
        w, h = size
        airplane_x = int(w * 0.38)
        airplane_y = int(h * 0.41)
        hotspot_x  = int(w * 0.60)
        hotspot_y  = int(h * 0.41)

        # 0. Re-lock rotation portrait (HP mungkin udah ke-rotate selama upload)
        lock_rotation_portrait(serial, log=None)

        # 1. Buka panel
        if log: log(f"📱 Buka Quick Settings panel — {serial}")
        _adb(["shell", "cmd", "statusbar", "expand-settings"])
        time.sleep(1)

        # 3. Airplane ON
        if log: log(f"✈ Airplane ON @ ({airplane_x},{airplane_y}) — {serial}")
        _adb(["shell", "input", "tap", str(airplane_x), str(airplane_y)])
        # 4. Tunggu 5s
        time.sleep(5)

        # 5. Airplane OFF
        if log: log(f"✈ Airplane OFF — {serial}")
        _adb(["shell", "input", "tap", str(airplane_x), str(airplane_y)])
        # 6. Tunggu 5s
        time.sleep(5)

        # 7. Cek status hotspot SEBELUM tap (penting!)
        #    Kalau hotspot survive airplane (Android pintar) → jangan tap (would toggle OFF)
        #    Kalau hotspot mati setelah airplane → tap untuk nyalain
        if hotspot_is_active(serial):
            if log: log(f"📡 Hotspot survive airplane — SKIP tap (anti-toggle-off) — {serial}")
        else:
            if log: log(f"📡 Hotspot ON @ ({hotspot_x},{hotspot_y}) — {serial}")
            _adb(["shell", "input", "tap", str(hotspot_x), str(hotspot_y)])
            # 8. Tunggu 5s
            time.sleep(5)

        # 9. Tutup panel via HOME
        _adb(["shell", "input", "keyevent", "KEYCODE_HOME"])
        time.sleep(0.8)
        if log: log(f"🏠 Panel ditutup — {serial}")
    except Exception as e:
        if log: log(f"⚠ Combined reset gagal: {e}")


def hotspot_is_active(serial: str) -> bool:
    """Cek apakah hotspot sedang aktif di device.
    3-method chain: ip link → dumpsys wifi → cmd wifi soft-ap-state.
    Method 1 (ip link) paling reliable — cek state radio interface langsung.
    Return True kalau ANY method confirm ON.
    """
    # Method 1: ip link show — cek interface hotspot UP
    # Hotspot biasanya pakai: wlan1 / wlan2 / ap0 / swlan0 (beda per vendor)
    try:
        r = subprocess.run(
            ["adb", "-s", serial, "shell", "ip", "-o", "link", "show"],
            capture_output=True, text=True, timeout=5
        )
        out = (r.stdout or "").lower()
        for line in out.splitlines():
            for iface in ("wlan1", "wlan2", "ap0", "swlan0"):
                if iface in line and "state up" in line:
                    return True
    except Exception:
        pass

    # Method 2: dumpsys wifi grep AP state
    try:
        r = subprocess.run(
            ["adb", "-s", serial, "shell", "dumpsys", "wifi"],
            capture_output=True, text=True, timeout=10
        )
        out = r.stdout.lower()
        # Indikator hotspot ON: "apenabled" / "ap_state_enabled" / "ap state: enabled"
        if "apenabled" in out or "ap_state_enabled" in out or "ap state: enabled" in out:
            return True
        # Indikator hotspot OFF (lebih kuat dari fallback ke method 3)
        if ("apdisabled" in out or "ap_state_disabled" in out or "ap state: disabled" in out):
            # Cek juga "ApEnabled" sekalian — kadang dumpsys log keduanya, ambil yang terakhir
            if "apenabled" not in out:
                return False
    except Exception:
        pass

    # Method 3: cmd wifi soft-ap-state (Android 11+)
    try:
        r = subprocess.run(
            ["adb", "-s", serial, "shell", "cmd", "wifi", "soft-ap-state"],
            capture_output=True, text=True, timeout=8
        )
        out = (r.stdout + r.stderr).lower().strip()
        if out:
            if "enabled" in out and "disabled" not in out:
                return True
            if "disabled" in out:
                return False
    except Exception:
        pass

    # Default conservative: kalau semua method gak ada signal jelas → anggap OFF
    # Reason: setup awal butuh detection OFF yg akurat biar tap enable dijalanin.
    # Combined flow risiko false-toggle-off di-mitigate via post-tap verify (kalau perlu).
    return False
