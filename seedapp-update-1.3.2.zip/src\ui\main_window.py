"""Main Window - SeedApp — Makmur-inspired layout"""
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QFrame, QStackedWidget, QSizePolicy
)
from PyQt6.QtCore import Qt
from src.core.database import init_db
import src.ui.styles as S

# Global theme state — default LIGHT
_theme = "light"


def current_theme() -> str:
    return _theme


class NavButton(QPushButton):
    def __init__(self, icon: str, label: str):
        super().__init__()
        self.setObjectName("navBtn")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(44)
        self._icon  = icon
        self._label = label
        self._set_text(True)

    def _set_text(self, expanded: bool):
        if expanded:
            self.setText(f"  {self._icon}   {self._label}")
            self.setStyleSheet("font-size: 14px;")
        else:
            self.setText(self._icon)
            self.setStyleSheet("text-align:center; padding:0px; font-size:18px;")

    def set_active(self, active: bool):
        self.setProperty("active", "true" if active else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def set_expanded(self, expanded: bool):
        self._set_text(expanded)


class MainWindow(QMainWindow):
    _instance = None

    def __init__(self):
        super().__init__()
        MainWindow._instance = self
        init_db()
        self.setWindowTitle("SeedApp")
        self.setMinimumSize(1100, 680)
        self.resize(1440, 860)
        self._sidebar_expanded = True
        self.setStyleSheet(S.get_stylesheet("light"))
        self._build_ui()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._sidebar = self._build_sidebar()
        root.addWidget(self._sidebar)

        # Divider line
        self._divider = QFrame()
        self._divider.setFixedWidth(1)
        self._divider.setStyleSheet("background:#e0e6ed;")
        root.addWidget(self._divider)

        self.stack = QStackedWidget()
        self.stack.setObjectName("contentArea")

        from src.ui.dashboard_page       import DashboardPage
        from src.ui.project_page         import ProjectPage
        from src.ui.dataset_page         import DatasetPage
        from src.ui.process_monitor_page import ProcessMonitorPage

        self.dashboard_page       = DashboardPage()
        self.project_page         = ProjectPage()
        self.dataset_page         = DatasetPage()
        self.process_monitor_page = ProcessMonitorPage()
        self.stack.addWidget(self.dashboard_page)
        self.stack.addWidget(self.project_page)
        self.stack.addWidget(self.dataset_page)
        self.stack.addWidget(self.process_monitor_page)

        root.addWidget(self.stack, 1)

        self._apply_sidebar_theme()
        self._navigate("dashboard")

    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(220)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Logo area ──
        self._logo_frame = QFrame()
        self._logo_frame.setFixedHeight(64)
        ll = QHBoxLayout(self._logo_frame)
        ll.setContentsMargins(16, 0, 10, 0)
        ll.setSpacing(10)

        self._icon_lbl = QLabel("⚡")
        self._icon_lbl.setFixedWidth(26)
        self._name_lbl = QLabel("SeedApp")
        self._ver_lbl  = QLabel("v1.0")
        self._ver_lbl.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight)

        self._toggle_btn = QPushButton("☰")
        self._toggle_btn.setObjectName("btnSidebarToggle")
        self._toggle_btn.setFixedSize(28, 28)
        self._toggle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._toggle_btn.clicked.connect(self._toggle_sidebar)

        ll.addWidget(self._icon_lbl)
        ll.addWidget(self._name_lbl, 1)
        ll.addWidget(self._ver_lbl)
        ll.addWidget(self._toggle_btn)
        layout.addWidget(self._logo_frame)

        self._logo_div = QFrame()
        self._logo_div.setFixedHeight(1)
        layout.addWidget(self._logo_div)
        layout.addSpacing(8)

        # ── Nav buttons ──
        self._nav_btns = {}
        for icon, label, key in [
            ("⬛", "Dashboard",       "dashboard"),
            ("☰", "Project",         "project"),
            ("⊞", "Dataset",         "dataset"),
            ("◎", "Process Monitor", "monitor"),
        ]:
            btn = NavButton(icon, label)
            btn.clicked.connect(lambda _, k=key: self._navigate(k))
            self._nav_btns[key] = btn
            layout.addWidget(btn)

        layout.addStretch()

        # ── Footer ──
        self._footer_frame = QFrame()
        self._footer_frame.setFixedHeight(48)
        fl = QHBoxLayout(self._footer_frame)
        fl.setContentsMargins(14, 0, 12, 0)
        fl.setSpacing(6)

        self._footer_lbl = QLabel("Shopee Uploader")

        self._theme_btn = QPushButton("🌙 Dark")
        self._theme_btn.setObjectName("btnSidebarTheme")
        self._theme_btn.setFixedHeight(28)
        self._theme_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._theme_btn.clicked.connect(self._toggle_theme)

        fl.addWidget(self._footer_lbl, 1)
        fl.addWidget(self._theme_btn)
        layout.addWidget(self._footer_frame)

        return sidebar

    def _apply_sidebar_theme(self):
        global _theme
        if _theme == "light":
            self._logo_frame.setStyleSheet("background:#00c48c; border:none;")
            self._logo_div.setStyleSheet("background:#00a876;")
            self._icon_lbl.setStyleSheet(
                "color:#ffffff; font-size:22px; font-weight:bold; background:transparent; border:none;")
            self._name_lbl.setStyleSheet(
                "color:#ffffff; font-size:17px; font-weight:700; background:transparent; border:none;")
            self._ver_lbl.setStyleSheet(
                "color:#c8f5e8; font-size:10px; background:transparent; border:none;")
            self._toggle_btn.setStyleSheet(
                "QPushButton{background:transparent;color:#c8f5e8;border:none;font-size:15px;border-radius:5px;}"
                "QPushButton:hover{background:#00a876;color:#fff;}")
            self._footer_frame.setStyleSheet("background:#00c48c; border-top:1px solid #00a876;")
            self._footer_lbl.setStyleSheet("color:#c8f5e8; font-size:11px; background:transparent;")
            self._theme_btn.setStyleSheet(
                "QPushButton{background:#00a876;color:#c8f5e8;border:none;border-radius:6px;font-size:11px;padding:2px 8px;}"
                "QPushButton:hover{color:#fff;}")
            self._divider.setStyleSheet("background:#e0e6ed;")
        else:
            self._logo_frame.setStyleSheet("background:#0f1022; border:none;")
            self._logo_div.setStyleSheet("background:#1e1f38;")
            self._icon_lbl.setStyleSheet(
                "color:#00c48c; font-size:22px; font-weight:bold; background:transparent; border:none;")
            self._name_lbl.setStyleSheet(
                "color:#ffffff; font-size:17px; font-weight:700; background:transparent; border:none;")
            self._ver_lbl.setStyleSheet(
                "color:#3a3c60; font-size:10px; background:transparent; border:none;")
            self._toggle_btn.setStyleSheet(
                "QPushButton{background:transparent;color:#3a3c60;border:none;font-size:15px;border-radius:5px;}"
                "QPushButton:hover{background:#1e1f38;color:#ffffff;}")
            self._footer_frame.setStyleSheet("background:#0f1022; border:none;")
            self._footer_lbl.setStyleSheet("color:#3a3c60; font-size:11px; background:transparent;")
            self._theme_btn.setStyleSheet(
                "QPushButton{background:#1a1b2e;color:#3a3c60;border:none;border-radius:6px;font-size:11px;padding:2px 8px;}"
                "QPushButton:hover{color:#ffffff;}")
            self._divider.setStyleSheet("background:#2e2f50;")

    def _toggle_theme(self):
        global _theme
        _theme = "light" if _theme == "dark" else "dark"
        ss = S.get_stylesheet(_theme)
        self.setStyleSheet(ss)
        self._theme_btn.setText("☀ Light" if _theme == "dark" else "🌙 Dark")
        self._apply_sidebar_theme()
        for page in [self.dashboard_page, self.project_page,
                     self.dataset_page, self.process_monitor_page]:
            # Jika project_page ada worker aktif (run/retry), skip semua operasi
            detail = getattr(page, "detail_page", None)
            if detail:
                has_retry = hasattr(detail, "_retry_workers") and detail._retry_workers
                has_run = hasattr(detail, "_worker") and detail._worker and detail._worker.isRunning()
                if has_retry or has_run:
                    continue
            page.setStyleSheet(ss)
            page.setStyleSheet("")
            page.style().unpolish(page)
            page.style().polish(page)
            page.update()
            if hasattr(page, "refresh"):
                page.refresh()
            elif hasattr(page, "_apply"):
                page._apply()

    def _toggle_sidebar(self):
        self._sidebar_expanded = not self._sidebar_expanded
        exp = self._sidebar_expanded
        self._sidebar.setFixedWidth(220 if exp else 56)
        for btn in self._nav_btns.values():
            btn.set_expanded(exp)
        self._footer_lbl.setVisible(exp)
        self._theme_btn.setVisible(exp)
        self._name_lbl.setVisible(exp)
        self._ver_lbl.setVisible(exp)

    def _navigate(self, key: str):
        for k, btn in self._nav_btns.items():
            btn.set_active(k == key)
        pages = {
            "dashboard": self.dashboard_page,
            "project":   self.project_page,
            "dataset":   self.dataset_page,
            "monitor":   self.process_monitor_page,
        }
        if key in pages:
            self.stack.setCurrentWidget(pages[key])
            if hasattr(pages[key], "refresh"):
                pages[key].refresh()

    @staticmethod
    def get_dialog_style() -> str:
        return S.get_dialog_style(_theme)
